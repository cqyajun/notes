﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class GameSDKInterfaceWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(GameSDKInterface);
			Utils.BeginObjectRegister(type, L, translator, 0, 51, 0, 0);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetChannelName", _m_GetChannelName);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetPackageBunldId", _m_GetPackageBunldId);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetPlatformName", _m_GetPlatformName);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "ReadFileFromeAssets", _m_ReadFileFromeAssets);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "AssetsFileExist", _m_AssetsFileExist);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "IsUseSdk", _m_IsUseSdk);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Init", _m_Init);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Login", _m_Login);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "LoginCustom", _m_LoginCustom);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "SwitchLogin", _m_SwitchLogin);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Logout", _m_Logout);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "ShowAccountCenter", _m_ShowAccountCenter);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "SubmitGameData", _m_SubmitGameData);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "SDKExit", _m_SDKExit);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Pay", _m_Pay);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "IsSupportExit", _m_IsSupportExit);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "IsSupportAccountCenter", _m_IsSupportAccountCenter);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "IsSupportLogout", _m_IsSupportLogout);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "RestartApplication", _m_RestartApplication);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetCountry", _m_GetCountry);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetCarrier", _m_GetCarrier);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetNewCarrier", _m_GetNewCarrier);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetIDFA", _m_GetIDFA);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetNativeAvatar", _m_GetNativeAvatar);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetVerify", _m_GetVerify);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "SubmitVerify", _m_SubmitVerify);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "ProcessIpAndAddressFamily", _m_ProcessIpAndAddressFamily);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "ShareImageToWeixin", _m_ShareImageToWeixin);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "ShareTextToWeixin", _m_ShareTextToWeixin);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "ShareUrlToWeixin", _m_ShareUrlToWeixin);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetCurSignalStrenth", _m_GetCurSignalStrenth);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetCurSignalType", _m_GetCurSignalType);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetCurBatteryLevel", _m_GetCurBatteryLevel);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "ShakePhone", _m_ShakePhone);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetCurChargeState", _m_GetCurChargeState);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "InitWechat", _m_InitWechat);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "LoginWechat", _m_LoginWechat);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "ShareUrl", _m_ShareUrl);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "ShareImage", _m_ShareImage);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "InitBaiduSDK", _m_InitBaiduSDK);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "RequestLocation", _m_RequestLocation);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetLocation", _m_GetLocation);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetInitParam", _m_GetInitParam);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "ClearInitParam", _m_ClearInitParam);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "CopyTextToClipboard", _m_CopyTextToClipboard);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetTextFromClipboard", _m_GetTextFromClipboard);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "IsPkgInstalled", _m_IsPkgInstalled);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetUnionDeviceId", _m_GetUnionDeviceId);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "InitIAP", _m_InitIAP);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "RequestIAP", _m_RequestIAP);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GotoWeChat", _m_GotoWeChat);
			
			
			
			
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 1, 1, 0);
			
			
            
			Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "instance", _g_get_instance);
            
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            return LuaAPI.luaL_error(L, "GameSDKInterface does not have a constructor!");
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetChannelName(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        string __cl_gen_ret = __cl_gen_to_be_invoked.GetChannelName(  );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetPackageBunldId(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        string __cl_gen_ret = __cl_gen_to_be_invoked.GetPackageBunldId(  );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetPlatformName(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        string __cl_gen_ret = __cl_gen_to_be_invoked.GetPlatformName(  );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ReadFileFromeAssets(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string fileName = LuaAPI.lua_tostring(L, 2);
                    
                        string __cl_gen_ret = __cl_gen_to_be_invoked.ReadFileFromeAssets( fileName );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_AssetsFileExist(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string fileName = LuaAPI.lua_tostring(L, 2);
                    
                        bool __cl_gen_ret = __cl_gen_to_be_invoked.AssetsFileExist( fileName );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_IsUseSdk(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        bool __cl_gen_ret = __cl_gen_to_be_invoked.IsUseSdk(  );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Init(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    __cl_gen_to_be_invoked.Init(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Login(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    __cl_gen_to_be_invoked.Login(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_LoginCustom(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string customData = LuaAPI.lua_tostring(L, 2);
                    
                    __cl_gen_to_be_invoked.LoginCustom( customData );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SwitchLogin(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    __cl_gen_to_be_invoked.SwitchLogin(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Logout(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        bool __cl_gen_ret = __cl_gen_to_be_invoked.Logout(  );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ShowAccountCenter(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        bool __cl_gen_ret = __cl_gen_to_be_invoked.ShowAccountCenter(  );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SubmitGameData(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    U8ExtraGameData data = (U8ExtraGameData)translator.GetObject(L, 2, typeof(U8ExtraGameData));
                    
                    __cl_gen_to_be_invoked.SubmitGameData( data );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SDKExit(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        bool __cl_gen_ret = __cl_gen_to_be_invoked.SDKExit(  );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Pay(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    U8PayParams data = (U8PayParams)translator.GetObject(L, 2, typeof(U8PayParams));
                    
                    __cl_gen_to_be_invoked.Pay( data );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_IsSupportExit(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        bool __cl_gen_ret = __cl_gen_to_be_invoked.IsSupportExit(  );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_IsSupportAccountCenter(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        bool __cl_gen_ret = __cl_gen_to_be_invoked.IsSupportAccountCenter(  );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_IsSupportLogout(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        bool __cl_gen_ret = __cl_gen_to_be_invoked.IsSupportLogout(  );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_RestartApplication(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        bool __cl_gen_ret = __cl_gen_to_be_invoked.RestartApplication(  );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetCountry(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        string __cl_gen_ret = __cl_gen_to_be_invoked.GetCountry(  );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetCarrier(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        string __cl_gen_ret = __cl_gen_to_be_invoked.GetCarrier(  );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetNewCarrier(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        string __cl_gen_ret = __cl_gen_to_be_invoked.GetNewCarrier(  );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetIDFA(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        string __cl_gen_ret = __cl_gen_to_be_invoked.GetIDFA(  );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetNativeAvatar(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    int size = LuaAPI.xlua_tointeger(L, 2);
                    
                    __cl_gen_to_be_invoked.GetNativeAvatar( size );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetVerify(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    SmsLoginPara loginpara = (SmsLoginPara)translator.GetObject(L, 2, typeof(SmsLoginPara));
                    
                    __cl_gen_to_be_invoked.GetVerify( loginpara );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SubmitVerify(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    SmsLoginPara loginpara = (SmsLoginPara)translator.GetObject(L, 2, typeof(SmsLoginPara));
                    
                    __cl_gen_to_be_invoked.SubmitVerify( loginpara );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ProcessIpAndAddressFamily(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string ipv4 = LuaAPI.lua_tostring(L, 2);
                    string newServerIp;
                    System.Net.Sockets.AddressFamily ipAddressFamily;
                    
                        bool __cl_gen_ret = __cl_gen_to_be_invoked.ProcessIpAndAddressFamily( ipv4, out newServerIp, out ipAddressFamily );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    LuaAPI.lua_pushstring(L, newServerIp);
                        
                    translator.Push(L, ipAddressFamily);
                        
                    
                    
                    
                    return 3;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ShareImageToWeixin(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    ShareWeixinPara data = (ShareWeixinPara)translator.GetObject(L, 2, typeof(ShareWeixinPara));
                    
                    __cl_gen_to_be_invoked.ShareImageToWeixin( data );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ShareTextToWeixin(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    ShareWeixinPara data = (ShareWeixinPara)translator.GetObject(L, 2, typeof(ShareWeixinPara));
                    
                    __cl_gen_to_be_invoked.ShareTextToWeixin( data );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ShareUrlToWeixin(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    ShareWeixinPara data = (ShareWeixinPara)translator.GetObject(L, 2, typeof(ShareWeixinPara));
                    
                    __cl_gen_to_be_invoked.ShareUrlToWeixin( data );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetCurSignalStrenth(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        int __cl_gen_ret = __cl_gen_to_be_invoked.GetCurSignalStrenth(  );
                        LuaAPI.xlua_pushinteger(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetCurSignalType(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        string __cl_gen_ret = __cl_gen_to_be_invoked.GetCurSignalType(  );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetCurBatteryLevel(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        int __cl_gen_ret = __cl_gen_to_be_invoked.GetCurBatteryLevel(  );
                        LuaAPI.xlua_pushinteger(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ShakePhone(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    long ms = LuaAPI.lua_toint64(L, 2);
                    
                    __cl_gen_to_be_invoked.ShakePhone( ms );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetCurChargeState(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        bool __cl_gen_ret = __cl_gen_to_be_invoked.GetCurChargeState(  );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_InitWechat(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string appid = LuaAPI.lua_tostring(L, 2);
                    
                    __cl_gen_to_be_invoked.InitWechat( appid );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_LoginWechat(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    __cl_gen_to_be_invoked.LoginWechat(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ShareUrl(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string json = LuaAPI.lua_tostring(L, 2);
                    
                    __cl_gen_to_be_invoked.ShareUrl( json );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ShareImage(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string json = LuaAPI.lua_tostring(L, 2);
                    
                    __cl_gen_to_be_invoked.ShareImage( json );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_InitBaiduSDK(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string appid = LuaAPI.lua_tostring(L, 2);
                    
                    __cl_gen_to_be_invoked.InitBaiduSDK( appid );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_RequestLocation(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    __cl_gen_to_be_invoked.RequestLocation(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetLocation(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        string __cl_gen_ret = __cl_gen_to_be_invoked.GetLocation(  );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetInitParam(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        string __cl_gen_ret = __cl_gen_to_be_invoked.GetInitParam(  );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ClearInitParam(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    __cl_gen_to_be_invoked.ClearInitParam(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_CopyTextToClipboard(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string str = LuaAPI.lua_tostring(L, 2);
                    
                        bool __cl_gen_ret = __cl_gen_to_be_invoked.CopyTextToClipboard( str );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetTextFromClipboard(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        string __cl_gen_ret = __cl_gen_to_be_invoked.GetTextFromClipboard(  );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_IsPkgInstalled(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string packageName = LuaAPI.lua_tostring(L, 2);
                    
                        bool __cl_gen_ret = __cl_gen_to_be_invoked.IsPkgInstalled( packageName );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetUnionDeviceId(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        string __cl_gen_ret = __cl_gen_to_be_invoked.GetUnionDeviceId(  );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_InitIAP(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string productsIdStr = LuaAPI.lua_tostring(L, 2);
                    
                    __cl_gen_to_be_invoked.InitIAP( productsIdStr );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_RequestIAP(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string productId = LuaAPI.lua_tostring(L, 2);
                    
                    __cl_gen_to_be_invoked.RequestIAP( productId );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GotoWeChat(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameSDKInterface __cl_gen_to_be_invoked = (GameSDKInterface)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    __cl_gen_to_be_invoked.GotoWeChat(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_instance(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, GameSDKInterface.instance);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        
        
		
		
		
		
    }
}
