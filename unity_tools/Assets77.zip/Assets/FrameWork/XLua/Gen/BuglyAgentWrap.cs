﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class BuglyAgentWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(BuglyAgent);
			Utils.BeginObjectRegister(type, L, translator, 0, 0, 0, 0);
			
			
			
			
			
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 17, 3, 0);
			Utils.RegisterFunc(L, Utils.CLS_IDX, "ConfigCrashReporter", _m_ConfigCrashReporter_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "InitWithAppId", _m_InitWithAppId_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "EnableExceptionHandler", _m_EnableExceptionHandler_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "RegisterLogCallback", _m_RegisterLogCallback_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "SetLogCallbackExtrasHandler", _m_SetLogCallbackExtrasHandler_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "ReportException", _m_ReportException_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "UnregisterLogCallback", _m_UnregisterLogCallback_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "SetUserId", _m_SetUserId_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "SetScene", _m_SetScene_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "AddSceneData", _m_AddSceneData_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "ConfigDebugMode", _m_ConfigDebugMode_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "ConfigAutoQuitApplication", _m_ConfigAutoQuitApplication_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "ConfigAutoReportLogLevel", _m_ConfigAutoReportLogLevel_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "ConfigDefault", _m_ConfigDefault_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "DebugLog", _m_DebugLog_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "PrintLog", _m_PrintLog_xlua_st_);
            
			
            
			Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "PluginVersion", _g_get_PluginVersion);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "IsInitialized", _g_get_IsInitialized);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "AutoQuitApplicationAfterReport", _g_get_AutoQuitApplicationAfterReport);
            
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					BuglyAgent __cl_gen_ret = new BuglyAgent();
					translator.Push(L, __cl_gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception __gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to BuglyAgent constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ConfigCrashReporter_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    int type = LuaAPI.xlua_tointeger(L, 1);
                    int logLevel = LuaAPI.xlua_tointeger(L, 2);
                    
                    BuglyAgent.ConfigCrashReporter( type, logLevel );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_InitWithAppId_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string appId = LuaAPI.lua_tostring(L, 1);
                    
                    BuglyAgent.InitWithAppId( appId );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_EnableExceptionHandler_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    
                    BuglyAgent.EnableExceptionHandler(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_RegisterLogCallback_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    BuglyAgent.LogCallbackDelegate handler = translator.GetDelegate<BuglyAgent.LogCallbackDelegate>(L, 1);
                    
                    BuglyAgent.RegisterLogCallback( handler );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SetLogCallbackExtrasHandler_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    System.Func<System.Collections.Generic.Dictionary<string, string>> handler = translator.GetDelegate<System.Func<System.Collections.Generic.Dictionary<string, string>>>(L, 1);
                    
                    BuglyAgent.SetLogCallbackExtrasHandler( handler );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ReportException_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
			    int __gen_param_count = LuaAPI.lua_gettop(L);
            
                if(__gen_param_count == 2&& translator.Assignable<System.Exception>(L, 1)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)) 
                {
                    System.Exception e = (System.Exception)translator.GetObject(L, 1, typeof(System.Exception));
                    string message = LuaAPI.lua_tostring(L, 2);
                    
                    BuglyAgent.ReportException( e, message );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 3&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)) 
                {
                    string name = LuaAPI.lua_tostring(L, 1);
                    string message = LuaAPI.lua_tostring(L, 2);
                    string stackTrace = LuaAPI.lua_tostring(L, 3);
                    
                    BuglyAgent.ReportException( name, message, stackTrace );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to BuglyAgent.ReportException!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_UnregisterLogCallback_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    BuglyAgent.LogCallbackDelegate handler = translator.GetDelegate<BuglyAgent.LogCallbackDelegate>(L, 1);
                    
                    BuglyAgent.UnregisterLogCallback( handler );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SetUserId_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string userId = LuaAPI.lua_tostring(L, 1);
                    
                    BuglyAgent.SetUserId( userId );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SetScene_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    int sceneId = LuaAPI.xlua_tointeger(L, 1);
                    
                    BuglyAgent.SetScene( sceneId );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_AddSceneData_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string key = LuaAPI.lua_tostring(L, 1);
                    string value = LuaAPI.lua_tostring(L, 2);
                    
                    BuglyAgent.AddSceneData( key, value );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ConfigDebugMode_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    bool enable = LuaAPI.lua_toboolean(L, 1);
                    
                    BuglyAgent.ConfigDebugMode( enable );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ConfigAutoQuitApplication_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    bool autoQuit = LuaAPI.lua_toboolean(L, 1);
                    
                    BuglyAgent.ConfigAutoQuitApplication( autoQuit );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ConfigAutoReportLogLevel_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    LogSeverity level;translator.Get(L, 1, out level);
                    
                    BuglyAgent.ConfigAutoReportLogLevel( level );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ConfigDefault_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string channel = LuaAPI.lua_tostring(L, 1);
                    string version = LuaAPI.lua_tostring(L, 2);
                    string user = LuaAPI.lua_tostring(L, 3);
                    long delay = LuaAPI.lua_toint64(L, 4);
                    
                    BuglyAgent.ConfigDefault( channel, version, user, delay );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_DebugLog_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    string tag = LuaAPI.lua_tostring(L, 1);
                    string format = LuaAPI.lua_tostring(L, 2);
                    object[] args = translator.GetParams<object>(L, 3);
                    
                    BuglyAgent.DebugLog( tag, format, args );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_PrintLog_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    LogSeverity level;translator.Get(L, 1, out level);
                    string format = LuaAPI.lua_tostring(L, 2);
                    object[] args = translator.GetParams<object>(L, 3);
                    
                    BuglyAgent.PrintLog( level, format, args );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_PluginVersion(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, BuglyAgent.PluginVersion);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_IsInitialized(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushboolean(L, BuglyAgent.IsInitialized);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_AutoQuitApplicationAfterReport(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushboolean(L, BuglyAgent.AutoQuitApplicationAfterReport);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        
        
		
		
		
		
    }
}
