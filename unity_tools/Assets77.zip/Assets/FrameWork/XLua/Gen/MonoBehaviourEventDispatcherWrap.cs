﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class MonoBehaviourEventDispatcherWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(MonoBehaviourEventDispatcher);
			Utils.BeginObjectRegister(type, L, translator, 0, 2, 11, 11);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "RemoveAllEvents", _m_RemoveAllEvents);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Clone", _m_Clone);
			
			
			Utils.RegisterFunc(L, Utils.GETTER_IDX, "onAwakeFn", _g_get_onAwakeFn);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "onStartFn", _g_get_onStartFn);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "onUpdateFn", _g_get_onUpdateFn);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "onFixedUpdateFn", _g_get_onFixedUpdateFn);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "onLateUpdateFn", _g_get_onLateUpdateFn);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "onOnDisableFn", _g_get_onOnDisableFn);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "onOnEnableFn", _g_get_onOnEnableFn);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "onOnDestroyFn", _g_get_onOnDestroyFn);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "onOnApplicationFocusFn", _g_get_onOnApplicationFocusFn);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "onOnApplicationPauseFn", _g_get_onOnApplicationPauseFn);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "onOnApplicationQuitFn", _g_get_onOnApplicationQuitFn);
            
			Utils.RegisterFunc(L, Utils.SETTER_IDX, "onAwakeFn", _s_set_onAwakeFn);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "onStartFn", _s_set_onStartFn);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "onUpdateFn", _s_set_onUpdateFn);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "onFixedUpdateFn", _s_set_onFixedUpdateFn);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "onLateUpdateFn", _s_set_onLateUpdateFn);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "onOnDisableFn", _s_set_onOnDisableFn);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "onOnEnableFn", _s_set_onOnEnableFn);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "onOnDestroyFn", _s_set_onOnDestroyFn);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "onOnApplicationFocusFn", _s_set_onOnApplicationFocusFn);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "onOnApplicationPauseFn", _s_set_onOnApplicationPauseFn);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "onOnApplicationQuitFn", _s_set_onOnApplicationQuitFn);
            
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 1, 0, 0);
			
			
            
			
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					MonoBehaviourEventDispatcher __cl_gen_ret = new MonoBehaviourEventDispatcher();
					translator.Push(L, __cl_gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception __gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to MonoBehaviourEventDispatcher constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_RemoveAllEvents(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    __cl_gen_to_be_invoked.RemoveAllEvents(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Clone(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        UnityEngine.MonoBehaviour __cl_gen_ret = __cl_gen_to_be_invoked.Clone(  );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_onAwakeFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                translator.Push(L, __cl_gen_to_be_invoked.onAwakeFn);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_onStartFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                translator.Push(L, __cl_gen_to_be_invoked.onStartFn);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_onUpdateFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                translator.Push(L, __cl_gen_to_be_invoked.onUpdateFn);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_onFixedUpdateFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                translator.Push(L, __cl_gen_to_be_invoked.onFixedUpdateFn);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_onLateUpdateFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                translator.Push(L, __cl_gen_to_be_invoked.onLateUpdateFn);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_onOnDisableFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                translator.Push(L, __cl_gen_to_be_invoked.onOnDisableFn);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_onOnEnableFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                translator.Push(L, __cl_gen_to_be_invoked.onOnEnableFn);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_onOnDestroyFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                translator.Push(L, __cl_gen_to_be_invoked.onOnDestroyFn);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_onOnApplicationFocusFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                translator.Push(L, __cl_gen_to_be_invoked.onOnApplicationFocusFn);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_onOnApplicationPauseFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                translator.Push(L, __cl_gen_to_be_invoked.onOnApplicationPauseFn);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_onOnApplicationQuitFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                translator.Push(L, __cl_gen_to_be_invoked.onOnApplicationQuitFn);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_onAwakeFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.onAwakeFn = translator.GetDelegate<System.Action>(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_onStartFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.onStartFn = translator.GetDelegate<System.Action>(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_onUpdateFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.onUpdateFn = translator.GetDelegate<System.Action>(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_onFixedUpdateFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.onFixedUpdateFn = translator.GetDelegate<System.Action>(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_onLateUpdateFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.onLateUpdateFn = translator.GetDelegate<System.Action>(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_onOnDisableFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.onOnDisableFn = translator.GetDelegate<System.Action>(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_onOnEnableFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.onOnEnableFn = translator.GetDelegate<System.Action>(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_onOnDestroyFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.onOnDestroyFn = translator.GetDelegate<System.Action>(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_onOnApplicationFocusFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.onOnApplicationFocusFn = translator.GetDelegate<System.Action<bool>>(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_onOnApplicationPauseFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.onOnApplicationPauseFn = translator.GetDelegate<System.Action<bool>>(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_onOnApplicationQuitFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MonoBehaviourEventDispatcher __cl_gen_to_be_invoked = (MonoBehaviourEventDispatcher)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.onOnApplicationQuitFn = translator.GetDelegate<System.Action>(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
