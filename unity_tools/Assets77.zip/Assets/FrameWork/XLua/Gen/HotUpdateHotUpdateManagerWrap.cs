﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class HotUpdateHotUpdateManagerWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(HotUpdate.HotUpdateManager);
			Utils.BeginObjectRegister(type, L, translator, 0, 5, 4, 0);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "SetUpdateProjectName", _m_SetUpdateProjectName);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetProjectVersion", _m_GetProjectVersion);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "TryUpdateAllAssetFromStreamingAssets", _m_TryUpdateAllAssetFromStreamingAssets);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "TryStartUpdateRemoteAssetsToLocal", _m_TryStartUpdateRemoteAssetsToLocal);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Clone", _m_Clone);
			
			
			Utils.RegisterFunc(L, Utils.GETTER_IDX, "IsWorking", _g_get_IsWorking);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "IsLoadedNewAsset", _g_get_IsLoadedNewAsset);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "IsValidatedAssets", _g_get_IsValidatedAssets);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "UpdaterState", _g_get_UpdaterState);
            
			
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 8, 6, 5);
			Utils.RegisterFunc(L, Utils.CLS_IDX, "GetFormatedVersionFileName", _m_GetFormatedVersionFileName_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "GetFormatedFileRecordFileName", _m_GetFormatedFileRecordFileName_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "CheckVersion", _m_CheckVersion_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "ConvertToFileRecords", _m_ConvertToFileRecords_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "FilterObsoleteFileRecodes", _m_FilterObsoleteFileRecodes_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "FilterNeedUpdateFileRecodes", _m_FilterNeedUpdateFileRecodes_xlua_st_);
            
			
            Utils.RegisterObject(L, translator, Utils.CLS_IDX, "DEFAULT_VERSION", HotUpdate.HotUpdateManager.DEFAULT_VERSION);
            
			Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "HallVersionFileName", _g_get_HallVersionFileName);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "OnHotUpdateProgressChanged", _g_get_OnHotUpdateProgressChanged);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "OnHotUpdateComplated", _g_get_OnHotUpdateComplated);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "OnHotUpdateFail", _g_get_OnHotUpdateFail);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "OnHotUpdateFailClose", _g_get_OnHotUpdateFailClose);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "OnHotUpdateCantContinue", _g_get_OnHotUpdateCantContinue);
            
			Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "OnHotUpdateProgressChanged", _s_set_OnHotUpdateProgressChanged);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "OnHotUpdateComplated", _s_set_OnHotUpdateComplated);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "OnHotUpdateFail", _s_set_OnHotUpdateFail);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "OnHotUpdateFailClose", _s_set_OnHotUpdateFailClose);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "OnHotUpdateCantContinue", _s_set_OnHotUpdateCantContinue);
            
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					HotUpdate.HotUpdateManager __cl_gen_ret = new HotUpdate.HotUpdateManager();
					translator.Push(L, __cl_gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception __gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to HotUpdate.HotUpdateManager constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SetUpdateProjectName(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                HotUpdate.HotUpdateManager __cl_gen_to_be_invoked = (HotUpdate.HotUpdateManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string projectName = LuaAPI.lua_tostring(L, 2);
                    
                    __cl_gen_to_be_invoked.SetUpdateProjectName( projectName );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetProjectVersion(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                HotUpdate.HotUpdateManager __cl_gen_to_be_invoked = (HotUpdate.HotUpdateManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string projectName = LuaAPI.lua_tostring(L, 2);
                    
                        string __cl_gen_ret = __cl_gen_to_be_invoked.GetProjectVersion( projectName );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetFormatedVersionFileName_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string projectName = LuaAPI.lua_tostring(L, 1);
                    
                        string __cl_gen_ret = HotUpdate.HotUpdateManager.GetFormatedVersionFileName( projectName );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetFormatedFileRecordFileName_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string projectName = LuaAPI.lua_tostring(L, 1);
                    
                        string __cl_gen_ret = HotUpdate.HotUpdateManager.GetFormatedFileRecordFileName( projectName );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_TryUpdateAllAssetFromStreamingAssets(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                HotUpdate.HotUpdateManager __cl_gen_to_be_invoked = (HotUpdate.HotUpdateManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        System.Collections.IEnumerator __cl_gen_ret = __cl_gen_to_be_invoked.TryUpdateAllAssetFromStreamingAssets(  );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_TryStartUpdateRemoteAssetsToLocal(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                HotUpdate.HotUpdateManager __cl_gen_to_be_invoked = (HotUpdate.HotUpdateManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    __cl_gen_to_be_invoked.TryStartUpdateRemoteAssetsToLocal(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_CheckVersion_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string newVersionStr = LuaAPI.lua_tostring(L, 1);
                    string oldVersionStr = LuaAPI.lua_tostring(L, 2);
                    
                        int __cl_gen_ret = HotUpdate.HotUpdateManager.CheckVersion( newVersionStr, oldVersionStr );
                        LuaAPI.xlua_pushinteger(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ConvertToFileRecords_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    string content = LuaAPI.lua_tostring(L, 1);
                    
                        System.Collections.Generic.Dictionary<string, FileRecord> __cl_gen_ret = HotUpdate.HotUpdateManager.ConvertToFileRecords( content );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_FilterObsoleteFileRecodes_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    System.Collections.Generic.Dictionary<string, FileRecord> newFileRecords = (System.Collections.Generic.Dictionary<string, FileRecord>)translator.GetObject(L, 1, typeof(System.Collections.Generic.Dictionary<string, FileRecord>));
                    System.Collections.Generic.Dictionary<string, FileRecord> oldFileRecords = (System.Collections.Generic.Dictionary<string, FileRecord>)translator.GetObject(L, 2, typeof(System.Collections.Generic.Dictionary<string, FileRecord>));
                    
                        System.Collections.Generic.List<FileRecord> __cl_gen_ret = HotUpdate.HotUpdateManager.FilterObsoleteFileRecodes( newFileRecords, oldFileRecords );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_FilterNeedUpdateFileRecodes_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    System.Collections.Generic.Dictionary<string, FileRecord> newFileRecords = (System.Collections.Generic.Dictionary<string, FileRecord>)translator.GetObject(L, 1, typeof(System.Collections.Generic.Dictionary<string, FileRecord>));
                    System.Collections.Generic.Dictionary<string, FileRecord> oldFileRecords = (System.Collections.Generic.Dictionary<string, FileRecord>)translator.GetObject(L, 2, typeof(System.Collections.Generic.Dictionary<string, FileRecord>));
                    
                        System.Collections.Generic.List<FileRecord> __cl_gen_ret = HotUpdate.HotUpdateManager.FilterNeedUpdateFileRecodes( newFileRecords, oldFileRecords );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Clone(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                HotUpdate.HotUpdateManager __cl_gen_to_be_invoked = (HotUpdate.HotUpdateManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        UnityEngine.MonoBehaviour __cl_gen_ret = __cl_gen_to_be_invoked.Clone(  );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_IsWorking(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                HotUpdate.HotUpdateManager __cl_gen_to_be_invoked = (HotUpdate.HotUpdateManager)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushboolean(L, __cl_gen_to_be_invoked.IsWorking);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_IsLoadedNewAsset(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                HotUpdate.HotUpdateManager __cl_gen_to_be_invoked = (HotUpdate.HotUpdateManager)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushboolean(L, __cl_gen_to_be_invoked.IsLoadedNewAsset);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_IsValidatedAssets(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                HotUpdate.HotUpdateManager __cl_gen_to_be_invoked = (HotUpdate.HotUpdateManager)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushboolean(L, __cl_gen_to_be_invoked.IsValidatedAssets);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_UpdaterState(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                HotUpdate.HotUpdateManager __cl_gen_to_be_invoked = (HotUpdate.HotUpdateManager)translator.FastGetCSObj(L, 1);
                translator.Push(L, __cl_gen_to_be_invoked.UpdaterState);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_HallVersionFileName(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, HotUpdate.HotUpdateManager.HallVersionFileName);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_OnHotUpdateProgressChanged(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, HotUpdate.HotUpdateManager.OnHotUpdateProgressChanged);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_OnHotUpdateComplated(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, HotUpdate.HotUpdateManager.OnHotUpdateComplated);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_OnHotUpdateFail(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, HotUpdate.HotUpdateManager.OnHotUpdateFail);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_OnHotUpdateFailClose(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, HotUpdate.HotUpdateManager.OnHotUpdateFailClose);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_OnHotUpdateCantContinue(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, HotUpdate.HotUpdateManager.OnHotUpdateCantContinue);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_OnHotUpdateProgressChanged(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    HotUpdate.HotUpdateManager.OnHotUpdateProgressChanged = translator.GetDelegate<System.Action<HotUpdate.UpdateProgressInfo>>(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_OnHotUpdateComplated(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    HotUpdate.HotUpdateManager.OnHotUpdateComplated = translator.GetDelegate<System.Action>(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_OnHotUpdateFail(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    HotUpdate.HotUpdateManager.OnHotUpdateFail = translator.GetDelegate<System.Action>(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_OnHotUpdateFailClose(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    HotUpdate.HotUpdateManager.OnHotUpdateFailClose = translator.GetDelegate<System.Action>(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_OnHotUpdateCantContinue(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    HotUpdate.HotUpdateManager.OnHotUpdateCantContinue = translator.GetDelegate<System.Action>(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
