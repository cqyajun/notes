﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class UIMessageBoxWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(UIMessageBox);
			Utils.BeginObjectRegister(type, L, translator, 0, 3, 0, 0);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "RefreshWindowData", _m_RefreshWindowData);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "EscapeWindow", _m_EscapeWindow);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Clone", _m_Clone);
			
			
			
			
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 4, 0, 0);
			Utils.RegisterFunc(L, Utils.CLS_IDX, "Show", _m_Show_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "Hide", _m_Hide_xlua_st_);
            
			
            Utils.RegisterObject(L, translator, Utils.CLS_IDX, "UIAssetName", UIMessageBox.UIAssetName);
            
			
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					UIMessageBox __cl_gen_ret = new UIMessageBox();
					translator.Push(L, __cl_gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception __gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to UIMessageBox constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_RefreshWindowData(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                UIMessageBox __cl_gen_to_be_invoked = (UIMessageBox)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    object windowData = translator.GetObject(L, 2, typeof(object));
                    
                    __cl_gen_to_be_invoked.RefreshWindowData( windowData );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Show_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
			    int __gen_param_count = LuaAPI.lua_gettop(L);
            
                if(__gen_param_count == 2&& translator.Assignable<MessageBoxData>(L, 1)&& translator.Assignable<WindowNode>(L, 2)) 
                {
                    MessageBoxData uiData = (MessageBoxData)translator.GetObject(L, 1, typeof(MessageBoxData));
                    WindowNode parent = (WindowNode)translator.GetObject(L, 2, typeof(WindowNode));
                    
                    UIMessageBox.Show( uiData, parent );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 1&& translator.Assignable<MessageBoxData>(L, 1)) 
                {
                    MessageBoxData uiData = (MessageBoxData)translator.GetObject(L, 1, typeof(MessageBoxData));
                    
                    UIMessageBox.Show( uiData );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 4&& translator.Assignable<MessageBoxStyle>(L, 1)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Action<MessageBoxResult>>(L, 4)) 
                {
                    MessageBoxStyle style;translator.Get(L, 1, out style);
                    string title = LuaAPI.lua_tostring(L, 2);
                    string content = LuaAPI.lua_tostring(L, 3);
                    System.Action<MessageBoxResult> callBack = translator.GetDelegate<System.Action<MessageBoxResult>>(L, 4);
                    
                    UIMessageBox.Show( style, title, content, callBack );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 3&& translator.Assignable<MessageBoxStyle>(L, 1)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)) 
                {
                    MessageBoxStyle style;translator.Get(L, 1, out style);
                    string title = LuaAPI.lua_tostring(L, 2);
                    string content = LuaAPI.lua_tostring(L, 3);
                    
                    UIMessageBox.Show( style, title, content );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 5&& translator.Assignable<MessageBoxStyle>(L, 1)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 4)&& translator.Assignable<System.Action<MessageBoxResult>>(L, 5)) 
                {
                    MessageBoxStyle style;translator.Get(L, 1, out style);
                    string title = LuaAPI.lua_tostring(L, 2);
                    string content = LuaAPI.lua_tostring(L, 3);
                    int lastTime = LuaAPI.xlua_tointeger(L, 4);
                    System.Action<MessageBoxResult> callBack = translator.GetDelegate<System.Action<MessageBoxResult>>(L, 5);
                    
                    UIMessageBox.Show( style, title, content, lastTime, callBack );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 4&& translator.Assignable<MessageBoxStyle>(L, 1)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 4)) 
                {
                    MessageBoxStyle style;translator.Get(L, 1, out style);
                    string title = LuaAPI.lua_tostring(L, 2);
                    string content = LuaAPI.lua_tostring(L, 3);
                    int lastTime = LuaAPI.xlua_tointeger(L, 4);
                    
                    UIMessageBox.Show( style, title, content, lastTime );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 5&& translator.Assignable<MessageBoxStyle>(L, 1)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Action<MessageBoxResult>>(L, 5)) 
                {
                    MessageBoxStyle style;translator.Get(L, 1, out style);
                    string title = LuaAPI.lua_tostring(L, 2);
                    string content = LuaAPI.lua_tostring(L, 3);
                    string okButtonText = LuaAPI.lua_tostring(L, 4);
                    System.Action<MessageBoxResult> callBack = translator.GetDelegate<System.Action<MessageBoxResult>>(L, 5);
                    
                    UIMessageBox.Show( style, title, content, okButtonText, callBack );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 4&& translator.Assignable<MessageBoxStyle>(L, 1)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)) 
                {
                    MessageBoxStyle style;translator.Get(L, 1, out style);
                    string title = LuaAPI.lua_tostring(L, 2);
                    string content = LuaAPI.lua_tostring(L, 3);
                    string okButtonText = LuaAPI.lua_tostring(L, 4);
                    
                    UIMessageBox.Show( style, title, content, okButtonText );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 6&& translator.Assignable<MessageBoxStyle>(L, 1)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 5)&& translator.Assignable<System.Action<MessageBoxResult>>(L, 6)) 
                {
                    MessageBoxStyle style;translator.Get(L, 1, out style);
                    string title = LuaAPI.lua_tostring(L, 2);
                    string content = LuaAPI.lua_tostring(L, 3);
                    string okButtonText = LuaAPI.lua_tostring(L, 4);
                    int lastTime = LuaAPI.xlua_tointeger(L, 5);
                    System.Action<MessageBoxResult> callBack = translator.GetDelegate<System.Action<MessageBoxResult>>(L, 6);
                    
                    UIMessageBox.Show( style, title, content, okButtonText, lastTime, callBack );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 5&& translator.Assignable<MessageBoxStyle>(L, 1)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 5)) 
                {
                    MessageBoxStyle style;translator.Get(L, 1, out style);
                    string title = LuaAPI.lua_tostring(L, 2);
                    string content = LuaAPI.lua_tostring(L, 3);
                    string okButtonText = LuaAPI.lua_tostring(L, 4);
                    int lastTime = LuaAPI.xlua_tointeger(L, 5);
                    
                    UIMessageBox.Show( style, title, content, okButtonText, lastTime );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 6&& translator.Assignable<MessageBoxStyle>(L, 1)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 5) || LuaAPI.lua_type(L, 5) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Action<MessageBoxResult>>(L, 6)) 
                {
                    MessageBoxStyle style;translator.Get(L, 1, out style);
                    string title = LuaAPI.lua_tostring(L, 2);
                    string content = LuaAPI.lua_tostring(L, 3);
                    string okButtonText = LuaAPI.lua_tostring(L, 4);
                    string cancelButtonText = LuaAPI.lua_tostring(L, 5);
                    System.Action<MessageBoxResult> callBack = translator.GetDelegate<System.Action<MessageBoxResult>>(L, 6);
                    
                    UIMessageBox.Show( style, title, content, okButtonText, cancelButtonText, callBack );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 5&& translator.Assignable<MessageBoxStyle>(L, 1)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 5) || LuaAPI.lua_type(L, 5) == LuaTypes.LUA_TSTRING)) 
                {
                    MessageBoxStyle style;translator.Get(L, 1, out style);
                    string title = LuaAPI.lua_tostring(L, 2);
                    string content = LuaAPI.lua_tostring(L, 3);
                    string okButtonText = LuaAPI.lua_tostring(L, 4);
                    string cancelButtonText = LuaAPI.lua_tostring(L, 5);
                    
                    UIMessageBox.Show( style, title, content, okButtonText, cancelButtonText );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 7&& translator.Assignable<MessageBoxStyle>(L, 1)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 5) || LuaAPI.lua_type(L, 5) == LuaTypes.LUA_TSTRING)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 6)&& translator.Assignable<System.Action<MessageBoxResult>>(L, 7)) 
                {
                    MessageBoxStyle style;translator.Get(L, 1, out style);
                    string title = LuaAPI.lua_tostring(L, 2);
                    string content = LuaAPI.lua_tostring(L, 3);
                    string okButtonText = LuaAPI.lua_tostring(L, 4);
                    string cancelButtonText = LuaAPI.lua_tostring(L, 5);
                    int lastTime = LuaAPI.xlua_tointeger(L, 6);
                    System.Action<MessageBoxResult> callBack = translator.GetDelegate<System.Action<MessageBoxResult>>(L, 7);
                    
                    UIMessageBox.Show( style, title, content, okButtonText, cancelButtonText, lastTime, callBack );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 6&& translator.Assignable<MessageBoxStyle>(L, 1)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 5) || LuaAPI.lua_type(L, 5) == LuaTypes.LUA_TSTRING)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 6)) 
                {
                    MessageBoxStyle style;translator.Get(L, 1, out style);
                    string title = LuaAPI.lua_tostring(L, 2);
                    string content = LuaAPI.lua_tostring(L, 3);
                    string okButtonText = LuaAPI.lua_tostring(L, 4);
                    string cancelButtonText = LuaAPI.lua_tostring(L, 5);
                    int lastTime = LuaAPI.xlua_tointeger(L, 6);
                    
                    UIMessageBox.Show( style, title, content, okButtonText, cancelButtonText, lastTime );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to UIMessageBox.Show!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Hide_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    
                    UIMessageBox.Hide(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_EscapeWindow(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                UIMessageBox __cl_gen_to_be_invoked = (UIMessageBox)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    __cl_gen_to_be_invoked.EscapeWindow(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Clone(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                UIMessageBox __cl_gen_to_be_invoked = (UIMessageBox)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        UnityEngine.MonoBehaviour __cl_gen_ret = __cl_gen_to_be_invoked.Clone(  );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        
        
        
        
        
		
		
		
		
    }
}
