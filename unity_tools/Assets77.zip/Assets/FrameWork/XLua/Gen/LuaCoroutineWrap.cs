﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class LuaCoroutineWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(LuaCoroutine);
			Utils.BeginObjectRegister(type, L, translator, 0, 11, 0, 0);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "StartCountDown", _m_StartCountDown);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "RemoveCountDown", _m_RemoveCountDown);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "InvokeRepeating", _m_InvokeRepeating);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "CancelInvokeRepeat", _m_CancelInvokeRepeat);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "StopAllRepeatInvoke", _m_StopAllRepeatInvoke);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "DelayInvoke", _m_DelayInvoke);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "StopDelayInvoke", _m_StopDelayInvoke);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "StopAllDelayInvoke", _m_StopAllDelayInvoke);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "YieldAndCallback", _m_YieldAndCallback);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "StopAllCoroutines", _m_StopAllCoroutines);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Clone", _m_Clone);
			
			
			
			
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 1, 0, 0);
			
			
            
			
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					LuaCoroutine __cl_gen_ret = new LuaCoroutine();
					translator.Push(L, __cl_gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception __gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to LuaCoroutine constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_StartCountDown(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                LuaCoroutine __cl_gen_to_be_invoked = (LuaCoroutine)translator.FastGetCSObj(L, 1);
            
            
			    int __gen_param_count = LuaAPI.lua_gettop(L);
            
                if(__gen_param_count == 5&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 2)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Action<float>>(L, 4)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 5)) 
                {
                    float countDown = (float)LuaAPI.lua_tonumber(L, 2);
                    string keyName = LuaAPI.lua_tostring(L, 3);
                    System.Action<float> updateCallBack = translator.GetDelegate<System.Action<float>>(L, 4);
                    float notifyInterval = (float)LuaAPI.lua_tonumber(L, 5);
                    
                    __cl_gen_to_be_invoked.StartCountDown( countDown, keyName, updateCallBack, notifyInterval );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 4&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 2)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Action<float>>(L, 4)) 
                {
                    float countDown = (float)LuaAPI.lua_tonumber(L, 2);
                    string keyName = LuaAPI.lua_tostring(L, 3);
                    System.Action<float> updateCallBack = translator.GetDelegate<System.Action<float>>(L, 4);
                    
                    __cl_gen_to_be_invoked.StartCountDown( countDown, keyName, updateCallBack );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to LuaCoroutine.StartCountDown!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_RemoveCountDown(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                LuaCoroutine __cl_gen_to_be_invoked = (LuaCoroutine)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string keyName = LuaAPI.lua_tostring(L, 2);
                    
                    __cl_gen_to_be_invoked.RemoveCountDown( keyName );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_InvokeRepeating(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                LuaCoroutine __cl_gen_to_be_invoked = (LuaCoroutine)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    System.Action repeatAction = translator.GetDelegate<System.Action>(L, 2);
                    float time = (float)LuaAPI.lua_tonumber(L, 3);
                    float repeatRate = (float)LuaAPI.lua_tonumber(L, 4);
                    
                    __cl_gen_to_be_invoked.InvokeRepeating( repeatAction, time, repeatRate );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_CancelInvokeRepeat(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                LuaCoroutine __cl_gen_to_be_invoked = (LuaCoroutine)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    System.Action repeatAction = translator.GetDelegate<System.Action>(L, 2);
                    
                    __cl_gen_to_be_invoked.CancelInvokeRepeat( repeatAction );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_StopAllRepeatInvoke(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                LuaCoroutine __cl_gen_to_be_invoked = (LuaCoroutine)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    __cl_gen_to_be_invoked.StopAllRepeatInvoke(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_DelayInvoke(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                LuaCoroutine __cl_gen_to_be_invoked = (LuaCoroutine)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    float delayTime = (float)LuaAPI.lua_tonumber(L, 2);
                    System.Action callBack = translator.GetDelegate<System.Action>(L, 3);
                    
                        int __cl_gen_ret = __cl_gen_to_be_invoked.DelayInvoke( delayTime, callBack );
                        LuaAPI.xlua_pushinteger(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_StopDelayInvoke(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                LuaCoroutine __cl_gen_to_be_invoked = (LuaCoroutine)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    int delayID = LuaAPI.xlua_tointeger(L, 2);
                    
                    __cl_gen_to_be_invoked.StopDelayInvoke( delayID );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_StopAllDelayInvoke(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                LuaCoroutine __cl_gen_to_be_invoked = (LuaCoroutine)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    __cl_gen_to_be_invoked.StopAllDelayInvoke(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_YieldAndCallback(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                LuaCoroutine __cl_gen_to_be_invoked = (LuaCoroutine)translator.FastGetCSObj(L, 1);
            
            
			    int __gen_param_count = LuaAPI.lua_gettop(L);
            
                if(__gen_param_count == 3&& translator.Assignable<object>(L, 2)&& translator.Assignable<System.Action>(L, 3)) 
                {
                    object to_yield = translator.GetObject(L, 2, typeof(object));
                    System.Action callback = translator.GetDelegate<System.Action>(L, 3);
                    
                    __cl_gen_to_be_invoked.YieldAndCallback( to_yield, callback );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 4&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<object>(L, 3)&& translator.Assignable<System.Action>(L, 4)) 
                {
                    string sign = LuaAPI.lua_tostring(L, 2);
                    object to_yield = translator.GetObject(L, 3, typeof(object));
                    System.Action callback = translator.GetDelegate<System.Action>(L, 4);
                    
                    __cl_gen_to_be_invoked.YieldAndCallback( sign, to_yield, callback );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to LuaCoroutine.YieldAndCallback!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_StopAllCoroutines(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                LuaCoroutine __cl_gen_to_be_invoked = (LuaCoroutine)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string sign = LuaAPI.lua_tostring(L, 2);
                    
                    __cl_gen_to_be_invoked.StopAllCoroutines( sign );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Clone(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                LuaCoroutine __cl_gen_to_be_invoked = (LuaCoroutine)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        UnityEngine.MonoBehaviour __cl_gen_ret = __cl_gen_to_be_invoked.Clone(  );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        
        
        
        
        
		
		
		
		
    }
}
