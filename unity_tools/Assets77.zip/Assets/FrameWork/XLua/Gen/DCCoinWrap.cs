﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class DCCoinWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(DCCoin);
			Utils.BeginObjectRegister(type, L, translator, 0, 0, 0, 0);
			
			
			
			
			
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 6, 0, 0);
			Utils.RegisterFunc(L, Utils.CLS_IDX, "setCoinNum", _m_setCoinNum_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "lost", _m_lost_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "lostInLevel", _m_lostInLevel_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "gain", _m_gain_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "gainInLevel", _m_gainInLevel_xlua_st_);
            
			
            
			
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					DCCoin __cl_gen_ret = new DCCoin();
					translator.Push(L, __cl_gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception __gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to DCCoin constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_setCoinNum_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    long num = LuaAPI.lua_toint64(L, 1);
                    string coinType = LuaAPI.lua_tostring(L, 2);
                    
                    DCCoin.setCoinNum( num, coinType );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_lost_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string id = LuaAPI.lua_tostring(L, 1);
                    string coinType = LuaAPI.lua_tostring(L, 2);
                    long lost = LuaAPI.lua_toint64(L, 3);
                    long left = LuaAPI.lua_toint64(L, 4);
                    
                    DCCoin.lost( id, coinType, lost, left );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_lostInLevel_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string id = LuaAPI.lua_tostring(L, 1);
                    string coinType = LuaAPI.lua_tostring(L, 2);
                    long lost = LuaAPI.lua_toint64(L, 3);
                    long left = LuaAPI.lua_toint64(L, 4);
                    string levelId = LuaAPI.lua_tostring(L, 5);
                    
                    DCCoin.lostInLevel( id, coinType, lost, left, levelId );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_gain_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string id = LuaAPI.lua_tostring(L, 1);
                    string coinType = LuaAPI.lua_tostring(L, 2);
                    long gain = LuaAPI.lua_toint64(L, 3);
                    long left = LuaAPI.lua_toint64(L, 4);
                    
                    DCCoin.gain( id, coinType, gain, left );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_gainInLevel_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string id = LuaAPI.lua_tostring(L, 1);
                    string coinType = LuaAPI.lua_tostring(L, 2);
                    long gain = LuaAPI.lua_toint64(L, 3);
                    long left = LuaAPI.lua_toint64(L, 4);
                    string levelId = LuaAPI.lua_tostring(L, 5);
                    
                    DCCoin.gainInLevel( id, coinType, gain, left, levelId );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        
        
        
        
        
		
		
		
		
    }
}
