﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class CustomerUtilWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(CustomerUtil);
			Utils.BeginObjectRegister(type, L, translator, 0, 0, 0, 0);
			
			
			
			
			
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 23, 0, 0);
			Utils.RegisterFunc(L, Utils.CLS_IDX, "ReloadCurScene", _m_ReloadCurScene_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "UnloadUnusedAssets", _m_UnloadUnusedAssets_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "CaptureCamera", _m_CaptureCamera_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "SetPos", _m_SetPos_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "SetLocalPos", _m_SetLocalPos_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "SetScale", _m_SetScale_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "SetAlpha", _m_SetAlpha_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "Instantiate", _m_Instantiate_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "InstantiateAndReset", _m_InstantiateAndReset_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "StartCoroutineToWaitOneFrame", _m_StartCoroutineToWaitOneFrame_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "SetAlphaYoyo", _m_SetAlphaYoyo_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "FloatTween", _m_FloatTween_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "ConvertVector2", _m_ConvertVector2_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "ConvertVector3", _m_ConvertVector3_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "ConvertColor", _m_ConvertColor_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "ConvertColor32", _m_ConvertColor32_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "ConverToTargetRectTransformChildPos", _m_ConverToTargetRectTransformChildPos_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "GetScreenShotPath", _m_GetScreenShotPath_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "ConvertToggleIEnumerableToAry", _m_ConvertToggleIEnumerableToAry_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "GetMd5HashFromStr", _m_GetMd5HashFromStr_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "ReplaceStrToBlankForText", _m_ReplaceStrToBlankForText_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "ReplaceStr", _m_ReplaceStr_xlua_st_);
            
			
            
			
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            return LuaAPI.luaL_error(L, "CustomerUtil does not have a constructor!");
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ReloadCurScene_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    
                    CustomerUtil.ReloadCurScene(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_UnloadUnusedAssets_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    
                    CustomerUtil.UnloadUnusedAssets(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_CaptureCamera_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
			    int __gen_param_count = LuaAPI.lua_gettop(L);
            
                if(__gen_param_count == 2&& translator.Assignable<UnityEngine.Camera>(L, 1)&& translator.Assignable<UnityEngine.Rect>(L, 2)) 
                {
                    UnityEngine.Camera camera = (UnityEngine.Camera)translator.GetObject(L, 1, typeof(UnityEngine.Camera));
                    UnityEngine.Rect rect;translator.Get(L, 2, out rect);
                    
                        string __cl_gen_ret = CustomerUtil.CaptureCamera( camera, rect );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                if(__gen_param_count == 6&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& translator.Assignable<UnityEngine.Camera>(L, 2)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 3)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 4)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 5)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 6)) 
                {
                    string imageSavePath = LuaAPI.lua_tostring(L, 1);
                    UnityEngine.Camera camera = (UnityEngine.Camera)translator.GetObject(L, 2, typeof(UnityEngine.Camera));
                    float x = (float)LuaAPI.lua_tonumber(L, 3);
                    float y = (float)LuaAPI.lua_tonumber(L, 4);
                    float width = (float)LuaAPI.lua_tonumber(L, 5);
                    float height = (float)LuaAPI.lua_tonumber(L, 6);
                    
                        bool __cl_gen_ret = CustomerUtil.CaptureCamera( imageSavePath, camera, x, y, width, height );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to CustomerUtil.CaptureCamera!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SetPos_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    UnityEngine.GameObject obj = (UnityEngine.GameObject)translator.GetObject(L, 1, typeof(UnityEngine.GameObject));
                    float x = (float)LuaAPI.lua_tonumber(L, 2);
                    float y = (float)LuaAPI.lua_tonumber(L, 3);
                    float z = (float)LuaAPI.lua_tonumber(L, 4);
                    
                    CustomerUtil.SetPos( obj, x, y, z );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SetLocalPos_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    UnityEngine.GameObject obj = (UnityEngine.GameObject)translator.GetObject(L, 1, typeof(UnityEngine.GameObject));
                    float x = (float)LuaAPI.lua_tonumber(L, 2);
                    float y = (float)LuaAPI.lua_tonumber(L, 3);
                    float z = (float)LuaAPI.lua_tonumber(L, 4);
                    
                    CustomerUtil.SetLocalPos( obj, x, y, z );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SetScale_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    UnityEngine.GameObject obj = (UnityEngine.GameObject)translator.GetObject(L, 1, typeof(UnityEngine.GameObject));
                    float x = (float)LuaAPI.lua_tonumber(L, 2);
                    float y = (float)LuaAPI.lua_tonumber(L, 3);
                    float z = (float)LuaAPI.lua_tonumber(L, 4);
                    
                    CustomerUtil.SetScale( obj, x, y, z );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SetAlpha_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
			    int __gen_param_count = LuaAPI.lua_gettop(L);
            
                if(__gen_param_count == 2&& translator.Assignable<UnityEngine.UI.Image>(L, 1)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 2)) 
                {
                    UnityEngine.UI.Image img = (UnityEngine.UI.Image)translator.GetObject(L, 1, typeof(UnityEngine.UI.Image));
                    float a = (float)LuaAPI.lua_tonumber(L, 2);
                    
                    CustomerUtil.SetAlpha( img, a );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 2&& translator.Assignable<UnityEngine.UI.RawImage>(L, 1)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 2)) 
                {
                    UnityEngine.UI.RawImage img = (UnityEngine.UI.RawImage)translator.GetObject(L, 1, typeof(UnityEngine.UI.RawImage));
                    float a = (float)LuaAPI.lua_tonumber(L, 2);
                    
                    CustomerUtil.SetAlpha( img, a );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to CustomerUtil.SetAlpha!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Instantiate_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    UnityEngine.GameObject obj = (UnityEngine.GameObject)translator.GetObject(L, 1, typeof(UnityEngine.GameObject));
                    UnityEngine.GameObject parent = (UnityEngine.GameObject)translator.GetObject(L, 2, typeof(UnityEngine.GameObject));
                    
                        UnityEngine.GameObject __cl_gen_ret = CustomerUtil.Instantiate( obj, parent );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_InstantiateAndReset_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    UnityEngine.GameObject obj = (UnityEngine.GameObject)translator.GetObject(L, 1, typeof(UnityEngine.GameObject));
                    UnityEngine.GameObject parent = (UnityEngine.GameObject)translator.GetObject(L, 2, typeof(UnityEngine.GameObject));
                    
                        UnityEngine.GameObject __cl_gen_ret = CustomerUtil.InstantiateAndReset( obj, parent );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_StartCoroutineToWaitOneFrame_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    UnityEngine.MonoBehaviour mono = (UnityEngine.MonoBehaviour)translator.GetObject(L, 1, typeof(UnityEngine.MonoBehaviour));
                    System.Action callback = translator.GetDelegate<System.Action>(L, 2);
                    
                    CustomerUtil.StartCoroutineToWaitOneFrame( mono, callback );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SetAlphaYoyo_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    UnityEngine.UI.Image img = (UnityEngine.UI.Image)translator.GetObject(L, 1, typeof(UnityEngine.UI.Image));
                    float a = (float)LuaAPI.lua_tonumber(L, 2);
                    float t = (float)LuaAPI.lua_tonumber(L, 3);
                    
                        DG.Tweening.Sequence __cl_gen_ret = CustomerUtil.SetAlphaYoyo( img, a, t );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_FloatTween_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    float startValue = (float)LuaAPI.lua_tonumber(L, 1);
                    float endValue = (float)LuaAPI.lua_tonumber(L, 2);
                    float duration = (float)LuaAPI.lua_tonumber(L, 3);
                    System.Action<float> funUpdate = translator.GetDelegate<System.Action<float>>(L, 4);
                    System.Action funComplete = translator.GetDelegate<System.Action>(L, 5);
                    
                        DG.Tweening.Sequence __cl_gen_ret = CustomerUtil.FloatTween( startValue, endValue, duration, funUpdate, funComplete );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ConvertVector2_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    float x = (float)LuaAPI.lua_tonumber(L, 1);
                    float y = (float)LuaAPI.lua_tonumber(L, 2);
                    
                        UnityEngine.Vector2 __cl_gen_ret = CustomerUtil.ConvertVector2( x, y );
                        translator.PushUnityEngineVector2(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ConvertVector3_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    float x = (float)LuaAPI.lua_tonumber(L, 1);
                    float y = (float)LuaAPI.lua_tonumber(L, 2);
                    float z = (float)LuaAPI.lua_tonumber(L, 3);
                    
                        UnityEngine.Vector3 __cl_gen_ret = CustomerUtil.ConvertVector3( x, y, z );
                        translator.PushUnityEngineVector3(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ConvertColor_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    float r = (float)LuaAPI.lua_tonumber(L, 1);
                    float g = (float)LuaAPI.lua_tonumber(L, 2);
                    float b = (float)LuaAPI.lua_tonumber(L, 3);
                    float a = (float)LuaAPI.lua_tonumber(L, 4);
                    
                        UnityEngine.Color __cl_gen_ret = CustomerUtil.ConvertColor( r, g, b, a );
                        translator.PushUnityEngineColor(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ConvertColor32_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    byte r = (byte)LuaAPI.xlua_tointeger(L, 1);
                    byte g = (byte)LuaAPI.xlua_tointeger(L, 2);
                    byte b = (byte)LuaAPI.xlua_tointeger(L, 3);
                    byte a = (byte)LuaAPI.xlua_tointeger(L, 4);
                    
                        UnityEngine.Color __cl_gen_ret = CustomerUtil.ConvertColor32( r, g, b, a );
                        translator.PushUnityEngineColor(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ConverToTargetRectTransformChildPos_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    UnityEngine.Camera camera = (UnityEngine.Camera)translator.GetObject(L, 1, typeof(UnityEngine.Camera));
                    UnityEngine.RectTransform source = (UnityEngine.RectTransform)translator.GetObject(L, 2, typeof(UnityEngine.RectTransform));
                    UnityEngine.RectTransform target = (UnityEngine.RectTransform)translator.GetObject(L, 3, typeof(UnityEngine.RectTransform));
                    
                        UnityEngine.Vector2 __cl_gen_ret = CustomerUtil.ConverToTargetRectTransformChildPos( camera, source, target );
                        translator.PushUnityEngineVector2(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetScreenShotPath_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    
                        string __cl_gen_ret = CustomerUtil.GetScreenShotPath(  );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ConvertToggleIEnumerableToAry_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    System.Collections.Generic.IEnumerable<UnityEngine.UI.Toggle> ieCollection = (System.Collections.Generic.IEnumerable<UnityEngine.UI.Toggle>)translator.GetObject(L, 1, typeof(System.Collections.Generic.IEnumerable<UnityEngine.UI.Toggle>));
                    
                        UnityEngine.UI.Toggle[] __cl_gen_ret = CustomerUtil.ConvertToggleIEnumerableToAry( ieCollection );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetMd5HashFromStr_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string text = LuaAPI.lua_tostring(L, 1);
                    
                        string __cl_gen_ret = CustomerUtil.GetMd5HashFromStr( text );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ReplaceStrToBlankForText_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string str = LuaAPI.lua_tostring(L, 1);
                    string pattern = LuaAPI.lua_tostring(L, 2);
                    
                        string __cl_gen_ret = CustomerUtil.ReplaceStrToBlankForText( str, pattern );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ReplaceStr_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string str = LuaAPI.lua_tostring(L, 1);
                    string pattern = LuaAPI.lua_tostring(L, 2);
                    string target = LuaAPI.lua_tostring(L, 3);
                    
                        string __cl_gen_ret = CustomerUtil.ReplaceStr( str, pattern, target );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        
        
        
        
        
		
		
		
		
    }
}
