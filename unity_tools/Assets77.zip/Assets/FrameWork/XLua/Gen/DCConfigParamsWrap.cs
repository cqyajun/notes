﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class DCConfigParamsWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(DCConfigParams);
			Utils.BeginObjectRegister(type, L, translator, 0, 0, 0, 0);
			
			
			
			
			
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 7, 1, 1);
			Utils.RegisterFunc(L, Utils.CLS_IDX, "update", _m_update_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "setUpdateCallBack", _m_setUpdateCallBack_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "getParameterString", _m_getParameterString_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "getParameterInt", _m_getParameterInt_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "getParameterLong", _m_getParameterLong_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "getParameterBoolean", _m_getParameterBoolean_xlua_st_);
            
			
            
			Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "DATAEYE_CONFIG_PARAMS_UPDATE_COMPLETE", _g_get_DATAEYE_CONFIG_PARAMS_UPDATE_COMPLETE);
            
			Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "DATAEYE_CONFIG_PARAMS_UPDATE_COMPLETE", _s_set_DATAEYE_CONFIG_PARAMS_UPDATE_COMPLETE);
            
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					DCConfigParams __cl_gen_ret = new DCConfigParams();
					translator.Push(L, __cl_gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception __gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to DCConfigParams constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_update_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    
                    DCConfigParams.update(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_setUpdateCallBack_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string objectName = LuaAPI.lua_tostring(L, 1);
                    string functionName = LuaAPI.lua_tostring(L, 2);
                    
                    DCConfigParams.setUpdateCallBack( objectName, functionName );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_getParameterString_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string key = LuaAPI.lua_tostring(L, 1);
                    string defaultValue = LuaAPI.lua_tostring(L, 2);
                    
                        string __cl_gen_ret = DCConfigParams.getParameterString( key, defaultValue );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_getParameterInt_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string key = LuaAPI.lua_tostring(L, 1);
                    int defaultValue = LuaAPI.xlua_tointeger(L, 2);
                    
                        int __cl_gen_ret = DCConfigParams.getParameterInt( key, defaultValue );
                        LuaAPI.xlua_pushinteger(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_getParameterLong_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string key = LuaAPI.lua_tostring(L, 1);
                    long defaultValue = LuaAPI.lua_toint64(L, 2);
                    
                        long __cl_gen_ret = DCConfigParams.getParameterLong( key, defaultValue );
                        LuaAPI.lua_pushint64(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_getParameterBoolean_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string key = LuaAPI.lua_tostring(L, 1);
                    bool defaultValue = LuaAPI.lua_toboolean(L, 2);
                    
                        bool __cl_gen_ret = DCConfigParams.getParameterBoolean( key, defaultValue );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_DATAEYE_CONFIG_PARAMS_UPDATE_COMPLETE(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, DCConfigParams.DATAEYE_CONFIG_PARAMS_UPDATE_COMPLETE);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_DATAEYE_CONFIG_PARAMS_UPDATE_COMPLETE(RealStatePtr L)
        {
		    try {
                
			    DCConfigParams.DATAEYE_CONFIG_PARAMS_UPDATE_COMPLETE = LuaAPI.lua_tostring(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
