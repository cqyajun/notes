﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class AppDefineWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(AppDefine);
			Utils.BeginObjectRegister(type, L, translator, 0, 0, 0, 0);
			
			
			
			
			
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 1, 17, 9);
			
			
            
			Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "CurrentProjectPath", _g_get_CurrentProjectPath);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "CurrentProjectFolderPath", _g_get_CurrentProjectFolderPath);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "CurrentProjectFolder", _g_get_CurrentProjectFolder);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "AssetRecordsFileName", _g_get_AssetRecordsFileName);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "HallNumber", _g_get_HallNumber);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "PlatformPath", _g_get_PlatformPath);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "REMOTE_DATA_PATH", _g_get_REMOTE_DATA_PATH);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "LOCAL_INIT_DATA_PATH", _g_get_LOCAL_INIT_DATA_PATH);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "LOCAL_DATA_PATH", _g_get_LOCAL_DATA_PATH);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "LOCAL_TEMP_PATH", _g_get_LOCAL_TEMP_PATH);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "m_CurrentProjectPath", _g_get_m_CurrentProjectPath);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "ProjectListFileName", _g_get_ProjectListFileName);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "IsEncrypted", _g_get_IsEncrypted);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "AssetSecretKey", _g_get_AssetSecretKey);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "UpdateFileUrl", _g_get_UpdateFileUrl);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "GameUrl", _g_get_GameUrl);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "OpenHotUpdate", _g_get_OpenHotUpdate);
            
			Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "CurrentProjectPath", _s_set_CurrentProjectPath);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "REMOTE_DATA_PATH", _s_set_REMOTE_DATA_PATH);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "m_CurrentProjectPath", _s_set_m_CurrentProjectPath);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "ProjectListFileName", _s_set_ProjectListFileName);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "IsEncrypted", _s_set_IsEncrypted);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "AssetSecretKey", _s_set_AssetSecretKey);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "UpdateFileUrl", _s_set_UpdateFileUrl);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "GameUrl", _s_set_GameUrl);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "OpenHotUpdate", _s_set_OpenHotUpdate);
            
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					AppDefine __cl_gen_ret = new AppDefine();
					translator.Push(L, __cl_gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception __gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to AppDefine constructor!");
            
        }
        
		
        
		
        
        
        
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_CurrentProjectPath(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, AppDefine.CurrentProjectPath);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_CurrentProjectFolderPath(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, AppDefine.CurrentProjectFolderPath);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_CurrentProjectFolder(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, AppDefine.CurrentProjectFolder);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_AssetRecordsFileName(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, AppDefine.AssetRecordsFileName);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_HallNumber(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, AppDefine.HallNumber);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_PlatformPath(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, AppDefine.PlatformPath);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_REMOTE_DATA_PATH(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, AppDefine.REMOTE_DATA_PATH);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_LOCAL_INIT_DATA_PATH(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, AppDefine.LOCAL_INIT_DATA_PATH);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_LOCAL_DATA_PATH(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, AppDefine.LOCAL_DATA_PATH);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_LOCAL_TEMP_PATH(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, AppDefine.LOCAL_TEMP_PATH);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_m_CurrentProjectPath(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, AppDefine.m_CurrentProjectPath);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_ProjectListFileName(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, AppDefine.ProjectListFileName);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_IsEncrypted(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushboolean(L, AppDefine.IsEncrypted);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_AssetSecretKey(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, AppDefine.AssetSecretKey);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_UpdateFileUrl(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, AppDefine.UpdateFileUrl);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_GameUrl(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, AppDefine.GameUrl);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_OpenHotUpdate(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushboolean(L, AppDefine.OpenHotUpdate);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_CurrentProjectPath(RealStatePtr L)
        {
		    try {
                
			    AppDefine.CurrentProjectPath = LuaAPI.lua_tostring(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_REMOTE_DATA_PATH(RealStatePtr L)
        {
		    try {
                
			    AppDefine.REMOTE_DATA_PATH = LuaAPI.lua_tostring(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_m_CurrentProjectPath(RealStatePtr L)
        {
		    try {
                
			    AppDefine.m_CurrentProjectPath = LuaAPI.lua_tostring(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_ProjectListFileName(RealStatePtr L)
        {
		    try {
                
			    AppDefine.ProjectListFileName = LuaAPI.lua_tostring(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_IsEncrypted(RealStatePtr L)
        {
		    try {
                
			    AppDefine.IsEncrypted = LuaAPI.lua_toboolean(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_AssetSecretKey(RealStatePtr L)
        {
		    try {
                
			    AppDefine.AssetSecretKey = LuaAPI.lua_tostring(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_UpdateFileUrl(RealStatePtr L)
        {
		    try {
                
			    AppDefine.UpdateFileUrl = LuaAPI.lua_tostring(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_GameUrl(RealStatePtr L)
        {
		    try {
                
			    AppDefine.GameUrl = LuaAPI.lua_tostring(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_OpenHotUpdate(RealStatePtr L)
        {
		    try {
                
			    AppDefine.OpenHotUpdate = LuaAPI.lua_toboolean(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
