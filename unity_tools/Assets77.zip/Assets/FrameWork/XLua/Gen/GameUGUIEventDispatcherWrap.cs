﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class GameUGUIEventDispatcherWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(GameUGUIEventDispatcher);
			Utils.BeginObjectRegister(type, L, translator, 0, 0, 0, 0);
			
			
			
			
			
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 9, 7, 7);
			Utils.RegisterFunc(L, Utils.CLS_IDX, "onCustomerHandle", _m_onCustomerHandle_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "onPressHandle", _m_onPressHandle_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "onClickHandle", _m_onClickHandle_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "onDragHandle", _m_onDragHandle_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "onDropHandle", _m_onDropHandle_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "onSelectHandle", _m_onSelectHandle_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "onCancelHandle", _m_onCancelHandle_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "RemoveAllEvents", _m_RemoveAllEvents_xlua_st_);
            
			
            
			Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "onCustomerFn", _g_get_onCustomerFn);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "onPressFn", _g_get_onPressFn);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "onClickFn", _g_get_onClickFn);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "onDragFn", _g_get_onDragFn);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "onDropFn", _g_get_onDropFn);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "onSelectFn", _g_get_onSelectFn);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "onCancelFn", _g_get_onCancelFn);
            
			Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "onCustomerFn", _s_set_onCustomerFn);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "onPressFn", _s_set_onPressFn);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "onClickFn", _s_set_onClickFn);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "onDragFn", _s_set_onDragFn);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "onDropFn", _s_set_onDropFn);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "onSelectFn", _s_set_onSelectFn);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "onCancelFn", _s_set_onCancelFn);
            
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            return LuaAPI.luaL_error(L, "GameUGUIEventDispatcher does not have a constructor!");
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_onCustomerHandle_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
			    int __gen_param_count = LuaAPI.lua_gettop(L);
            
                if(__gen_param_count == 4&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<object>(L, 3)&& translator.Assignable<object>(L, 4)) 
                {
                    string packageName = LuaAPI.lua_tostring(L, 1);
                    string moduleName = LuaAPI.lua_tostring(L, 2);
                    object sender = translator.GetObject(L, 3, typeof(object));
                    object arg = translator.GetObject(L, 4, typeof(object));
                    
                    GameUGUIEventDispatcher.onCustomerHandle( packageName, moduleName, sender, arg );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 4&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<object>(L, 3)&& translator.Assignable<UnityEngine.Vector3>(L, 4)) 
                {
                    string packageName = LuaAPI.lua_tostring(L, 1);
                    string moduleName = LuaAPI.lua_tostring(L, 2);
                    object sender = translator.GetObject(L, 3, typeof(object));
                    UnityEngine.Vector3 arg;translator.Get(L, 4, out arg);
                    
                    GameUGUIEventDispatcher.onCustomerHandle( packageName, moduleName, sender, arg );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to GameUGUIEventDispatcher.onCustomerHandle!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_onPressHandle_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
			    int __gen_param_count = LuaAPI.lua_gettop(L);
            
                if(__gen_param_count == 4&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<object>(L, 3)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 4)) 
                {
                    string packageName = LuaAPI.lua_tostring(L, 1);
                    string moduleName = LuaAPI.lua_tostring(L, 2);
                    object sender = translator.GetObject(L, 3, typeof(object));
                    bool arg = LuaAPI.lua_toboolean(L, 4);
                    
                    GameUGUIEventDispatcher.onPressHandle( packageName, moduleName, sender, arg );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 4&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<object>(L, 3)&& translator.Assignable<object>(L, 4)) 
                {
                    string packageName = LuaAPI.lua_tostring(L, 1);
                    string moduleName = LuaAPI.lua_tostring(L, 2);
                    object sender = translator.GetObject(L, 3, typeof(object));
                    object arg = translator.GetObject(L, 4, typeof(object));
                    
                    GameUGUIEventDispatcher.onPressHandle( packageName, moduleName, sender, arg );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to GameUGUIEventDispatcher.onPressHandle!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_onClickHandle_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
			    int __gen_param_count = LuaAPI.lua_gettop(L);
            
                if(__gen_param_count == 3&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<object>(L, 3)) 
                {
                    string packageName = LuaAPI.lua_tostring(L, 1);
                    string moduleName = LuaAPI.lua_tostring(L, 2);
                    object sender = translator.GetObject(L, 3, typeof(object));
                    
                    GameUGUIEventDispatcher.onClickHandle( packageName, moduleName, sender );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 4&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<object>(L, 3)&& translator.Assignable<object>(L, 4)) 
                {
                    string packageName = LuaAPI.lua_tostring(L, 1);
                    string moduleName = LuaAPI.lua_tostring(L, 2);
                    object sender = translator.GetObject(L, 3, typeof(object));
                    object arg = translator.GetObject(L, 4, typeof(object));
                    
                    GameUGUIEventDispatcher.onClickHandle( packageName, moduleName, sender, arg );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to GameUGUIEventDispatcher.onClickHandle!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_onDragHandle_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    string packageName = LuaAPI.lua_tostring(L, 1);
                    string moduleName = LuaAPI.lua_tostring(L, 2);
                    object sender = translator.GetObject(L, 3, typeof(object));
                    UnityEngine.Vector3 arg;translator.Get(L, 4, out arg);
                    
                    GameUGUIEventDispatcher.onDragHandle( packageName, moduleName, sender, arg );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_onDropHandle_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
			    int __gen_param_count = LuaAPI.lua_gettop(L);
            
                if(__gen_param_count == 4&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<object>(L, 3)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 4)) 
                {
                    string packageName = LuaAPI.lua_tostring(L, 1);
                    string moduleName = LuaAPI.lua_tostring(L, 2);
                    object sender = translator.GetObject(L, 3, typeof(object));
                    bool arg = LuaAPI.lua_toboolean(L, 4);
                    
                    GameUGUIEventDispatcher.onDropHandle( packageName, moduleName, sender, arg );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 4&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<object>(L, 3)&& translator.Assignable<object>(L, 4)) 
                {
                    string packageName = LuaAPI.lua_tostring(L, 1);
                    string moduleName = LuaAPI.lua_tostring(L, 2);
                    object sender = translator.GetObject(L, 3, typeof(object));
                    object arg = translator.GetObject(L, 4, typeof(object));
                    
                    GameUGUIEventDispatcher.onDropHandle( packageName, moduleName, sender, arg );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 4&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<object>(L, 3)&& translator.Assignable<UnityEngine.Vector3>(L, 4)) 
                {
                    string packageName = LuaAPI.lua_tostring(L, 1);
                    string moduleName = LuaAPI.lua_tostring(L, 2);
                    object sender = translator.GetObject(L, 3, typeof(object));
                    UnityEngine.Vector3 arg;translator.Get(L, 4, out arg);
                    
                    GameUGUIEventDispatcher.onDropHandle( packageName, moduleName, sender, arg );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to GameUGUIEventDispatcher.onDropHandle!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_onSelectHandle_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    string packageName = LuaAPI.lua_tostring(L, 1);
                    string moduleName = LuaAPI.lua_tostring(L, 2);
                    object sender = translator.GetObject(L, 3, typeof(object));
                    object arg = translator.GetObject(L, 4, typeof(object));
                    
                    GameUGUIEventDispatcher.onSelectHandle( packageName, moduleName, sender, arg );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_onCancelHandle_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    string packageName = LuaAPI.lua_tostring(L, 1);
                    string moduleName = LuaAPI.lua_tostring(L, 2);
                    object sender = translator.GetObject(L, 3, typeof(object));
                    object arg = translator.GetObject(L, 4, typeof(object));
                    
                    GameUGUIEventDispatcher.onCancelHandle( packageName, moduleName, sender, arg );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_RemoveAllEvents_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    
                    GameUGUIEventDispatcher.RemoveAllEvents(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_onCustomerFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, GameUGUIEventDispatcher.onCustomerFn);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_onPressFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, GameUGUIEventDispatcher.onPressFn);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_onClickFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, GameUGUIEventDispatcher.onClickFn);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_onDragFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, GameUGUIEventDispatcher.onDragFn);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_onDropFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, GameUGUIEventDispatcher.onDropFn);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_onSelectFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, GameUGUIEventDispatcher.onSelectFn);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_onCancelFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, GameUGUIEventDispatcher.onCancelFn);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_onCustomerFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    GameUGUIEventDispatcher.onCustomerFn = translator.GetDelegate<System.Action<string, string, object, object>>(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_onPressFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    GameUGUIEventDispatcher.onPressFn = translator.GetDelegate<System.Action<string, string, object, object>>(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_onClickFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    GameUGUIEventDispatcher.onClickFn = translator.GetDelegate<System.Action<string, string, object, object>>(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_onDragFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    GameUGUIEventDispatcher.onDragFn = translator.GetDelegate<System.Action<string, string, object, object>>(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_onDropFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    GameUGUIEventDispatcher.onDropFn = translator.GetDelegate<System.Action<string, string, object, object>>(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_onSelectFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    GameUGUIEventDispatcher.onSelectFn = translator.GetDelegate<System.Action<string, string, object, object>>(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_onCancelFn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    GameUGUIEventDispatcher.onCancelFn = translator.GetDelegate<System.Action<string, string, object, object>>(L, 1);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
