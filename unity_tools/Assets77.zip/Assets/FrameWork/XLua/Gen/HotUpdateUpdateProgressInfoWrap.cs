﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class HotUpdateUpdateProgressInfoWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(HotUpdate.UpdateProgressInfo);
			Utils.BeginObjectRegister(type, L, translator, 0, 0, 5, 5);
			
			
			
			Utils.RegisterFunc(L, Utils.GETTER_IDX, "ProgressPercentage", _g_get_ProgressPercentage);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "TipsContent", _g_get_TipsContent);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "DownLoadSizeInfo", _g_get_DownLoadSizeInfo);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "DownLoadSpeed", _g_get_DownLoadSpeed);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "NeedTime", _g_get_NeedTime);
            
			Utils.RegisterFunc(L, Utils.SETTER_IDX, "ProgressPercentage", _s_set_ProgressPercentage);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "TipsContent", _s_set_TipsContent);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "DownLoadSizeInfo", _s_set_DownLoadSizeInfo);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "DownLoadSpeed", _s_set_DownLoadSpeed);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "NeedTime", _s_set_NeedTime);
            
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 1, 0, 0);
			
			
            
			
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					HotUpdate.UpdateProgressInfo __cl_gen_ret = new HotUpdate.UpdateProgressInfo();
					translator.Push(L, __cl_gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception __gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to HotUpdate.UpdateProgressInfo constructor!");
            
        }
        
		
        
		
        
        
        
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_ProgressPercentage(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                HotUpdate.UpdateProgressInfo __cl_gen_to_be_invoked = (HotUpdate.UpdateProgressInfo)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushnumber(L, __cl_gen_to_be_invoked.ProgressPercentage);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_TipsContent(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                HotUpdate.UpdateProgressInfo __cl_gen_to_be_invoked = (HotUpdate.UpdateProgressInfo)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushstring(L, __cl_gen_to_be_invoked.TipsContent);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_DownLoadSizeInfo(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                HotUpdate.UpdateProgressInfo __cl_gen_to_be_invoked = (HotUpdate.UpdateProgressInfo)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushstring(L, __cl_gen_to_be_invoked.DownLoadSizeInfo);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_DownLoadSpeed(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                HotUpdate.UpdateProgressInfo __cl_gen_to_be_invoked = (HotUpdate.UpdateProgressInfo)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushstring(L, __cl_gen_to_be_invoked.DownLoadSpeed);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_NeedTime(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                HotUpdate.UpdateProgressInfo __cl_gen_to_be_invoked = (HotUpdate.UpdateProgressInfo)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushstring(L, __cl_gen_to_be_invoked.NeedTime);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_ProgressPercentage(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                HotUpdate.UpdateProgressInfo __cl_gen_to_be_invoked = (HotUpdate.UpdateProgressInfo)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.ProgressPercentage = (float)LuaAPI.lua_tonumber(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_TipsContent(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                HotUpdate.UpdateProgressInfo __cl_gen_to_be_invoked = (HotUpdate.UpdateProgressInfo)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.TipsContent = LuaAPI.lua_tostring(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_DownLoadSizeInfo(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                HotUpdate.UpdateProgressInfo __cl_gen_to_be_invoked = (HotUpdate.UpdateProgressInfo)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.DownLoadSizeInfo = LuaAPI.lua_tostring(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_DownLoadSpeed(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                HotUpdate.UpdateProgressInfo __cl_gen_to_be_invoked = (HotUpdate.UpdateProgressInfo)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.DownLoadSpeed = LuaAPI.lua_tostring(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_NeedTime(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                HotUpdate.UpdateProgressInfo __cl_gen_to_be_invoked = (HotUpdate.UpdateProgressInfo)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.NeedTime = LuaAPI.lua_tostring(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
