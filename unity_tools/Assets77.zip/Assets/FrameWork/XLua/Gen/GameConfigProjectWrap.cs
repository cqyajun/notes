﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class GameConfigProjectWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(GameConfigProject);
			Utils.BeginObjectRegister(type, L, translator, 0, 1, 15, 15);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Clone", _m_Clone);
			
			
			Utils.RegisterFunc(L, Utils.GETTER_IDX, "showFpsPanel", _g_get_showFpsPanel);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "showLogPanel", _g_get_showLogPanel);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "assetLoadType", _g_get_assetLoadType);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "shouldCheckVersion", _g_get_shouldCheckVersion);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "selectServerIndex", _g_get_selectServerIndex);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "selectPackageIndex", _g_get_selectPackageIndex);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "testServerIp", _g_get_testServerIp);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "testServerIpValue", _g_get_testServerIpValue);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "testServerPort", _g_get_testServerPort);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "testServerPortValue", _g_get_testServerPortValue);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "testAppVersion", _g_get_testAppVersion);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "testAppVersionValue", _g_get_testAppVersionValue);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "testBunldIdFlag", _g_get_testBunldIdFlag);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "testBunldIdValue", _g_get_testBunldIdValue);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "isDirectConnectIp", _g_get_isDirectConnectIp);
            
			Utils.RegisterFunc(L, Utils.SETTER_IDX, "showFpsPanel", _s_set_showFpsPanel);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "showLogPanel", _s_set_showLogPanel);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "assetLoadType", _s_set_assetLoadType);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "shouldCheckVersion", _s_set_shouldCheckVersion);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "selectServerIndex", _s_set_selectServerIndex);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "selectPackageIndex", _s_set_selectPackageIndex);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "testServerIp", _s_set_testServerIp);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "testServerIpValue", _s_set_testServerIpValue);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "testServerPort", _s_set_testServerPort);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "testServerPortValue", _s_set_testServerPortValue);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "testAppVersion", _s_set_testAppVersion);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "testAppVersionValue", _s_set_testAppVersionValue);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "testBunldIdFlag", _s_set_testBunldIdFlag);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "testBunldIdValue", _s_set_testBunldIdValue);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "isDirectConnectIp", _s_set_isDirectConnectIp);
            
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 1, 0, 0);
			
			
            
			
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					GameConfigProject __cl_gen_ret = new GameConfigProject();
					translator.Push(L, __cl_gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception __gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to GameConfigProject constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Clone(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        UnityEngine.MonoBehaviour __cl_gen_ret = __cl_gen_to_be_invoked.Clone(  );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_showFpsPanel(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushboolean(L, __cl_gen_to_be_invoked.showFpsPanel);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_showLogPanel(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushboolean(L, __cl_gen_to_be_invoked.showLogPanel);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_assetLoadType(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                LuaAPI.xlua_pushinteger(L, __cl_gen_to_be_invoked.assetLoadType);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_shouldCheckVersion(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushboolean(L, __cl_gen_to_be_invoked.shouldCheckVersion);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_selectServerIndex(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                LuaAPI.xlua_pushinteger(L, __cl_gen_to_be_invoked.selectServerIndex);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_selectPackageIndex(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                LuaAPI.xlua_pushinteger(L, __cl_gen_to_be_invoked.selectPackageIndex);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_testServerIp(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushboolean(L, __cl_gen_to_be_invoked.testServerIp);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_testServerIpValue(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushstring(L, __cl_gen_to_be_invoked.testServerIpValue);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_testServerPort(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushboolean(L, __cl_gen_to_be_invoked.testServerPort);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_testServerPortValue(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushstring(L, __cl_gen_to_be_invoked.testServerPortValue);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_testAppVersion(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushboolean(L, __cl_gen_to_be_invoked.testAppVersion);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_testAppVersionValue(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushstring(L, __cl_gen_to_be_invoked.testAppVersionValue);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_testBunldIdFlag(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushboolean(L, __cl_gen_to_be_invoked.testBunldIdFlag);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_testBunldIdValue(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushstring(L, __cl_gen_to_be_invoked.testBunldIdValue);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_isDirectConnectIp(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushboolean(L, __cl_gen_to_be_invoked.isDirectConnectIp);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_showFpsPanel(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.showFpsPanel = LuaAPI.lua_toboolean(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_showLogPanel(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.showLogPanel = LuaAPI.lua_toboolean(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_assetLoadType(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.assetLoadType = LuaAPI.xlua_tointeger(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_shouldCheckVersion(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.shouldCheckVersion = LuaAPI.lua_toboolean(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_selectServerIndex(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.selectServerIndex = LuaAPI.xlua_tointeger(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_selectPackageIndex(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.selectPackageIndex = LuaAPI.xlua_tointeger(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_testServerIp(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.testServerIp = LuaAPI.lua_toboolean(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_testServerIpValue(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.testServerIpValue = LuaAPI.lua_tostring(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_testServerPort(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.testServerPort = LuaAPI.lua_toboolean(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_testServerPortValue(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.testServerPortValue = LuaAPI.lua_tostring(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_testAppVersion(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.testAppVersion = LuaAPI.lua_toboolean(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_testAppVersionValue(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.testAppVersionValue = LuaAPI.lua_tostring(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_testBunldIdFlag(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.testBunldIdFlag = LuaAPI.lua_toboolean(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_testBunldIdValue(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.testBunldIdValue = LuaAPI.lua_tostring(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_isDirectConnectIp(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameConfigProject __cl_gen_to_be_invoked = (GameConfigProject)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.isDirectConnectIp = LuaAPI.lua_toboolean(L, 2);
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
