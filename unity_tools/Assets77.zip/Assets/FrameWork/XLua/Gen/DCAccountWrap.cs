﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class DCAccountWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(DCAccount);
			Utils.BeginObjectRegister(type, L, translator, 0, 0, 0, 0);
			
			
			
			
			
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 11, 0, 0);
			Utils.RegisterFunc(L, Utils.CLS_IDX, "login", _m_login_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "logout", _m_logout_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "getAccountId", _m_getAccountId_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "setAccountType", _m_setAccountType_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "setLevel", _m_setLevel_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "setGender", _m_setGender_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "setAge", _m_setAge_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "setGameServer", _m_setGameServer_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "addTag", _m_addTag_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "removeTag", _m_removeTag_xlua_st_);
            
			
            
			
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					DCAccount __cl_gen_ret = new DCAccount();
					translator.Push(L, __cl_gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception __gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to DCAccount constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_login_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
			    int __gen_param_count = LuaAPI.lua_gettop(L);
            
                if(__gen_param_count == 1&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)) 
                {
                    string accountId = LuaAPI.lua_tostring(L, 1);
                    
                    DCAccount.login( accountId );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 2&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)) 
                {
                    string accountId = LuaAPI.lua_tostring(L, 1);
                    string gameServer = LuaAPI.lua_tostring(L, 2);
                    
                    DCAccount.login( accountId, gameServer );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to DCAccount.login!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_logout_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    
                    DCAccount.logout(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_getAccountId_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    
                        string __cl_gen_ret = DCAccount.getAccountId(  );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_setAccountType_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    DCAccountType type;translator.Get(L, 1, out type);
                    
                    DCAccount.setAccountType( type );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_setLevel_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    int level = LuaAPI.xlua_tointeger(L, 1);
                    
                    DCAccount.setLevel( level );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_setGender_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    DCGender gender;translator.Get(L, 1, out gender);
                    
                    DCAccount.setGender( gender );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_setAge_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    int age = LuaAPI.xlua_tointeger(L, 1);
                    
                    DCAccount.setAge( age );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_setGameServer_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string server = LuaAPI.lua_tostring(L, 1);
                    
                    DCAccount.setGameServer( server );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_addTag_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string tag = LuaAPI.lua_tostring(L, 1);
                    string subTag = LuaAPI.lua_tostring(L, 2);
                    
                    DCAccount.addTag( tag, subTag );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_removeTag_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string tag = LuaAPI.lua_tostring(L, 1);
                    string subTag = LuaAPI.lua_tostring(L, 2);
                    
                    DCAccount.removeTag( tag, subTag );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        
        
        
        
        
		
		
		
		
    }
}
