﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class LuaHelperWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(LuaHelper);
			Utils.BeginObjectRegister(type, L, translator, 0, 0, 0, 0);
			
			
			
			
			
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 11, 0, 0);
			Utils.RegisterFunc(L, Utils.CLS_IDX, "GetLayerMask", _m_GetLayerMask_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "GetAngle", _m_GetAngle_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "GetUTF8String", _m_GetUTF8String_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "GetBytes", _m_GetBytes_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "LoadFromMemory", _m_LoadFromMemory_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "GCCollect", _m_GCCollect_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "StringToHash", _m_StringToHash_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "SetTextColor", _m_SetTextColor_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "SetImageColor", _m_SetImageColor_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "StringToColor", _m_StringToColor_xlua_st_);
            
			
            
			
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            return LuaAPI.luaL_error(L, "LuaHelper does not have a constructor!");
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetLayerMask_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string args = LuaAPI.lua_tostring(L, 1);
                    
                        int __cl_gen_ret = LuaHelper.GetLayerMask( args );
                        LuaAPI.xlua_pushinteger(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetAngle_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    float p1x = (float)LuaAPI.lua_tonumber(L, 1);
                    float p1y = (float)LuaAPI.lua_tonumber(L, 2);
                    float p2x = (float)LuaAPI.lua_tonumber(L, 3);
                    float p2y = (float)LuaAPI.lua_tonumber(L, 4);
                    
                        float __cl_gen_ret = LuaHelper.GetAngle( p1x, p1y, p2x, p2y );
                        LuaAPI.lua_pushnumber(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetUTF8String_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    System.Array bytes = (System.Array)translator.GetObject(L, 1, typeof(System.Array));
                    
                        string __cl_gen_ret = LuaHelper.GetUTF8String( bytes );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetBytes_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string utf8Str = LuaAPI.lua_tostring(L, 1);
                    
                        byte[] __cl_gen_ret = LuaHelper.GetBytes( utf8Str );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_LoadFromMemory_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    System.Array bytes = (System.Array)translator.GetObject(L, 1, typeof(System.Array));
                    
                        UnityEngine.AssetBundle __cl_gen_ret = LuaHelper.LoadFromMemory( bytes );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GCCollect_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    
                    LuaHelper.GCCollect(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_StringToHash_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string str = LuaAPI.lua_tostring(L, 1);
                    
                        int __cl_gen_ret = LuaHelper.StringToHash( str );
                        LuaAPI.xlua_pushinteger(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SetTextColor_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    UnityEngine.UI.Text text = (UnityEngine.UI.Text)translator.GetObject(L, 1, typeof(UnityEngine.UI.Text));
                    string color = LuaAPI.lua_tostring(L, 2);
                    
                    LuaHelper.SetTextColor( text, color );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SetImageColor_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    UnityEngine.UI.Image img = (UnityEngine.UI.Image)translator.GetObject(L, 1, typeof(UnityEngine.UI.Image));
                    string color = LuaAPI.lua_tostring(L, 2);
                    
                    LuaHelper.SetImageColor( img, color );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_StringToColor_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    string color = LuaAPI.lua_tostring(L, 1);
                    
                        UnityEngine.Color __cl_gen_ret = LuaHelper.StringToColor( color );
                        translator.PushUnityEngineColor(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        
        
        
        
        
		
		
		
		
    }
}
