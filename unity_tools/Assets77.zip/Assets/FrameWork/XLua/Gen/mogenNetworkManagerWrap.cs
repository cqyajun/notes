﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class mogenNetworkManagerWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(mogen.NetworkManager);
			Utils.BeginObjectRegister(type, L, translator, 0, 9, 1, 1);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "AddSocket", _m_AddSocket);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "SendConnect", _m_SendConnect);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "SendConnectIPAddress", _m_SendConnectIPAddress);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "SendMessage", _m_SendMessage);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetReader", _m_GetReader);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "AddEvent", _m_AddEvent);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "ReadBytes", _m_ReadBytes);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetSocket", _m_GetSocket);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Clone", _m_Clone);
			
			
			Utils.RegisterFunc(L, Utils.GETTER_IDX, "netMsgs", _g_get_netMsgs);
            
			Utils.RegisterFunc(L, Utils.SETTER_IDX, "netMsgs", _s_set_netMsgs);
            
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 1, 2, 1);
			
			
            
			Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "Instance", _g_get_Instance);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "sockets", _g_get_sockets);
            
			Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "sockets", _s_set_sockets);
            
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					mogen.NetworkManager __cl_gen_ret = new mogen.NetworkManager();
					translator.Push(L, __cl_gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception __gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to mogen.NetworkManager constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_AddSocket(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                mogen.NetworkManager __cl_gen_to_be_invoked = (mogen.NetworkManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string socketName = LuaAPI.lua_tostring(L, 2);
                    int flag = LuaAPI.xlua_tointeger(L, 3);
                    
                    __cl_gen_to_be_invoked.AddSocket( socketName, flag );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SendConnect(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                mogen.NetworkManager __cl_gen_to_be_invoked = (mogen.NetworkManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string socketName = LuaAPI.lua_tostring(L, 2);
                    string ip = LuaAPI.lua_tostring(L, 3);
                    int port = LuaAPI.xlua_tointeger(L, 4);
                    
                    __cl_gen_to_be_invoked.SendConnect( socketName, ip, port );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SendConnectIPAddress(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                mogen.NetworkManager __cl_gen_to_be_invoked = (mogen.NetworkManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string socketName = LuaAPI.lua_tostring(L, 2);
                    int data = LuaAPI.xlua_tointeger(L, 3);
                    int port = LuaAPI.xlua_tointeger(L, 4);
                    
                    __cl_gen_to_be_invoked.SendConnectIPAddress( socketName, data, port );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SendMessage(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                mogen.NetworkManager __cl_gen_to_be_invoked = (mogen.NetworkManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string socketName = LuaAPI.lua_tostring(L, 2);
                    int id = LuaAPI.xlua_tointeger(L, 3);
                    byte[] msg = LuaAPI.lua_tobytes(L, 4);
                    
                    __cl_gen_to_be_invoked.SendMessage( socketName, id, msg );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetReader(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                mogen.NetworkManager __cl_gen_to_be_invoked = (mogen.NetworkManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    byte[] msg = LuaAPI.lua_tobytes(L, 2);
                    
                        object __cl_gen_ret = __cl_gen_to_be_invoked.GetReader( msg );
                        translator.PushAny(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_AddEvent(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                mogen.NetworkManager __cl_gen_to_be_invoked = (mogen.NetworkManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string socketName = LuaAPI.lua_tostring(L, 2);
                    int id = LuaAPI.xlua_tointeger(L, 3);
                    object msg = translator.GetObject(L, 4, typeof(object));
                    
                    __cl_gen_to_be_invoked.AddEvent( socketName, id, msg );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ReadBytes(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                mogen.NetworkManager __cl_gen_to_be_invoked = (mogen.NetworkManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    byte[] bytes = LuaAPI.lua_tobytes(L, 2);
                    
                    __cl_gen_to_be_invoked.ReadBytes( bytes );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetSocket(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                mogen.NetworkManager __cl_gen_to_be_invoked = (mogen.NetworkManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string n = LuaAPI.lua_tostring(L, 2);
                    
                        mogen.SocketClient __cl_gen_ret = __cl_gen_to_be_invoked.GetSocket( n );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Clone(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                mogen.NetworkManager __cl_gen_to_be_invoked = (mogen.NetworkManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        UnityEngine.MonoBehaviour __cl_gen_ret = __cl_gen_to_be_invoked.Clone(  );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_Instance(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, mogen.NetworkManager.Instance);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_sockets(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, mogen.NetworkManager.sockets);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_netMsgs(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                mogen.NetworkManager __cl_gen_to_be_invoked = (mogen.NetworkManager)translator.FastGetCSObj(L, 1);
                translator.Push(L, __cl_gen_to_be_invoked.netMsgs);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_sockets(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    mogen.NetworkManager.sockets = (System.Collections.Generic.Dictionary<string, mogen.SocketClient>)translator.GetObject(L, 1, typeof(System.Collections.Generic.Dictionary<string, mogen.SocketClient>));
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_netMsgs(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                mogen.NetworkManager __cl_gen_to_be_invoked = (mogen.NetworkManager)translator.FastGetCSObj(L, 1);
                __cl_gen_to_be_invoked.netMsgs = (System.Collections.Generic.Queue<mogen.NetMsg>)translator.GetObject(L, 2, typeof(System.Collections.Generic.Queue<mogen.NetMsg>));
            
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
