﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class FileUtilityExWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(FileUtilityEx);
			Utils.BeginObjectRegister(type, L, translator, 0, 0, 0, 0);
			
			
			
			
			
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 16, 1, 0);
			Utils.RegisterFunc(L, Utils.CLS_IDX, "SaveFile", _m_SaveFile_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "DeleteDirectory", _m_DeleteDirectory_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "DownloadFile", _m_DownloadFile_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "DirectoryExists", _m_DirectoryExists_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "DirectoryDelete", _m_DirectoryDelete_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "DirectoryCreate", _m_DirectoryCreate_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "Exists", _m_Exists_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "Delete", _m_Delete_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "Copy", _m_Copy_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "DirectoryCopy", _m_DirectoryCopy_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "WriteAllText", _m_WriteAllText_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "ReadAllText", _m_ReadAllText_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "Decompress7Zip", _m_Decompress7Zip_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "Decompress7ZipAsync", _m_Decompress7ZipAsync_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "ExecuteProgram", _m_ExecuteProgram_xlua_st_);
            
			
            
			Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "streamingAssetsPathInWWW", _g_get_streamingAssetsPathInWWW);
            
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            return LuaAPI.luaL_error(L, "FileUtilityEx does not have a constructor!");
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SaveFile_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
			    int __gen_param_count = LuaAPI.lua_gettop(L);
            
                if(__gen_param_count == 2&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)) 
                {
                    string fullPath = LuaAPI.lua_tostring(L, 1);
                    string text = LuaAPI.lua_tostring(L, 2);
                    
                    FileUtilityEx.SaveFile( fullPath, text );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 3&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 3)) 
                {
                    string fullPath = LuaAPI.lua_tostring(L, 1);
                    byte[] fileContent = LuaAPI.lua_tobytes(L, 2);
                    bool append = LuaAPI.lua_toboolean(L, 3);
                    
                    FileUtilityEx.SaveFile( fullPath, fileContent, append );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 2&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)) 
                {
                    string fullPath = LuaAPI.lua_tostring(L, 1);
                    byte[] fileContent = LuaAPI.lua_tobytes(L, 2);
                    
                    FileUtilityEx.SaveFile( fullPath, fileContent );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to FileUtilityEx.SaveFile!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_DeleteDirectory_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
			    int __gen_param_count = LuaAPI.lua_gettop(L);
            
                if(__gen_param_count == 2&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 2)) 
                {
                    string directoryPath = LuaAPI.lua_tostring(L, 1);
                    bool includeSelfDirectory = LuaAPI.lua_toboolean(L, 2);
                    
                    FileUtilityEx.DeleteDirectory( directoryPath, includeSelfDirectory );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 1&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)) 
                {
                    string directoryPath = LuaAPI.lua_tostring(L, 1);
                    
                    FileUtilityEx.DeleteDirectory( directoryPath );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to FileUtilityEx.DeleteDirectory!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_DownloadFile_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
			    int __gen_param_count = LuaAPI.lua_gettop(L);
            
                if(__gen_param_count == 4&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Action<string>>(L, 3)&& translator.Assignable<System.Action<float>>(L, 4)) 
                {
                    string serverUrl = LuaAPI.lua_tostring(L, 1);
                    string saveFile = LuaAPI.lua_tostring(L, 2);
                    System.Action<string> onDownload = translator.GetDelegate<System.Action<string>>(L, 3);
                    System.Action<float> onProgress = translator.GetDelegate<System.Action<float>>(L, 4);
                    
                    FileUtilityEx.DownloadFile( serverUrl, saveFile, onDownload, onProgress );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 3&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Action<string>>(L, 3)) 
                {
                    string serverUrl = LuaAPI.lua_tostring(L, 1);
                    string saveFile = LuaAPI.lua_tostring(L, 2);
                    System.Action<string> onDownload = translator.GetDelegate<System.Action<string>>(L, 3);
                    
                    FileUtilityEx.DownloadFile( serverUrl, saveFile, onDownload );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to FileUtilityEx.DownloadFile!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_DirectoryExists_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string path = LuaAPI.lua_tostring(L, 1);
                    
                        bool __cl_gen_ret = FileUtilityEx.DirectoryExists( path );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_DirectoryDelete_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string path = LuaAPI.lua_tostring(L, 1);
                    bool recursive = LuaAPI.lua_toboolean(L, 2);
                    
                    FileUtilityEx.DirectoryDelete( path, recursive );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_DirectoryCreate_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string path = LuaAPI.lua_tostring(L, 1);
                    
                    FileUtilityEx.DirectoryCreate( path );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Exists_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string path = LuaAPI.lua_tostring(L, 1);
                    
                        bool __cl_gen_ret = FileUtilityEx.Exists( path );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Delete_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string path = LuaAPI.lua_tostring(L, 1);
                    
                    FileUtilityEx.Delete( path );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Copy_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string fileSourpath = LuaAPI.lua_tostring(L, 1);
                    string fileDestpath = LuaAPI.lua_tostring(L, 2);
                    
                        bool __cl_gen_ret = FileUtilityEx.Copy( fileSourpath, fileDestpath );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_DirectoryCopy_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string srcPath = LuaAPI.lua_tostring(L, 1);
                    string destPath = LuaAPI.lua_tostring(L, 2);
                    
                    FileUtilityEx.DirectoryCopy( srcPath, destPath );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_WriteAllText_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string path = LuaAPI.lua_tostring(L, 1);
                    string content = LuaAPI.lua_tostring(L, 2);
                    
                    FileUtilityEx.WriteAllText( path, content );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ReadAllText_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string path = LuaAPI.lua_tostring(L, 1);
                    
                        string __cl_gen_ret = FileUtilityEx.ReadAllText( path );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Decompress7Zip_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string sourceFile = LuaAPI.lua_tostring(L, 1);
                    string extractFileDirectory = LuaAPI.lua_tostring(L, 2);
                    bool largeFiles = LuaAPI.lua_toboolean(L, 3);
                    bool fullPaths = LuaAPI.lua_toboolean(L, 4);
                    
                        int __cl_gen_ret = FileUtilityEx.Decompress7Zip( sourceFile, extractFileDirectory, largeFiles, fullPaths );
                        LuaAPI.xlua_pushinteger(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Decompress7ZipAsync_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
			    int __gen_param_count = LuaAPI.lua_gettop(L);
            
                if(__gen_param_count == 6&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 3)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 4)&& translator.Assignable<System.Action<int>>(L, 5)&& translator.Assignable<System.Action<int>>(L, 6)) 
                {
                    string sourceFile = LuaAPI.lua_tostring(L, 1);
                    string extractFileDirectory = LuaAPI.lua_tostring(L, 2);
                    bool largeFiles = LuaAPI.lua_toboolean(L, 3);
                    bool fullPaths = LuaAPI.lua_toboolean(L, 4);
                    System.Action<int> onResult = translator.GetDelegate<System.Action<int>>(L, 5);
                    System.Action<int> onProgress = translator.GetDelegate<System.Action<int>>(L, 6);
                    
                    FileUtilityEx.Decompress7ZipAsync( sourceFile, extractFileDirectory, largeFiles, fullPaths, onResult, onProgress );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 5&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 3)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 4)&& translator.Assignable<System.Action<int>>(L, 5)) 
                {
                    string sourceFile = LuaAPI.lua_tostring(L, 1);
                    string extractFileDirectory = LuaAPI.lua_tostring(L, 2);
                    bool largeFiles = LuaAPI.lua_toboolean(L, 3);
                    bool fullPaths = LuaAPI.lua_toboolean(L, 4);
                    System.Action<int> onResult = translator.GetDelegate<System.Action<int>>(L, 5);
                    
                    FileUtilityEx.Decompress7ZipAsync( sourceFile, extractFileDirectory, largeFiles, fullPaths, onResult );
                    
                    
                    
                    return 0;
                }
                if(__gen_param_count == 4&& (LuaAPI.lua_isnil(L, 1) || LuaAPI.lua_type(L, 1) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 3)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 4)) 
                {
                    string sourceFile = LuaAPI.lua_tostring(L, 1);
                    string extractFileDirectory = LuaAPI.lua_tostring(L, 2);
                    bool largeFiles = LuaAPI.lua_toboolean(L, 3);
                    bool fullPaths = LuaAPI.lua_toboolean(L, 4);
                    
                    FileUtilityEx.Decompress7ZipAsync( sourceFile, extractFileDirectory, largeFiles, fullPaths );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to FileUtilityEx.Decompress7ZipAsync!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ExecuteProgram_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string exeFilename = LuaAPI.lua_tostring(L, 1);
                    string workDir = LuaAPI.lua_tostring(L, 2);
                    string args = LuaAPI.lua_tostring(L, 3);
                    
                        bool __cl_gen_ret = FileUtilityEx.ExecuteProgram( exeFilename, workDir, args );
                        LuaAPI.lua_pushboolean(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_streamingAssetsPathInWWW(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, FileUtilityEx.streamingAssetsPathInWWW);
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            return 1;
        }
        
        
        
		
		
		
		
    }
}
