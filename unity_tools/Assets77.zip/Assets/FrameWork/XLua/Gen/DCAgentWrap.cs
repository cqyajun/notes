﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class DCAgentWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(DCAgent);
			Utils.BeginObjectRegister(type, L, translator, 0, 2, 0, 0);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "initWithAppIdAndChannelId", _m_initWithAppIdAndChannelId);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Clone", _m_Clone);
			
			
			
			
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 10, 0, 0);
			Utils.RegisterFunc(L, Utils.CLS_IDX, "getInstance", _m_getInstance_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "setReportMode", _m_setReportMode_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "setUploadInterval", _m_setUploadInterval_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "setVersion", _m_setVersion_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "reportError", _m_reportError_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "setDebugMode", _m_setDebugMode_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "uploadNow", _m_uploadNow_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "getUID", _m_getUID_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "openAdTracking", _m_openAdTracking_xlua_st_);
            
			
            
			
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					DCAgent __cl_gen_ret = new DCAgent();
					translator.Push(L, __cl_gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception __gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to DCAgent constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_getInstance_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    
                        DCAgent __cl_gen_ret = DCAgent.getInstance(  );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_initWithAppIdAndChannelId(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                DCAgent __cl_gen_to_be_invoked = (DCAgent)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string appId = LuaAPI.lua_tostring(L, 2);
                    string channelId = LuaAPI.lua_tostring(L, 3);
                    
                    __cl_gen_to_be_invoked.initWithAppIdAndChannelId( appId, channelId );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_setReportMode_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    DCReportMode mode;translator.Get(L, 1, out mode);
                    
                    DCAgent.setReportMode( mode );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_setUploadInterval_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    uint time = LuaAPI.xlua_touint(L, 1);
                    
                    DCAgent.setUploadInterval( time );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_setVersion_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string appVersion = LuaAPI.lua_tostring(L, 1);
                    
                    DCAgent.setVersion( appVersion );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_reportError_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string titile = LuaAPI.lua_tostring(L, 1);
                    string error = LuaAPI.lua_tostring(L, 2);
                    
                    DCAgent.reportError( titile, error );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_setDebugMode_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    bool mode = LuaAPI.lua_toboolean(L, 1);
                    
                    DCAgent.setDebugMode( mode );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_uploadNow_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    
                    DCAgent.uploadNow(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_getUID_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    
                        string __cl_gen_ret = DCAgent.getUID(  );
                        LuaAPI.lua_pushstring(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_openAdTracking_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    
                    DCAgent.openAdTracking(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Clone(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                DCAgent __cl_gen_to_be_invoked = (DCAgent)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        UnityEngine.MonoBehaviour __cl_gen_ret = __cl_gen_to_be_invoked.Clone(  );
                        translator.Push(L, __cl_gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception __gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + __gen_e);
            }
            
        }
        
        
        
        
        
        
		
		
		
		
    }
}
