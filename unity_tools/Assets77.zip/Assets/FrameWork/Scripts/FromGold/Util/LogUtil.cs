﻿using System;
using UnityEngine;

public static class LogUtil
{
    public static void SetUnityLogEnable(bool enable)
    {
        UnityEngine.Debug.logger.logEnabled = enable;
    }
}
