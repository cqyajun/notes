﻿using UnityEngine;
using System.Collections;
using System.IO;

public static class SecurityUtility  {

    public static string GetMd5HashFromFile(string fileName) {
        System.IO.FileStream fileStream = new System.IO.FileStream(fileName, System.IO.FileMode.Open);
        return GetMd5FromStream(fileStream);
    }

    public static string GetMd5HashFromStr(string text) {
        return GetMd5HashFromBytes(System.Text.Encoding.UTF8.GetBytes(text));
    }

    public static string GetMd5HashFromBytes(byte[] data) {
        System.IO.MemoryStream stream = new System.IO.MemoryStream(data);
        return GetMd5FromStream(stream);
    }

    static string GetMd5FromStream(System.IO.Stream stream) {
        System.Security.Cryptography.MD5 md5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
        byte[] retVal = md5.ComputeHash(stream);
        stream.Close();

        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        for (int i = 0; i < retVal.Length; i++) {
            sb.Append(retVal[i].ToString("x2"));
        }
        return sb.ToString();
    }

}
