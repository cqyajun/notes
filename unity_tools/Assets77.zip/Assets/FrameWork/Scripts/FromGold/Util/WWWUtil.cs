﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.Events;

public static class WWWUtil {

    public static WWWOperation Get(string url) {
        var wwwData = new WWWOperation();
        wwwData.www = new WWW(url);
        CoroutineUtil.instance.AddCoroutine(wwwData);
        return wwwData;
    }

    public static WWWOperation Post(string url, WWWForm content, UnityAction<float> progress = null) {
        var wwwData = new WWWOperation();
        wwwData.www = new WWW(url, content);
        CoroutineUtil.instance.AddCoroutine(wwwData);
        return wwwData;
    }

}



public class WWWOperation : IEnumerator {

    private Action<WWW> mOnNext;
    private Action<string> mOnError;
    private Action<float> mOnProgress;

    public WWW www;

    public object Current {
        get { return null; }
    }

    public bool MoveNext() {
        if (mOnProgress != null) {
            mOnProgress(www.progress);
        }

        if (www.isDone) {
            try {
                if (www.error != null) {
                    if (mOnError != null) {
                        mOnError(www.error);
                    }
                } else {
                    if (mOnNext != null) {
                        mOnNext(www);
                    }
                }
            } catch (Exception) {
            }
            return true;
        }
        return false;
    }

    public void Reset() {

    }

    public WWWOperation Subscribe(Action<WWW> onComplete, Action<string> onError = null) {
        mOnNext = onComplete;
        mOnError = onError;
        return this;
    }

    public WWWOperation SubscribeWithProgress(Action<WWW> onComplete, Action<string> onError = null, Action<float> onProgress = null) {
        mOnNext = onComplete;
        mOnError = onError;
        mOnProgress = onProgress;
        return this;
    }
}