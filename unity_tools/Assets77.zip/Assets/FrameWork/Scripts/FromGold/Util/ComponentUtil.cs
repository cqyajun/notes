﻿using System;
using UnityEngine;
using System.Collections;
using System.Reflection;
using Object = UnityEngine.Object;

public static class ComponentUtil  {

    public static void SetLayer(Transform transform, int layer, bool includeChild) {
        transform.gameObject.layer = layer;
        if (includeChild) {
            var c = transform.childCount;
            for (var i = 0; i < c; i++) {
                var child = transform.GetChild(i);
                SetLayer(child, layer, true);
            }
        }
    }

    public static GameObject InstantiateLocal(GameObject original, GameObject parent) {
        return InstantiateLocal(original, parent, Vector3.zero);
    }

    public static GameObject InstantiateLocal(GameObject original) {
        return InstantiateLocal(original, null, Vector3.zero);
    }

    public static GameObject InstantiateLocal(GameObject original, Vector3 pos) {
        return InstantiateLocal(original, null, pos);
    }

    public static GameObject InstantiateLocal(GameObject original, GameObject parent, Vector3 pos) {
        var tranformTa = original.transform;
        if (pos == Vector3.zero) pos = tranformTa.localPosition;
        var rota = tranformTa.localRotation;
        var scale = tranformTa.localScale;
        var clone = Object.Instantiate(original);
        var transform = clone.transform;
        if (parent != null) clone.transform.SetParent(parent.transform);
        transform.localPosition = pos;
        transform.localScale = scale;
        transform.localRotation = rota;
        return clone;
    }

    /// <summary>
    /// </summary>
    /// <param name="original"></param>
    /// <param name="parent"></param>
    /// <returns></returns>
    public static GameObject InstantiateGlobal(GameObject original, GameObject parent = null) {
        var tranformTa = original.transform;
        var pos = tranformTa.position;
        var rota = tranformTa.rotation;
        var scale = tranformTa.localScale;
        var clone = Object.Instantiate(original);
        var transform = clone.transform;
        if (parent != null) clone.transform.SetParent(parent.transform);
        transform.position = pos;
        transform.localScale = scale;
        transform.rotation = rota;
        return clone;
    }

    /// <summary>
    /// 设置父对象
    /// </summary>
    /// <param name="child"></param>
    /// <param name="parent"></param>
    public static void SetParent(GameObject child, GameObject parent) {
        var tranformTa = child.transform;
        var pos = tranformTa.localPosition;
        var rota = tranformTa.localRotation;
        var scale = tranformTa.localScale;

        child.transform.SetParent(parent.transform);
        tranformTa.localPosition = pos;
        tranformTa.localScale = scale;
        tranformTa.localRotation = rota;
    }

    /// <summary>
    /// getType
    /// </summary>
    /// <param name="classname"></param>
    /// <returns></returns>
    public static Type GetClassType(string classname) {
        //if (string.IsNullOrEmpty(classname)) return null;
        //return Type.GetType(classname);
        //应该不需要用到
        Type t = null;
        var assbs = AppDomain.CurrentDomain.GetAssemblies();
        Assembly assb = null;
        for (var i = 0; i < assbs.Length; i++) {
            assb = assbs[i];
            t = assb.GetType(classname);
            if (t != null) {
                return t;
            }
        }

        return null;
    }

    public static GameObject Find(GameObject obj, string path) {
        Transform trans = obj.transform.Find(path);
        if (trans != null) {
            return trans.gameObject;
        }
        else {
            return null;
        }
    }

    public static Component GetComponent(GameObject obj, string classname) {
        var t = GetClassType(classname);
        return GetComponent(obj, t);
    }

    public static Component GetComponent(GameObject obj, Type t) {
        Component comp = null;
        if ((obj != null) && (t != null)) comp = obj.GetComponent(t);
        return comp;
    }

    public static Component AddComponent(GameObject obj, string className) {
        var t = GetClassType(className);
        return AddComponent(obj, t);
    }


    public static Component AddComponent(GameObject obj, Type t) {
        Component comp = null;
        comp = GetComponent(obj, t);
        if (comp == null) comp = obj.AddComponent(t);

        return comp;
    }

    public static Component GetComponentWithPath(GameObject obj, string path, string classname) {
        Component comp = null;

        Transform tr = obj.transform.Find(path);
        if (tr) {
            comp = GetComponent(tr.gameObject, classname);
        }
        return comp;
    }

    public static Component[] GetComponents(GameObject obj, string classname) {
        var t = GetClassType(classname);
        return GetComponents(obj, t);
    }

    public static Component[] GetComponents(GameObject obj, Type t) {
        Component[] comp = null;
        if ((obj != null) && (t != null)) comp = obj.GetComponents(t);
        return comp;
    }


    public static Component[] GetComponentsInChildren(GameObject obj, string classname) {
        var t = GetClassType(classname);
        return GetComponentsInChildren(obj, t);
    }

    public static Component[] GetComponentsInChildren(GameObject obj, Type t) {
        if ((t != null) && (obj != null)) return obj.transform.GetComponentsInChildren(t,true);
        return null;
    }


    public static Component GetComponentInChildren(GameObject obj, string classname) {
        var t = GetClassType(classname);
        return GetComponentInChildren(obj, t);
    }


    public static Component GetComponentInChildren(GameObject obj, Type t) {
        Component comp = null;
        if ((t != null) && (obj != null)) comp = obj.GetComponentInChildren(t);
        return comp;
    }

    public static Transform[] GetAllChild(GameObject obj) {
        Transform[] child = null;
        var count = obj.transform.childCount;
        child = new Transform[count];
        for (var i = 0; i < count; i++) {
            child[i] = obj.transform.GetChild(i);
        }
        return child;
    }


    public static void GetAllChildAndCallback(GameObject parent, System.Action<int,GameObject> eachFn) {
        var pr = parent.transform;
        var count = pr.childCount;
        Transform child = null;
        for (var i = 0; i < count; i++) {
            child = pr.GetChild(i);
            eachFn(i, child.gameObject);
        }
    }


    static public GameObject AddChild(GameObject parent)
    {
        return AddChild(parent, "New Game Obejct");
    }

    static public GameObject AddChild(GameObject parent, string name)
    {
        GameObject go = new GameObject(name);

        if (parent != null)
        {
            Transform t = go.transform;
            t.SetParent(parent.transform);
            t.localPosition = Vector3.zero;
            t.localRotation = Quaternion.identity;
            t.localScale = Vector3.one;
            go.layer = parent.layer;
        }
        return go;
    }


    static public GameObject AddChild(Transform tranParent)
    {
        return AddChild(tranParent.gameObject);
    }

    /// <summary>
    /// Instantiate an object and add it to the specified parent.
    /// </summary>

    static public GameObject AddChild(GameObject parent, GameObject prefab)
    {
        GameObject go = Object.Instantiate(prefab);

        if (go != null && parent != null)
        {
            prefab.name = prefab.name.Replace("(Clone)", "");
            RectTransform rectTransform = go.transform as RectTransform;
            if (rectTransform != null)
            {
                rectTransform.SetParent(parent.transform);
                rectTransform.localRotation = Quaternion.identity;
                rectTransform.localScale = Vector3.one;
                rectTransform.sizeDelta = Vector2.zero;
                rectTransform.anchoredPosition3D = Vector3.zero;
            }
            else
            {
                Transform t = go.transform;
                t.localPosition = Vector3.zero;
                t.SetParent(parent.transform);
                t.localRotation = Quaternion.identity;
                t.localScale = Vector3.one;
            }


            go.layer = parent.layer;
        }
        return go;
    }

    public static void DestroyComponent(UnityEngine.Object obj)
    {
        GameObject.Destroy(obj);
    }
}
