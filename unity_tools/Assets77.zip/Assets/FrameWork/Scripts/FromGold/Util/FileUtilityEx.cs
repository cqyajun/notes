﻿using System;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Threading;
using UnityEngine;
using System.Collections.Generic;
using System.Text;

public static class FileUtilityEx
{

    /// <summary>
    /// www获取各平台的StreamingAssets。末尾不带"/"符号。
    /// </summary>
    public static string streamingAssetsPathInWWW {
        get {
#if UNITY_EDITOR
            return "file:///" + Application.streamingAssetsPath;
#elif UNITY_ANDROID
            return Application.streamingAssetsPath;
#elif UNITY_IPHONE
            return "file:///" + Application.streamingAssetsPath;
#elif UNITY_STANDALONE
            return Application.streamingAssetsPath;
#endif
        }
    }


    /// <summary>
    /// 保存文件，如果文件的目录不存会自动创建
    /// </summary>
    /// <param name="fullPath"> 文件的详细路径，一般需要带扩展名结尾 </param>
    /// <param name="fileContent"> 文件内容 </param>
    /// <param name="append"> 是添加内容还是替换 </param>
    public static void SaveFile(string fullPath, byte[] fileContent, bool append = false) {

        string dir = Path.GetDirectoryName(fullPath);
        if (dir != null && !Directory.Exists(dir)) {
            Directory.CreateDirectory(dir);
        }

        FileStream stream = null;

        if (append) {
            stream = new FileStream(fullPath, FileMode.Append);
            stream.Write(fileContent, (int)stream.Position, fileContent.Length);
        } else {
            stream = new FileStream(fullPath, FileMode.Create);
            stream.Write(fileContent, 0, fileContent.Length);
        }

        stream.Flush();
        stream.Close();
        stream.Dispose();
    }

    public static void SaveFile(string fullPath, string text) {
        byte[] bytes = System.Text.Encoding.UTF8.GetBytes(text);
        SaveFile(fullPath, bytes);
    }

    /// <summary>
    /// 删除目录下的所有东西。如果直接使用Directory.Delete()在目录下有文件的情况下会失败
    /// </summary>
    /// <param name="directoryPath"> 目录地址 </param>
    /// <param name="includeSelfDirectory"> 是否包括本身的目录 </param>
    public static void DeleteDirectory(string directoryPath, bool includeSelfDirectory = true) {
        if (!Directory.Exists(directoryPath)) {
            return;
        }

        string[] dirs = Directory.GetDirectories(directoryPath);
        for (int i = 0, count = dirs.Length; i < count; ++i) {
            Directory.Delete(dirs[i], true);
        }
        string[] files = Directory.GetFiles(directoryPath);
        foreach (string f in files) {
            File.Delete(f);
        }
    }

    public static void DownloadFile(string serverUrl, string saveFile, Action<string> onDownload, Action<float> onProgress = null) {
        WWWUtil.Get(serverUrl).SubscribeWithProgress(x => {
            SaveFile(saveFile, x.bytes);
            if (onDownload != null) {
                onDownload("download sucess");
            }
        }, error => {
            if (onDownload != null) {
                onDownload(error);
            }
        }, progress => {
            if (onProgress != null) {
                onProgress(progress);
            }
        });
    }

    public static bool DirectoryExists(string path) {
        return Directory.Exists(path);
    }

    public static void DirectoryDelete(string path, bool recursive) {
        Directory.Delete(path, recursive);
    }

    public static void DirectoryCreate(string path) {
        Directory.CreateDirectory(path);
    }

    public static bool Exists(string path) {
        return File.Exists(path);
    }

    public static void Delete(string path) {
        File.Delete(path);
    }

    public static bool Copy(string fileSourpath,string fileDestpath) {
        bool isExist = File.Exists(fileSourpath);
        if(!isExist){
            return false;
        }
        isExist = File.Exists(fileDestpath);
        if(isExist){
            File.Delete(fileDestpath);
        }
        File.Copy(fileSourpath, fileDestpath);
        isExist = File.Exists(fileDestpath);
        return isExist;
    }

    public static void DirectoryCopy(string srcPath, string destPath)
    {
        DirectoryInfo dir = new DirectoryInfo(srcPath);
        FileSystemInfo[] fileinfo = dir.GetFileSystemInfos();//获取目录下（不包含子目录）的文件和子目录
        foreach (FileSystemInfo i in fileinfo)
        {
            if (i is DirectoryInfo) //判断是否文件夹
            {
                if (!Directory.Exists(destPath + "/" + i.Name))
                {
                    Directory.CreateDirectory(destPath + "/" + i.Name); //目标目录下不存在此文件夹即创建子文件夹
                }
                DirectoryCopy(i.FullName, destPath + "/" + i.Name);//递归调用复制子文件夹
            }else{
                File.Copy(i.FullName, destPath + "/" + i.Name, true);
            }
       }
    }

    public static void WriteAllText(string path, string content) {
        File.WriteAllText(path, content, Encoding.UTF8);
    }

    public static string ReadAllText(string path) {
        return File.ReadAllText(path);
    }


    //同步解压缩
    public static int Decompress7Zip(string sourceFile, string extractFileDirectory, bool largeFiles, bool fullPaths) {
        if (!Directory.Exists(extractFileDirectory)) {
            Directory.CreateDirectory(extractFileDirectory);
        }
        int ret = lzma.doDecompress7zip(sourceFile, extractFileDirectory, largeFiles, fullPaths);
        return ret;
    }

    //异步解压缩
    public static void Decompress7ZipAsync(string sourceFile, string extractFileDirectory, bool largeFiles, bool fullPaths, Action<int> onResult = null, Action<int> onProgress = null) {
        if (!Directory.Exists(extractFileDirectory)) {
            Directory.CreateDirectory(extractFileDirectory);
        }
        CoroutineUtil.instance.StartCoroutine(Decompress7ZipAsyncCoroutine(sourceFile, extractFileDirectory, largeFiles, fullPaths, onResult, onProgress));
    }

    public static bool ExecuteProgram(string exeFilename, string workDir, string args)  
    {  
        ProcessStartInfo info = new ProcessStartInfo();  
        info.FileName = exeFilename;  
        info.WorkingDirectory = workDir;  
        info.UseShellExecute = true;  
        info.Arguments = args;  
        info.WindowStyle = ProcessWindowStyle.Hidden;  
      
        Process task = null;  
        bool rt = true;  
        try  
        {           
            UnityEngine.Debug.Log("ExecuteProgram:" + args);      
            task = Process.Start(info);  
            if (task != null)  
            {  
                task.WaitForExit(60000);  
            }  
            else  
            {  
                return false;  
            }  
        }  
        catch (Exception e)  
        {  
            UnityEngine.Debug.LogError("ExecuteProgram:" + e.ToString()); 
            return false;  
        }   
        finally  
        {  
            if (task != null && task.HasExited)  
            {  
                rt = (task.ExitCode == 0);  
            }  
        }  
      
        return rt;  
    } 

    static IEnumerator Decompress7ZipAsyncCoroutine(string sourceFile, string extractFileDirectory, bool largeFiles, bool fullPaths, Action<int> onResult = null, Action<int> onProgress = null){
        int[] progress = new int[1];
        int result = 0;
        var thread = new Thread(() => {     //需要创建目录
            result = lzma.doDecompress7zip(sourceFile, extractFileDirectory, progress, false, true);
        });
        thread.Start();
        while (thread.IsAlive) {   //多线程解压完成才进行下一步
            if (onProgress != null) {
                onProgress(progress[0]);
            }
            yield return 0;
        }
        if (onResult != null) {
            onResult(result);
        }
    }

}
