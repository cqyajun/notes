﻿using UnityEngine;
using System.Collections;
using System;
using UnityEngine.UI;
using DG.Tweening;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;
using System.Collections.Generic;
using System.Reflection;

public static class CustomerUtil
{
    public static void ReloadCurScene() {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        GC.Collect();
        Resources.UnloadUnusedAssets();
    }

    public static void UnloadUnusedAssets() {
        Resources.UnloadUnusedAssets();
    }

    /// <summary>  
    /// 对相机截图。   
    /// </summary>  
    /// <returns>The screenshot2.</returns>
    /// <param name="imageSavePath">保存路径</param>
    /// <param name="camera">Camera.要被截屏的相机</param>
    /// <param name="x"></param>
    /// <param name="y"></param>
    /// <param name="width"></param>
    /// <param name="height"></param>  
    public static bool CaptureCamera(string imageSavePath, Camera camera, float x, float y, float width, float height) {
        // 创建一个RenderTexture对象  
        try {
            Rect rect = new Rect(x, y, width, height);
            RenderTexture rt = new RenderTexture((int)rect.width, (int)rect.height, 0);
            // 临时设置相关相机的targetTexture为rt, 并手动渲染相关相机  
            camera.targetTexture = rt;
            camera.Render();
            //ps: --- 如果这样加上第二个相机，可以实现只截图某几个指定的相机一起看到的图像。
            //ps: camera2.targetTexture = rt;  
            //ps: camera2.Render();  
            //ps: -------------------------------------------------------------------  

            // 激活这个rt, 并从中中读取像素。  
            RenderTexture.active = rt;
            Texture2D screenShot = new Texture2D((int)rect.width, (int)rect.height, TextureFormat.RGB24, false);
            screenShot.ReadPixels(rect, 0, 0);// 注：这个时候，它是从RenderTexture.active中读取像素  
            screenShot.Apply();

            // 重置相关参数，以使用camera继续在屏幕上显示  
            camera.targetTexture = null;
            //ps: camera2.targetTexture = null;  
            RenderTexture.active = null; // JC: added to avoid errors  
            Object.Destroy(rt);
            // 最后将这些纹理数据，成一个png图片文件  
            byte[] bytes = screenShot.EncodeToJPG();
            System.IO.File.WriteAllBytes(imageSavePath, bytes);
            return true;
        } catch (Exception ex) {
            Debug.LogAssertion(ex);
            return false;
        }
    }

    public static void SetPos(GameObject obj, float x, float y, float z)
    {
        obj.transform.position = new Vector3(x, y, z);
    }

    public static void SetLocalPos(GameObject obj, float x, float y, float z)
    {
        obj.transform.localPosition = new Vector3(x, y, z);
    }

    public static void SetScale(GameObject obj, float x, float y, float z)
    {
        obj.transform.localScale = new Vector3(x, y, z);
    }

    public static void SetAlpha(Image img, float a)
    {
        img.color = new Color(img.color.r, img.color.g, img.color.b, a);
    }

    public static void SetAlpha(RawImage img, float a)
    {
        img.color = new Color(img.color.r, img.color.g, img.color.b, a);
    }

    public static GameObject Instantiate(GameObject obj, GameObject parent)
    {
        GameObject go = GameObject.Instantiate(obj, parent.transform) as GameObject;
        return go;
    }

    public static GameObject InstantiateAndReset(GameObject obj, GameObject parent)
    {
        GameObject go = GameObject.Instantiate(obj, parent.transform) as GameObject;
        go.transform.localPosition = Vector3.zero;
        go.transform.localEulerAngles = Vector3.zero;
        go.transform.localScale = Vector3.one;
        return go;
    }

    public static void StartCoroutineToWaitOneFrame(MonoBehaviour mono, Action callback)
    {
        if (mono)
        {
            mono.StartCoroutine(WaitOneFrame(callback));
        }
        else
        {
            Debug.Log("StartCoroutine error--------------");
        }
    }
    private static IEnumerator WaitOneFrame(Action callback)
    {
        yield return new WaitForEndOfFrame();
        if (callback != null)
        {
            callback();
        }
    }

    public static Sequence SetAlphaYoyo(Image img, float a, float t)
    {
        Sequence seq = DOTween.Sequence();
        Tween tw = DOTween.To(() => img.color.a, (x) => img.color = new Color(img.color.r, img.color.g, img.color.b, x), a, t);
        seq.Append(tw);
        seq.SetAutoKill(false);
        seq.SetLoops(1000000, LoopType.Yoyo);
        return seq;
    }

    public static Sequence FloatTween(float startValue,float endValue,float duration,Action<float> funUpdate,Action funComplete)
    {
        Sequence seq = DOTween.Sequence();
        float tempValue = startValue;
        Tween tw = DOTween.To(() => tempValue, (x) => { tempValue = x; funUpdate(x); }, endValue, duration);
        seq.Append(tw);
        seq.SetAutoKill(true);
        seq.OnComplete(() =>funComplete());
        return seq;
    }

    public static Vector2 ConvertVector2(float x, float y)
    {
        return new Vector2(x, y);
    }

    public static Vector3 ConvertVector3(float x, float y, float z)
    {
        return new Vector3(x, y, z);
    }

    public static Color ConvertColor(float r,float g,float b,float a)
    {
        return new Color(r,g,b,a);
    }

    public static Color ConvertColor32(byte r, byte g, byte b, byte a)
    {
        return new Color32(r, g, b, a);
    }

    /// <summary>
    /// 转换成TargetRectTransform的物体坐标
    /// </summary>
    /// <param name="camera">摄像机</param>
    /// <param name="source">需要转换的RectTransform</param>
    /// <param name="target">目标的坐标地址</param>
    /// <returns></returns>
    public static Vector2 ConverToTargetRectTransformChildPos(Camera camera, RectTransform source, RectTransform target) {

        Vector2 local;
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(source, RectTransformUtility.WorldToScreenPoint(camera, target.position), camera, out local)) {
            //EditorApplication.isPaused = true;
            Debug.Log(String.Format("坐标转换失败，{0}", local));
        }
        return local;
    }

    //public static Vector2 ConverToTargetRectTransformChildPosWithScreenPoint(Camera camera, Vector2 screenPos, RectTransform target) {

    //    Vector2 local;
    //    if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(source, RectTransformUtility.WorldToScreenPoint(camera, target.position), camera, out local)) {
    //        //EditorApplication.isPaused = true;
    //        Debug.Log(String.Format("坐标转换失败，{0}", local));
    //    }
    //    return local;
    //}

    public static string GetScreenShotPath()
    {
        string imagePath = "";

        if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
        {
            imagePath = Application.persistentDataPath;
        }
        else if (Application.platform == RuntimePlatform.WindowsEditor)
        {
            imagePath = Application.dataPath;
            imagePath = imagePath.Replace("/Assets", null);
        }

        imagePath = imagePath + "/screencapture.jpg";
        return imagePath;
    }

    /// <summary>  
    /// 对相机截图。   
    /// </summary>  
    /// <returns>The screenshot2.</returns>  
    /// <param name="camera">Camera.要被截屏的相机</param>  
    /// <param name="rect">Rect.截屏的区域</param>  
    public static string CaptureCamera(Camera camera, Rect rect)
    {
        // 创建一个RenderTexture对象  
        RenderTexture rt = new RenderTexture((int)rect.width, (int)rect.height, 0);
        // 临时设置相关相机的targetTexture为rt, 并手动渲染相关相机  
        camera.targetTexture = rt;
        camera.Render();
        //ps: --- 如果这样加上第二个相机，可以实现只截图某几个指定的相机一起看到的图像。  
        //ps: camera2.targetTexture = rt;  
        //ps: camera2.Render();  
        //ps: -------------------------------------------------------------------  

        // 激活这个rt, 并从中中读取像素。  
        RenderTexture.active = rt;
        Texture2D screenShot = new Texture2D((int)rect.width, (int)rect.height, TextureFormat.RGB24, false);
        screenShot.ReadPixels(rect, 0, 0);// 注：这个时候，它是从RenderTexture.active中读取像素  
        screenShot.Apply();

        // 重置相关参数，以使用camera继续在屏幕上显示  
        camera.targetTexture = null;
        //ps: camera2.targetTexture = null;  
        RenderTexture.active = null; // JC: added to avoid errors  
        GameObject.Destroy(rt);
        // 最后将这些纹理数据，成一个png图片文件  
        byte[] bytes = screenShot.EncodeToJPG();
        string filePath = GetScreenShotPath();
        System.IO.File.WriteAllBytes(filePath, bytes);

        return filePath;
    }

    public static UnityEngine.UI.Toggle[] ConvertToggleIEnumerableToAry(System.Collections.Generic.IEnumerable<UnityEngine.UI.Toggle> ieCollection)
    {
        List<UnityEngine.UI.Toggle> tempList = new List<UnityEngine.UI.Toggle>();
        foreach (var p in ieCollection)
        {
            tempList.Add(p);
        }
        return tempList.ToArray();
    }

    public static string GetMd5HashFromStr(string text)
    {
        return SecurityUtility.GetMd5HashFromBytes(System.Text.Encoding.UTF8.GetBytes(text));
    }

    public static string ReplaceStrToBlankForText(string str,string pattern)
    {
        return str.Replace(pattern, "\u3000");
    }

    public static string ReplaceStr(string str,string pattern,string target)
    {
        return str.Replace(pattern, target);
    }
}
