﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class VoiceChatManager
{
    public static string voiceParentPath;

    /// <summary>初始化语音sdk</summary>    
    public static void InitVoice(uint mAppId, bool mIfTest, string path)
    {
        //voiceParentPath = path;
        //Debug.Log("测试环境：" + mIfTest);
        //ClearCacheResource();
        //int init = YunVaImSDK.instance.YunVa_Init(0, mAppId, voiceParentPath + "/cache", mIfTest);
        //Debug.Log(init == 0 ? "云娃语音初始化成功" : "云娃语音初始化失败");
    }
    /// <summary>
    /// 登录语音sdk，游戏进入主界面之前调用此接口，不同客户端不能登陆相同uid，目前tt  为 {"uid":"账号","nickname":"昵称"}  该json格式，
    /// 由游戏方的应用账号和游戏角色名称来进行绑定；
    ///  uid要全局唯一，如果不同区服有相同的uid建议gameServerID+用户编号（uid）组成新的uid
    /// </summary>
    public static void LoginVoice(string uid, string nickname, string severid, Action callback)
    {
        //string ttFormat = "{{\"nickname\":\"{0}\",\"uid\":\"{1}\"}}";
        //string tt = string.Format(ttFormat, nickname, uid);
        //string[] wildcard = new string[2];
        //wildcard[0] = "0x001";
        //wildcard[1] = "0x002";
        //Debug.Log("云娃tt：" + tt);
        //YunVaImSDK.instance.YunVaOnLogin(tt, severid, wildcard, 0, (data) =>
        //{
        //    if (data.result == 0)
        //    {
        //        Debug.Log(string.Format("云娃语音sdk登录成功,昵称：{0}，用户id：{1}", data.nickName, data.userId));
        //    }
        //    else
        //    {
        //        Debug.Log(string.Format("云娃语音sdk登录失败，错误消息：{0}", data.msg));
        //    }
        //    if (callback != null)
        //    {
        //        callback();
        //    }
        //});
    }

    /// <summary>登出语音sdk </summary>
    public static void LogoutVoice()
    {
        //YunVaImSDK.instance.YunVaLogOut();
    }

    /// <summary>开始录音</summary>
    public static void StartRecordVoice()
    {
        //string filePath = string.Format("{0}/{1}.amr", voiceParentPath, DateTime.Now.ToFileTime());
        //YunVaImSDK.instance.RecordStartRequest(filePath);
    }

    /// <summary>结束录音</summary>
    public static void EndRecordVoice(Action<VoiceResult> path)
    {
        //YunVaImSDK.instance.RecordStopRequest((data) =>
        //{
        //    if (!string.IsNullOrEmpty(data.strfilepath))
        //    {
        //        float len = data.time / 1000f;
        //        uint lenght = (uint)Math.Round(len);
        //        path(GetVoiceResult(data.strfilepath, lenght.ToString()));
        //        Debug.Log("停止录音返回:" + data.strfilepath);
        //    }
        //    else
        //    {
        //        path(GetVoiceResult(data.msg, "", -1));
        //    }
        //});
    }

    /// <summary>开始播放语音文件<param name="url"></param>
    public static void StartPlayVoice(string filepath, string url, Action<VoiceResult> action)
    {
        //YunVaImSDK.instance.RecordStartPlayRequest(filepath, url, "", (data) =>
        //{
        //    if (data.result == 0)
        //    {
        //        Debug.Log("播放成功");
        //        action(GetVoiceResult(""));
        //    }
        //    else
        //    {
        //        Debug.Log("播放失败");
        //        action(GetVoiceResult(data.describe, data.ext, (int)data.result));
        //    }
        //});
    }

    /// <summary>停止语音播放</summary>
    public static void EndPlayVoice()
    {
        //YunVaImSDK.instance.RecordStopPlayRequest();
    }

    /// <summary>设置语音识别语言</summary>
    public static void SetSpeechLanguage()
    {
        //YunVaImSDK.instance.SpeechSetLanguage(Yvimspeech_language.im_speech_zn, yvimspeech_outlanguage.im_speechout_simplified);
    }

    /// <summary>开始语音识别</summary>
    public static void StartIdentifyVoice(string path, Action<VoiceResult> info)
    {
        //YunVaImSDK.instance.SpeechStartRequest(path, "", (data) =>
        //{
        //    if (data.result == 0)
        //    {
        //        info(GetVoiceResult(data.text));
        //        Debug.Log("识别成功，识别内容:" + data.text);

        //    }
        //    else
        //    {
        //        info(GetVoiceResult(data.msg, "", -1));
        //        Debug.Log("识别失败，原因:" + data.msg);
        //    }
        //});
    }

    /// <summary>上传语音文件 <param name="url"></param>
    public static void UploadVoice(string path, string fileId, Action<VoiceResult> url)
    {
        //YunVaImSDK.instance.UploadFileRequest(path, fileId, (data) =>
        //{
        //    if (data.result == 0)
        //    {
        //        url(GetVoiceResult(data.fileurl));
        //        Debug.Log("上传成功");
        //    }
        //    else
        //    {
        //        url(GetVoiceResult(data.msg));
        //        Debug.Log("上传失败");
        //    }
        //});
    }

    /// <summary>下载语音文件</summary>
    public static void DownloadVoice(String url, string fileid, Action<VoiceResult> filepath)
    {
        //Debug.Log("下载地址：" + url + "-----下载路径：" + voiceParentPath + "/" + fileid + ".amr");
        //YunVaImSDK.instance.DownLoadFileRequest(url, voiceParentPath + "/" + fileid, fileid + ".amr", (data) =>
        //{
        //    if (data.result == 0)
        //    {
        //        Debug.Log("下载成功:" + data.filename);
        //        filepath(GetVoiceResult(data.filename));
        //    }
        //    else
        //    {
        //        Debug.Log("下载失败，错误码：" + data.result + "   " + data.msg);
        //        filepath(GetVoiceResult(data.msg, "", -1));
        //    }
        //});
    }

    /// <summary>语音回调类<returns></returns>
    private static VoiceResult GetVoiceResult(string ext, string ext2 = "", int code = 0)
    {
        VoiceResult result = new VoiceResult();
        result.error = code;
        result.ext = ext;
        result.ext2 = ext2;
        return result;
    }

    public static void ClearCacheResource()
    {
        FileUtility.DeleteDirectory(voiceParentPath);
    }
}



/// <summary>语音回调类</summary>
public class VoiceResult
{
    public int error;
    public string ext;
    public string ext2;
}
