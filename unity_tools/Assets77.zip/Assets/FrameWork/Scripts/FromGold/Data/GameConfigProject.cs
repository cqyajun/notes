﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class GameConfigProject : Singleton<GameConfigProject>
{
#if UNITY_EDITOR
    public enum LoadType
    {
        /// <summary> 从编辑器本地路径中提取 </summary>
        SimulateEditor = 0,
        /// <summary> 从App应中加载 </summary>
        FromAppAssets = 1,
    }
#endif

    /// <summary>是否显示FPS</summary>
    public bool showFpsPanel;
    /// <summary>是否显示日志输出</summary>
    public bool showLogPanel;
    /// <summary>资源的加载方式</summary>
    public int assetLoadType;
    /// <summary>是否检测版本更新</summary>
    public bool shouldCheckVersion=false;
    /// <summary></summary>
    public int selectServerIndex = 0;
    /// <summary></summary>
    public int selectPackageIndex = 0;

    public bool testServerIp = false;
    public string testServerIpValue = "192.168.1.83";
    public bool testServerPort = false;
    public string testServerPortValue = "10000";
    public bool testAppVersion = false;
    public string testAppVersionValue = "1.0.0";
    public bool testBunldIdFlag = true;
    public string testBunldIdValue = "com.bunld.default";
    //直连模式
    public bool isDirectConnectIp = false;
}
