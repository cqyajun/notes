﻿using System;
using UnityEngine;

public class MonoBehaviourEventDispatcher : MonoBehaviour
{
    public Action onAwakeFn;
    public Action onStartFn;
    public Action onUpdateFn;
    public Action onFixedUpdateFn;
    public Action onLateUpdateFn;
    public Action onOnDisableFn;
    public Action onOnEnableFn;
    public Action onOnDestroyFn;
    public Action<bool> onOnApplicationFocusFn;
    public Action<bool> onOnApplicationPauseFn;
    public Action onOnApplicationQuitFn;

    public void RemoveAllEvents()
    {
        onAwakeFn = null;
        onStartFn = null;
        onUpdateFn = null;
        onFixedUpdateFn = null;
        onLateUpdateFn = null;
        onOnDisableFn = null;
        onOnEnableFn = null;
        onOnDestroyFn = null;
        onOnApplicationFocusFn = null;
        onOnApplicationPauseFn = null;
        onOnApplicationQuitFn = null;
    }

    void Awake()
    {
        if (onAwakeFn != null)
        {
            onAwakeFn();
        }
    }

    void Start()
    {
        if (onStartFn != null)
        {
            onStartFn();
        }
    }

    void Update()
    {
        if (onUpdateFn != null)
        {
            onUpdateFn();
        }
    }

    void FixedUpdate()
    {
        if (onFixedUpdateFn != null)
        {
            onFixedUpdateFn();
        }
    }

    void LateUpdate()
    {
        if (onLateUpdateFn != null)
        {
            onLateUpdateFn();
        }
    }

    void OnDisable()
    {
        if (onOnDisableFn != null)
        {
            onOnDisableFn();
        }
    }

    void OnEnable()
    {
        if (onOnEnableFn != null)
        {
            onOnEnableFn();
        }
    }

    void OnDestroy()
    {
        if (onOnDestroyFn != null)
        {
            onOnDestroyFn();
        }
    }

    void OnApplicationFocus(bool focusStatus)
    {
        if (onOnApplicationFocusFn != null)
        {
            onOnApplicationFocusFn(focusStatus);
        }
    }

    void OnApplicationPause(bool pauseStatus)
    {
        if (onOnApplicationPauseFn != null)
        {
            onOnApplicationPauseFn(pauseStatus);
        }
    }

    void OnApplicationQuit()
    {
        if (onOnApplicationQuitFn != null)
        {
            onOnApplicationQuitFn();
        }
    }
}  
