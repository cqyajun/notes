﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace UGUIExtend
{
    /// <summary>
    /// 事件接受并抛给lua
    /// </summary>
    public class GameEventCollector : MonoBehaviour
    {
        public string packageName;

        public string moduleName;

        public void OnPointerDown(BaseEventData eventData)
        {
            var g = EventSystem.current.currentSelectedGameObject;
            GameUGUIEventDispatcher.onPressHandle(packageName, moduleName, g, eventData);
        }

        public void OnPointerUp(BaseEventData eventData)
        {
            var g = EventSystem.current.currentSelectedGameObject;
            GameUGUIEventDispatcher.onPressHandle(packageName, moduleName, g, eventData);
        }

        public void OnBeginDrag(BaseEventData eventData)
        {
            var g = EventSystem.current.currentSelectedGameObject;
            GameUGUIEventDispatcher.onCancelHandle(packageName, moduleName, g, eventData);
        }

        public void OnDrag(BaseEventData eventData)
        {
            var g = EventSystem.current.currentSelectedGameObject;
            PointerEventData ped = eventData as PointerEventData;
            GameUGUIEventDispatcher.onDragHandle(packageName, moduleName, g, ped.delta);
        }

        public void OnDrop(BaseEventData eventData)
        {
            var g = EventSystem.current.currentSelectedGameObject;
            GameUGUIEventDispatcher.onDropHandle(packageName, moduleName, g, eventData);
        }

        public void OnPointerClick(BaseEventData eventData)
        {
            //PointerEventData ped = eventData as PointerEventData;
            var g = EventSystem.current.currentSelectedGameObject;
            GameUGUIEventDispatcher.onClickHandle(packageName, moduleName, g, eventData);
        }

        public void OnSelect(BaseEventData eventData)
        {
            var g = EventSystem.current.currentSelectedGameObject;
            GameUGUIEventDispatcher.onSelectHandle(packageName, moduleName, g, eventData);
        }

        public void OnCancel(BaseEventData eventData)
        {
            var g = EventSystem.current.currentSelectedGameObject;
            GameUGUIEventDispatcher.onCancelHandle(packageName, moduleName, g, eventData);
        }

        public void OnButtonClick()
        {
            var g = EventSystem.current.currentSelectedGameObject;
            GameUGUIEventDispatcher.onClickHandle(packageName, moduleName, g); //Debug.Log("you are click "+g);
        }

        public void OnButtonClick(PointerEventData pointerEventData)
        {
            var g = EventSystem.current.currentSelectedGameObject;
            GameUGUIEventDispatcher.onClickHandle(packageName, moduleName, g); //Debug.Log("you are click "+g);
        }


        public void OnCustomerEvent(MonoBehaviour arg)
        {
            var g = EventSystem.current.currentSelectedGameObject;
            GameUGUIEventDispatcher.onCustomerHandle(packageName, moduleName, g, arg); //Debug.Log("you are click "+g);
        }

    }
}