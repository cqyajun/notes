﻿/*****************************************************
 * 作者: 龙涛
 * 创建时间：2015-10-23
 * 版本：1.0.0
 * 描述：与EventTriggerListener不同点在于,响应不会被阻塞
 ****************************************************/

using System;
using UnityEngine;
using System.Collections;
using UGUIExtend;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class GameEventTriggerClickListener : MonoBehaviour, IPointerClickHandler, IPointerDownHandler, IPointerUpHandler, IDragHandler
{
    public GameEventCollector gameEventCollector;

    public void OnPointerClick(PointerEventData eventData)
    {
        if (gameEventCollector != null)
        {
            gameEventCollector.OnButtonClick();
        }
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        if (gameEventCollector)
        {
            gameEventCollector.OnPointerDown(eventData);
        }
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        if (gameEventCollector)
        {
            gameEventCollector.OnPointerUp(eventData);
        }
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (gameEventCollector)
        {
            gameEventCollector.OnDrag(eventData);
        }
    }
}