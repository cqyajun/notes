﻿// Copyright (c) 2014 hugula
// direct https://github.com/tenvick/hugula

using UnityEngine;

/// <summary>
/// 事件处理
/// </summary>
public static class GameUGUIEventDispatcher
{
    #region public

    public static void onCustomerHandle(string packageName, string moduleName, object sender, object arg)
    {
        if (onCustomerFn != null)
        {
            onCustomerFn(packageName, moduleName, sender, arg);
        }
    }

    public static void onCustomerHandle(string packageName, string moduleName, object sender, Vector3 arg)
    {
        if (onCustomerFn != null && sender != null)
        {
            onCustomerFn(packageName, moduleName, sender, arg);
        }
    }

    public static void onPressHandle(string packageName, string moduleName, object sender, object arg)
    {
        if (onPressFn != null && sender != null)
        {
            onPressFn(packageName, moduleName, sender, arg);
        }
    }
    public static void onPressHandle(string packageName, string moduleName, object sender, bool arg)
    {
        if (onPressFn != null && sender != null)
        {
            onPressFn(packageName, moduleName, sender, arg);
        }
    }

    public static void onClickHandle(string packageName, string moduleName, object sender, object arg)
    {
        if (onClickFn != null && sender != null)
        {
            onClickFn(packageName, moduleName, sender, arg);
        }
    }

    public static void onClickHandle(string packageName, string moduleName, object sender)
    {
        if (onClickFn != null && sender != null)
        {
            onClickFn(packageName, moduleName, sender, null);
        }
    }

    public static void onDragHandle(string packageName, string moduleName, object sender, Vector3 arg)
    {
        if (onDragFn != null && sender != null)
        {
            onDragFn(packageName, moduleName, sender, arg);
        }
    }

    public static void onDropHandle(string packageName, string moduleName, object sender, object arg)
    {
        if (onDropFn != null && sender != null)
        {
            onDropFn(packageName, moduleName, sender, arg);
        }
    }

    public static void onDropHandle(string packageName, string moduleName, object sender, bool arg)
    {
        if (onDropFn != null && sender != null)
        {
            onDropFn(packageName, moduleName, sender, arg);
        }
    }

    public static void onDropHandle(string packageName, string moduleName, object sender, Vector3 arg)
    {
        if (onDropFn != null && sender != null)
        {
            onDropFn(packageName, moduleName, sender, arg);
        }
    }

    public static void onSelectHandle(string packageName, string moduleName, object sender, object arg)
    {
        if (onSelectFn != null && sender != null)
        {
            onSelectFn(packageName, moduleName, sender, arg);
        }
    }

    public static void onCancelHandle(string packageName, string moduleName, object sender, object arg)
    {
        if (onCancelFn != null && sender != null)
        {
            onCancelFn(packageName, moduleName, sender, arg);
        }
    }

    public static void RemoveAllEvents()
    {
        onCustomerFn = null;
        onPressFn = null;
        onClickFn = null;
        onDragFn = null;
        onDropFn = null;
        onSelectFn = null;
        onCancelFn = null;
    }

    #endregion

    public static System.Action<string, string, object, object> onCustomerFn;

    public static System.Action<string, string, object, object> onPressFn;

    public static System.Action<string, string, object, object> onClickFn;

    public static System.Action<string, string, object, object> onDragFn;

    public static System.Action<string, string, object, object> onDropFn;

    public static System.Action<string, string, object, object> onSelectFn;

    public static System.Action<string, string, object, object> onCancelFn;
}