﻿/*****************************************************
 * 作者: 刘靖 不到万不得已别找我
 * 创建时间：2015.n.n
 * 版本：1.0.0
 * 描述：UGUI图文混排
 ****************************************************/
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

[ExecuteInEditMode]
public class TextWrapEx : MonoBehaviour 
{
    public enum WrapMode
    {
        /// <summary>（x=0为最左端）文本从左到右排列</summary>
        L_R,
        /// <summary>（x=0为最右端）文本从右到左排列</summary>
        R_L,
        /// <summary>（x=0为最中间）文本左右两边散开</summary>
        Center,
    }

    /// <summary>所引用的图集</summary>
    [SerializeField]
    private SpriteAtlas mAtlas;
    public SpriteAtlas atlas
    {
        get
        {
            return mAtlas;
        }
        set
        {
            if (mAtlas == value) return;
            mAtlas = value;                        
            TextChange();
        }
    } 

    [SerializeField]
    private string mText = "";
    [SerializeField]
    private WrapMode mMode = WrapMode.L_R;
    [SerializeField]
    private float mInterval = 0.0f;
    [SerializeField]
    private int numCount = 10;
    [SerializeField]
    private Vector2 mImageSize = new Vector2(0, 0);


    public List<Image> imageList = new List<Image>();
    public List<Transform> transList = new List<Transform>();
    public List<RectTransform> rectTransList = new List<RectTransform>();

    private List<string> symbolList = new List<string>();

    public int NumCount
    {
        get
        {
            return numCount;
        }
        set
        {
            if (value > numCount)
            {
                for (int i = 0; i < value - numCount; i++)
                {
                    NewObj();
                }
            }
            else if (value < numCount)
            {
                for (int i = 0; i < numCount - value; i++)
                {
                    GameObject object_ = transform.GetChild(0).gameObject;
#if UNITY_EDITOR
                    DestroyImmediate(object_);
#else
                    Destroy(object_);
#endif
                }
            }

            numCount = value;
        }
    }

    public Vector2 imageSize 
    {
        get
        {
            return mImageSize;
        }
        set
        {
            if (mImageSize == value) return;
            mImageSize = value;
            TextChange();
        }
    }

    public string text
    {
        get
        {
            return mText;
        }
        set
        {
            if (mText == value) return;            
            mText = value;
            TextChange();
        }
    }

    public WrapMode mode
    {
        get 
        {
            return mMode;
        }
        set
        {
            if (mMode == value) return;            
            mMode = value;
            TextChange();            
        }
    }

    public float interval
    {
        get 
        {
            return mInterval;
        }
        set
        {
            if (mInterval == value) return;
            mInterval = value;
            TextChange();
        }
    }

    private float sizeScale=1.0f;
    private float intervalScale = 1.0f;


    Image NewObj()
    {
        GameObject object_ = new GameObject();
        object_.name = "textwrap";
        RectTransform rectTrans = object_.AddComponent<RectTransform>();
        rectTrans.SetParent(transform);
        rectTrans.localRotation = Quaternion.identity;
        rectTrans.localPosition = Vector3.zero;
        rectTrans.localScale = Vector3.one;
        Image image=object_.AddComponent<Image>();
        image.maskable = false;
        object_.SetActive(false);
        return image;
    }

    void CheckObjLoaded()
    {
        if (imageList.Count == numCount && imageList.Count == transform.childCount && imageList.Count == transList.Count && imageList.Count == rectTransList.Count)
        {
            return;
        }

        imageList.Clear();
        transList.Clear();
        rectTransList.Clear();

        if (transform.childCount == 0)
        {
            for (int i = 0; i < numCount; i++)
            {
                imageList.Add(NewObj());
            }
        }
        else
        {
            for (int i = 0; i < transform.childCount; i++)
            {
                imageList.Add(transform.GetChild(i).gameObject.GetComponent<Image>());
            }
        }

        for (int i = 0; i < imageList.Count; i++)
        {
            transList.Add(imageList[i].transform);
        }

        for (int i = 0; i < imageList.Count; i++)
        {
            rectTransList.Add(imageList[i].rectTransform);
        }        
    }
    
    void Awake()
    {
        CheckObjLoaded();
    }

    public void TextChange()
    {
        CheckObjLoaded();

        if(mText.Length > numCount)
        {
            Debug.LogError("TextWrapEx,图文混排越界！");
            return;
        }

        for (int i = mText.Length; i < numCount; i++)
        {
            transList[i].gameObject.SetActive(false);
        }

        symbolList.Clear();
        for (int i = 0; i < mText.Length; i++)
        {
            symbolList.Add(mText[i].ToString());
        }

        switch(mMode)
        {
            case WrapMode.L_R:
                {
                    for (int i = 0; i < symbolList.Count; i++)
                    {
                        int index = atlas.keys.IndexOf(symbolList[i]);                        
                        if (index>=0)
                        {
                            rectTransList[i].sizeDelta = mImageSize;
                            SetImage(i, atlas.values[index], new Vector3((mImageSize.x + mInterval) * i, 0, 0));
                        }
                        else
                        {
                            Debug.LogError(string.Format("TextWrapEx存在未识别的标示符 :{0}!", symbolList[i]));
                            return;
                        }
                    }
                }
                break;
            case WrapMode.R_L:
                {
                    for (int i = symbolList.Count - 1; i >= 0; i--) 
                    {
                        int index = atlas.keys.IndexOf(symbolList[i]);
                        if (index >= 0)
                        {
                            rectTransList[i].sizeDelta=mImageSize;
                            SetImage(i, atlas.values[index], new Vector3(-(mImageSize.x + mInterval) * (symbolList.Count - 1 - i), 0, 0));
                        }
                        else
                        {
                            Debug.LogError("TextWrapEx存在未识别的标示符!");
                            return;
                        }
                    }
                }
                break;
            case WrapMode.Center:
                {
                    for (int i = 0; i < symbolList.Count; i++)
                    {
                        int index = atlas.keys.IndexOf(symbolList[i]);
                        if (index >= 0)
                        {
                            rectTransList[i].sizeDelta=mImageSize;
                            SetImage(i, atlas.values[index], new Vector3((mImageSize.x + mInterval) * (i - (symbolList.Count - 1) / 2.0f), 0, 0));
                        }
                        else
                        {
                            Debug.LogError("TextWrapEx存在未识别的标示符!--->                " + symbolList[i] + "    ----->    " + symbolList[i]);
                            return;
                        }
                    }
                }
                break;
        }
    }

    public void SetImage(int index,Sprite sprite,Vector3 lposition)
    {
        imageList[index].sprite = sprite;
        imageList[index].maskable = false;
        imageList[index].SetNativeSize();
        rectTransList[index].localPosition = Vector3.Scale(new Vector3(intervalScale,1,1), lposition);
        SetTransFormActive(index,true);
    }

    public void SetSizeScale(float scale)
    {
        this.sizeScale = scale;
        for(int i = 0; i < transList.Count; ++i)
        {
            transList[i].localScale = scale * Vector3.one;
        }
    }

    public void SetIntervalScale(float scale)
    {
        this.intervalScale = scale;
    }

    public void SetTransFormActive(int index,bool active)
    {
        transList[index].gameObject.SetActive(active);
    }
}
