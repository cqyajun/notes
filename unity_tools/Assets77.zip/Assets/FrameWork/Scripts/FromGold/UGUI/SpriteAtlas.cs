﻿/********************************************************************
	created:	2015/05/11
	author:		dred
	purpose:	textwrap的引用字符图片集合
*********************************************************************/

using UnityEngine.UI;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SpriteAtlas : MonoBehaviour 
{
    public List<string> keys = new List<string>();
    public List<Sprite> values = new List<Sprite>();
}


