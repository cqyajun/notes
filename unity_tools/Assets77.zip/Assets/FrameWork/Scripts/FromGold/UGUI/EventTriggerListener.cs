﻿/*****************************************************
 * 作者: 刘靖 不到万不得已别找我
 * 创建时间：2014.n.n
 * 版本：1.0.0
 * 描述：类似于NGUI的UIEventListener
 ****************************************************/
using UnityEngine;
using System.Collections;
using System.Runtime.CompilerServices;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class EventTriggerListener : EventTrigger
{
    public delegate void VoidDelegate(GameObject go, PointerEventData eventData);
    public delegate void BoolDelegate(GameObject go, bool isPress, PointerEventData eventData);

    public VoidDelegate onClick;
    public VoidDelegate onDown;
    public VoidDelegate onEnter;
    public VoidDelegate onExit;
    public VoidDelegate onUp;
    public VoidDelegate onSelect;
    public VoidDelegate onUpdateSelect;
    public VoidDelegate onDragEx;
    public VoidDelegate onBeginDragEx;
    public VoidDelegate onEndDragEx;
    public VoidDelegate onScroll;
    public BoolDelegate onPress;

    bool mIsPress;
    PointerEventData mEventData;

    private bool mIsDrag;
    private Vector2 mDragDelta;

    static public EventTriggerListener Get(GameObject go)
    {
        EventTriggerListener listener = go.GetComponent<EventTriggerListener>();
        if (listener == null) listener = go.AddComponent<EventTriggerListener>();
        return listener;
    }

    public override void OnPointerClick(PointerEventData eventData)
    {
        if (onClick != null) onClick(gameObject, eventData);
    }
    public override void OnPointerDown(PointerEventData eventData)
    {
        mIsPress = true;
        mEventData = eventData;
        if (onDown != null) onDown(gameObject, eventData);
    }
    public override void OnPointerEnter(PointerEventData eventData)
    {
        if (onEnter != null) onEnter(gameObject, eventData);
    }
    public override void OnPointerExit(PointerEventData eventData)
    {
        if (onExit != null) onExit(gameObject, eventData);
    }
    public override void OnPointerUp(PointerEventData eventData)
    {
        mIsPress = false;
        mEventData = eventData;
        if (onUp != null) onUp(gameObject, eventData);
    }
    public override void OnDrag(PointerEventData eventData)
    {
        base.OnDrag(eventData);
        if (onDragEx != null) onDragEx(gameObject, eventData);
    }
    public override void OnBeginDrag(PointerEventData eventData)
    {
        base.OnBeginDrag(eventData);
        if (onBeginDragEx != null) onBeginDragEx(gameObject, eventData);
    }

    public override void OnEndDrag(PointerEventData eventData)
    {
        base.OnEndDrag(eventData);
        if (onEndDragEx != null) onEndDragEx(gameObject, eventData);
    }

#if UNITY_EDITOR
    public override void OnScroll(PointerEventData eventData)
    {
        base.OnScroll(eventData);
        if (onScroll != null) onScroll(gameObject, eventData);
    }
#endif

    void Update()
    {
        if (onPress != null) onPress(gameObject, mIsPress, mEventData);
    }
}