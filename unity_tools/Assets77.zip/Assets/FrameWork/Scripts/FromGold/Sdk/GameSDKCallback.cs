﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using System.Collections;
using XLua;
using UnityEngine.Events;
//using cn.SMSSDK.Unity;

/// <summary>
/// 回调 Android和IOS走同样的回调接口，保证接口的统一性
/// </summary>
public class GameSDKCallback : MonoBehaviour
{
    private static GameSDKCallback _instance;

    public LuaFunction gameSdkCallback;

    public static GameSDKCallback instance
    {
        get
        {
            if (_instance == null)
            {
                GameObject callback = GameObject.Find("GameSDKCallback");
                if (callback == null)
                {
                    callback = new GameObject("GameSDKCallback");
                    DontDestroyOnLoad(callback);
                    _instance = callback.AddComponent<GameSDKCallback>();

                    //SMSSDK.instance.setHandler(_instance);
                }
                else
                {
                    _instance = callback.GetComponent<GameSDKCallback>();
                }
            }
            return _instance;
        }
    }

    public void OnInit(string state)
    {
        Debug.Log("Callback->OnInit:" + state);
        if (gameSdkCallback != null)
        {
            gameSdkCallback.Call("onInit", state);
        }
    }


    /// <summary>
    /// 微信授权回调
    /// </summary>
    /// <param name="data"></param>
    public void OnLoginWechatResult(string data)
    {
        Debug.Log("Callback->OnLoginWechatResult:" + data);
        if (gameSdkCallback != null)
        {
            gameSdkCallback.Call("onLoginWechatResult", data);
        }
    }

    //登录成功回调
    public void OnLoginSuc(string jsonData)
    {
        Debug.Log("Callback->OnLoginSuc:" + jsonData);
        if (gameSdkCallback != null)
        {
            gameSdkCallback.Call("onLoginSuc", jsonData);
        }
    }

    //切换帐号回调
    public void OnSwitchLogin()
    {
        Debug.LogError("Callback->OnSwitchLogin");
        if (gameSdkCallback != null)
        {
            gameSdkCallback.Call("onSwitchLogin");
        }
    }

    //登出回调
    public void OnLogout()
    {
        Debug.LogError("Callback->OnLogout");
        if (gameSdkCallback != null)
        {
            gameSdkCallback.Call("onLogout");
        }
    }

    public void OnShareResult(string data)
    {
        Debug.LogError("Callback->OnShareResult");
        if (gameSdkCallback != null)
        {
            gameSdkCallback.Call("onShareResult", data);
        }
    }

    public void onComplete(int action, object resp)
    {
        Debug.LogError("Callback->onComplete");
        if (gameSdkCallback != null)
        {
            string[] dataAry = new string[2];
            dataAry[0] = action + "";
            dataAry[1] = resp as string;
            gameSdkCallback.Call("SMSSDKHandler_onComplete", dataAry);
        }
    }

    public void onError(int action, object resp)
    {
        Debug.LogError("Callback->onError");
        if (gameSdkCallback != null)
        {
            string[] dataAry = new string[2];
            dataAry[0] = action + "";
            dataAry[1] = resp as string;
            gameSdkCallback.Call("SMSSDKHandler_onError", dataAry);
        }
    }

    public void OnIAPResult(string data)
    {
        if (gameSdkCallback != null)
        {
            gameSdkCallback.Call("onIAPResult", data);
        }
    }
}