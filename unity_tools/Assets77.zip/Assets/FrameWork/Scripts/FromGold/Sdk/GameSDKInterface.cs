﻿/*****************************************************
 * 作者: DRed(龙涛) 1036409576@qq.com
 * 创建时间：2015.12.23
 * 版本：1.0.0
 * 描述：
 ****************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using UnityEngine;

public abstract class GameSDKInterface
{
    public delegate void LoginSucHandler(U8LoginResult data);
    public delegate void LogoutHandler();

    private static GameSDKInterface _instance;

    public static GameSDKInterface instance
    {
        get
        {
            if (_instance == null)
            {
#if UNITY_EDITOR || UNITY_STANDLONE
                _instance = new SDKInterfaceDefault();
#elif UNITY_ANDROID
                _instance = new U8SDKInterfaceAndroid();
#elif UNITY_IPHONE
                _instance = new SDKInterfaceIOS();
#endif
            }

            return _instance;
        }
    }

    //获取渠道名
    public abstract string GetChannelName();

    public abstract string GetPackageBunldId();

    public string GetPlatformName(){ return Application.platform.ToString(); }

    public abstract string ReadFileFromeAssets(string fileName);

    public abstract bool AssetsFileExist(string fileName);
    //是否使用SDK
    public abstract bool IsUseSdk();

    //初始化
    public abstract void Init();

    //登录
    public abstract void Login();

    //自定义登录，用于腾讯应用宝，QQ登录，customData="QQ";微信登录，customData="WX"
    public abstract void LoginCustom(string customData);

    //切换帐号
    public abstract void SwitchLogin();

    //登出
    public abstract bool Logout();

    //显示个人中心
    public abstract bool ShowAccountCenter();

    //上传游戏数据
    public abstract void SubmitGameData(U8ExtraGameData data);

    //调用SDK的退出确认框,返回false，说明SDK不支持退出确认框，游戏需要使用自己的退出确认框
    public abstract bool SDKExit();

    //调用SDK支付界面
    public abstract void Pay(U8PayParams data);

    //SDK是否支持退出确认框
    public abstract bool IsSupportExit();

    //SDK是否支持用户中心
    public abstract bool IsSupportAccountCenter();

    //SDK是否支持登出
    public abstract bool IsSupportLogout();

    public abstract bool RestartApplication();

    //获取使用地区和语言zh_CN中国中文
    public abstract string GetCountry();

    public abstract string GetCarrier();

    //获取手机运用商中国移动 中国联通 中国电信 ...
    public abstract string GetNewCarrier();

    //获取设备的IDFA
    public abstract string GetIDFA();
    /// <summary>
    /// 获取本地图片
    /// </summary>
    public abstract void GetNativeAvatar(int size);
    /// <summary>
    /// 获取验证码
    /// </summary>
    public abstract void GetVerify(SmsLoginPara loginpara);
    /// <summary>
    /// 提交验证码
    /// </summary>
    public abstract void SubmitVerify(SmsLoginPara loginpara);


#if !UNITY_EDITOR && UNITY_IPHONE
    public abstract string GetAccountFromKeychain();
    public abstract string GetPasswordFromKeychain();
    public abstract bool SaveAccountPasswordToKeychain(string account, string password); 
#endif

    //处理IP，因为ios需要支持IPV6
    public abstract bool ProcessIpAndAddressFamily(string ipv4, out string newServerIp, out AddressFamily ipAddressFamily);
    /// <summary>
    /// 分享图片到微信
    /// </summary>
    /// <param name="data"></param>
    public abstract void ShareImageToWeixin(ShareWeixinPara data);
    /// <summary>
    /// 分享文字到微信
    /// </summary>
    /// <param name="data"></param>
    public abstract void ShareTextToWeixin(ShareWeixinPara data);
    /// <summary>
    /// 分享url到微信
    /// </summary>
    /// <param name="data"></param>
    public abstract void ShareUrlToWeixin(ShareWeixinPara data);
    /// <summary>
    /// 获取当前信号
    /// </summary>
    public abstract int GetCurSignalStrenth();
    /// <summary>
    /// 获取型号类型
    /// </summary>
    public abstract string GetCurSignalType();
    /// <summary>
    /// 获取当前电量
    /// </summary>
    public abstract int GetCurBatteryLevel();
    /// <summary>
    /// 手机震动
    /// </summary>
    public abstract void ShakePhone(long ms);
    /// <summary>
    /// 获取当前手机是不是在充电
    /// </summary>
    public abstract bool GetCurChargeState();

    /// <summary>
    /// 根据appid初始化微信sdk
    /// </summary>
    /// <param name="appid"></param>
    public abstract void InitWechat(string appid);

    /// <summary>
    /// 登录微信
    /// </summary>
    /// <param name="appid">appid</param>
    /// <param name="appsecret">appsecret</param>
    public abstract void LoginWechat();
    /// <summary>
    /// 分享Url
    /// </summary>
    /// <param name="json">json</param>
    public abstract void ShareUrl(string json);
    /// <summary>
    /// 分享图片
    /// </summary>
    /// <param name="json">json</param>
    public abstract void ShareImage(string json);
    /// <summary>
    /// 初始化百度SDK
    /// </summary>
    /// <param name="appid"></param>
    public abstract void InitBaiduSDK(string appid);
    /// <summary>
    /// 请求定位信息
    /// </summary>
    public abstract void RequestLocation();
    /// <summary>
    /// 获取定位信息
    /// </summary>
    public abstract string GetLocation();
    /// <summary>
    /// 获取启动或者唤醒参数
    /// </summary>
    public abstract string GetInitParam();
    public abstract void ClearInitParam();
    /// <summary>
    /// 剪贴板功能
    /// </summary>
    public abstract bool CopyTextToClipboard(string str);
    public abstract string GetTextFromClipboard();
    /// <summary>
    /// 判断指定包是否安装
    /// </summary>
    public abstract bool IsPkgInstalled(string packageName);
    /// <summary>
    /// 获取设备唯一标识ID
    /// </summary>
    public abstract string GetUnionDeviceId();
	/// <summary>
    /// 初始化苹果支付
    /// </summary>
    public abstract void InitIAP(string productsIdStr);
    /// <summary>
    /// 请求苹果支付
    /// </summary>
    /// <param name="productId">苹果后台对应的产品id</param>
    public abstract void RequestIAP(string productId);
    /// <summary>
    /// 跳转微信
    /// </summary>
    public abstract void GotoWeChat();
}

/// <summary>
/// 支付接口需要的参数
/// </summary>
public class U8PayParams
{
    //游戏中商品ID
    public string productId { get; set; }

    //游戏中商品名称，比如元宝，钻石...
    public string productName { get; set; }

    //游戏中商品描述
    public string productDesc { get; set; }

    //价格，单位为元
    public int price { get; set; }

    //购买数量,一般都为1.注意下，比如游戏中“100元宝”是一条充值商品，
    //对应的价格是90元。那么上面price是90元。这里buyNum=1而不是100
    public int buyNum { get; set; }

    //当前玩家身上剩余的虚拟币数量
    public int coinNum { get; set; }

    //当前角色所在的服务器ID
    public string serverId { get; set; }

    //当前角色所在的服务器名称
    public string serverName { get; set; }

    //帐号ID
    public string accountId { get; set; }

    //当前角色ID
    public string roleId { get; set; }

    //当前角色名称
    public string roleName { get; set; }

    //当前角色等级
    public int roleLevel { get; set; }

    //当前角色的vip等级
    public string vip { get; set; }

    //游戏服务器订单号，由服务器生成
    public string orderID { get; set; }

    //服务器冲值的回调地址
    public string payNotifyUrl { get; set; }

    //扩展字段，由游戏服务器生成，各个渠道SDK可能不一样
    public string extension { get; set; }
}


/// <summary>
/// 数据上报接口需要的参数
/// </summary>
public class U8ExtraGameData
{

    public const int TYPE_SELECT_SERVER = 1;        //选择服务器
    public const int TYPE_CREATE_ROLE = 2;          //创建角色
    public const int TYPE_ENTER_GAME = 3;           //进入游戏
    public const int TYPE_LEVEL_UP = 4;				//等级提升
    public const int TYPE_EXIT_GAME = 5;			//退出游戏

    //调用时机，设置为上面定义的类型，在各个对应的地方调用submitGameData方法
    public int dataType { get; set; }

    //角色ID
    public string roleID { get; set; }

    //角色名称
    public string roleName { get; set; }

    //角色等级
    public string roleLevel { get; set; }

    //服务器ID
    public int serverID { get; set; }

    //服务器名称
    public string serverName { get; set; }

    //当前角色生成拥有的虚拟币数量
    public int moneyNum { get; set; }
}

/// <summary>
/// U8SDK 登录结果
/// </summary>
public class U8LoginResult
{
    //是否认证成功
    public bool isSuc { get; set; }

    //当前是否为SDK界面中切换帐号的回调
    public bool isSwitchAccount { get; set; }

    //u8server返回的userID
    public string userID { get; set; }

    //渠道SDK的userID
    public string sdkUserID { get; set; }

    //u8server返回的用户名
    public string username { get; set; }

    //渠道SDK的用户名
    public string sdkUsername { get; set; }

    //u8server返回的用于登录认证的凭据
    public string token { get; set; }

}
/// <summary>
/// 短信登录参数
/// </summary>
public class SmsLoginPara
{
    /// <summary>
    /// 国家代码
    /// </summary>
    public string country;
    /// <summary>
    /// 电话号码
    /// </summary>
    public string phone;
    /// <summary>
    /// 验证码
    /// </summary>
    public string code;
}
/// <summary>
/// 微信分享相关参数
/// </summary>
public class ShareWeixinPara
{
    /// <summary>
    /// 分享的图片路径或者url缩略图路径
    /// </summary>
    public string imgpath = "";
    /// <summary>
    /// 分享的文字
    /// </summary>
    public string text = "";
    /// <summary>
    /// 分享的url标题
    /// </summary>
    public string title = "";
    /// <summary>
    /// 分享的url
    /// </summary>
    public string url = "";
    /// <summary>
    /// 分享的url描述
    /// </summary>
    public string desc = "";
    /// <summary>
    /// 是否分享到朋友圈  
    /// </summary>
    public bool chat = false;
}

public enum WechatShareType
{
    Friends = 0,    // 好友/群
    Moments = 1,    // 朋友圈
}
