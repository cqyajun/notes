﻿#if UNITY_EDITOR
/*****************************************************
* 作者: DRed(龙涛) 1036409576@qq.com
* 创建时间：2015.12.23
* 版本：1.0.0
* 描述: 代表没接SDK
****************************************************/

using System;
using System.IO;
using UnityEngine;
using System.Linq;
using System.Net.Sockets;
using System.Text;

public class SDKInterfaceDefault : GameSDKInterface
{
    public override bool IsUseSdk()
    {
        return false;
    }

    public override void Init()
    {
        GameSDKCallback.instance.OnInit("success");
    }

    public override void Login()
    {
        throw new NotImplementedException();
    }

    public override void LoginCustom(string customData)
    {
        throw new NotImplementedException();
    }

    public override void SwitchLogin()
    {
        throw new NotImplementedException();
    }

    public override void GetNativeAvatar(int size)
    {
        throw new NotImplementedException();
    }

    public override void GetVerify(SmsLoginPara loginpara)
    {
        throw new NotImplementedException();
    }

    public override void SubmitVerify(SmsLoginPara loginpara)
    {
        throw new NotImplementedException();
    }

    public override bool Logout()
    {
        return true;
    }

    public override bool ShowAccountCenter()
    {
        return false;
    }

    public override void SubmitGameData(U8ExtraGameData data)
    {
        throw new NotImplementedException();
    }

    public override bool SDKExit()
    {
        return false;
    }

    public override void Pay(U8PayParams data)
    {
        throw new NotImplementedException();
    }

    public override bool IsSupportExit()
    {
        return false;
    }

    public override bool IsSupportAccountCenter()
    {
        return false;
    }

    public override bool IsSupportLogout()
    {
        return false;
    }

    public override string GetCountry()
    {
        return "zh_CN";
    }

    public override string GetCarrier()
    {
        return "Unknown";
    }

    public override string GetNewCarrier()
    {
        return "Unknown";
    }

    public override string GetIDFA()
    {
        return SystemInfo.deviceUniqueIdentifier;
    }

#if !UNITY_EDITOR && UNITY_IPHONE
    public override string GetAccountFromKeychain()
    {
        return "";
    }

    public override string GetPasswordFromKeychain()
    {
        return "";
    }

    public override bool SaveAccountPasswordToKeychain(string account, string password)
    {
        return false;
    } 

#endif

    public override bool ProcessIpAndAddressFamily(string ipv4, out string newServerIp, out AddressFamily ipAddressFamily)
    {
        newServerIp = ipv4;
        ipAddressFamily = AddressFamily.InterNetwork;
        return true;
    }

    public override void ShareImageToWeixin(ShareWeixinPara data)
    {
        throw new NotImplementedException();
    }

    public override void ShareTextToWeixin(ShareWeixinPara data)
    {
        throw new NotImplementedException();
    }

    public override void ShareUrlToWeixin(ShareWeixinPara data)
    {
        throw new NotImplementedException();
    }

    public override int GetCurSignalStrenth()
    {
        return 4;
    }

    public override int GetCurBatteryLevel()
    {
        return 100;
    }

    public override string GetCurSignalType()
    {
        return "wifi";
    }

    public override void ShakePhone(long ms)
    {
        return;
    }

    public override bool GetCurChargeState()
    {
        return true;
    }

    public override bool RestartApplication()
    {
        return true;
    }

    public override void InitWechat(string appid)
    {
    }

    public override void LoginWechat()
    {
    }

    public override void ShareUrl(string json)
    {
    }

    public override void ShareImage(string json)
    {

    }

    public override string GetPackageBunldId()
    {
#if UNITY_EDITOR
        if (GameConfigProject.Instance.testBunldIdFlag)
        {
            return GameConfigProject.Instance.testBunldIdValue;
        }
#endif
        return "com.bunld.default";
    }

    public override string GetChannelName()
    {
        if(AppDefine.PlatformPath == "Android")
        {
            return "android_none";
        }
        else if(AppDefine.PlatformPath == "iOS")
        {
            return "ios_none";
        }        
        else
        {
            return "none";
        }
    }

    public override string ReadFileFromeAssets(string fileName)
    {
        string fileFullPath = Path.Combine(Application.streamingAssetsPath, fileName);
        if (!File.Exists(fileFullPath))
        {
            return "";
        }
        return File.ReadAllText(Path.Combine(Application.streamingAssetsPath, fileName));
    }

    public override bool AssetsFileExist(string fileName)
    {
        string fileFullPath = Path.Combine(Application.streamingAssetsPath, fileName);
        return File.Exists(fileFullPath);
    }
    public override void InitBaiduSDK(string appid)
    {
        throw new NotImplementedException();
    }
    public override void RequestLocation()
    {
        throw new NotImplementedException();
    }

    public override string GetLocation()
    {
        throw new NotImplementedException();
    }

    public override string GetInitParam()
    {
        throw new NotImplementedException();
    }
    public override void ClearInitParam()
    {
        throw new NotImplementedException();
    }
    public override bool CopyTextToClipboard(string str)
    {
        throw new NotImplementedException();
    }
    public override string GetTextFromClipboard()
    {
        throw new NotImplementedException();
    }

    public override bool IsPkgInstalled(string packageName)
    {
        throw new NotImplementedException();
    }

    public override string GetUnionDeviceId()
    {
        throw new NotImplementedException();
    }
	
	public override void InitIAP(string productsIdStr)
    {

    }

    public override void RequestIAP(string productId)
    {
        
    }

    public override void GotoWeChat()
    {

    }
} 
#endif
