﻿#if UNITY_IPHONE
using UnityEngine;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Runtime.InteropServices;
using MyLitJson;

public class SDKInterfaceIOS : GameSDKInterface
{
    //[DllImport("__Internal")]
    //private static extern void IosInit();
    [DllImport("__Internal")]
    private static extern void IosLogin();
    [DllImport("__Internal")]
    private static extern void IosLogout();
    [DllImport("__Internal")]
    private static extern bool IosIsSupportLogout();
    [DllImport("__Internal")]    
    private static extern void IosPayment(string json);
    [DllImport("__Internal")]
    private static extern void IosSubmitGameData(int dataType, string roleID,  string roleName, string roleLevel, int moneyNum, int serverID, string serverName);
    [DllImport("__Internal")]
    private static extern bool IosIsUseThirdPlatform();

    [DllImport("__Internal")]
    private static extern string IosGetThirdPlatformName();
    [DllImport("__Internal")]
    private static extern string IosGetPackageBunldId();
    [DllImport("__Internal")]
    private static extern bool IosIsUseThirdPlatformCenter();
    [DllImport("__Internal")]
    private static extern void IosShowThirdPlatformCenter();

    [DllImport("__Internal")]
    private static extern string IosGetCountry();
    [DllImport("__Internal")]
    private static extern string IosGetNewCarrier();
    [DllImport("__Internal")]
    private static extern string IosGetIDFA();

    [DllImport("__Internal")]
    private static extern string IosGetIpv6(string ipv4);
    [DllImport("__Internal")]
    private static extern string IosGetAccountFromKeychain();
    [DllImport("__Internal")]
    private static extern string IosGetPasswordFromKeychain();
    [DllImport("__Internal")]
    private static extern bool IosSaveAccountPasswordToKeychain(string account, string password);

	[DllImport("__Internal")]
	private static extern void IosInitWechat (string appid);
	[DllImport("__Internal")]
	private static extern void IosLoginWechat ();
	[DllImport("__Internal")]
	private static extern void IosShareUrl (string json);
	[DllImport("__Internal")]
	private static extern void IosShareImage (string json);
	[DllImport("__Internal")]
	private static extern int IosGetCurBatteryLevel();
    [DllImport("__Internal")]
    private static extern string IosGetCurSignalType();
    [DllImport("__Internal")]
	private static extern int IosGetCurSignalStrenth();
    [DllImport("__Internal")]
    private static extern void IosShakePhone();
    [DllImport("__Internal")]
    private static extern bool IosGetCurChargeState();
    [DllImport("__Internal")]
    private static extern void IosInitBaiduSDK(string appid);
    [DllImport("__Internal")]
    private static extern void IosRequestLocation();
    [DllImport("__Internal")]
    private static extern string IosGetLocation();
    [DllImport("__Internal")]
    private static extern string IosGetInitParam();
    [DllImport("__Internal")]
    private static extern void IosClearInitParam();
    [DllImport("__Internal")]
    private static extern bool IosCopyTextToClipboard(string str);
    [DllImport("__Internal")]
    private static extern string IosGetTextFromClipboard();
    [DllImport("__Internal")]
    private static extern bool IosIsPkgInstalled(string packageName);
    [DllImport("__Internal")]
    private static extern string IosGetUnionDeviceId();
	[DllImport("__Internal")]
    private static extern void IosInitIAP(string productsIdStr);
    [DllImport("__Internal")]
    private static extern void IosRequestIAP(string productId);

    /// <summary>
    /// SDK初始化
    /// </summary>
    public override void Init()
    {
        //IosInit();
    }

    /// <summary>
    /// 登录
    /// </summary>
    public override void Login()
    {
        IosLogin();
    }

    /// <summary>
    /// 自定义登录，用于腾讯应用宝，QQ登录，customData="QQ";微信登录，customData="WX"
    /// </summary>
    /// <param name="customData"></param>
    public override void LoginCustom(string customData)
    {

    }

    /// <summary>
    /// 切换帐号
    /// </summary>
    public override void SwitchLogin()
    {
		
    }
    
    /// <summary>
    /// 登出
    /// </summary>
    /// <returns></returns>
    public override bool Logout()
    {
        IosLogout();
        return true;
    }

    /// <summary>
    /// 调用SDK支付
    /// </summary>
    /// <param name="data"></param>
    public override void Pay(U8PayParams data)
    {
        // 改为json 发送，这样在以后增删字段时，方便修改
        string json = encodePayParams(data);
        //UnityEngine.Debug.Log(json);
        //IosPayment(data.productId, data.productName, data.productDesc, data.price, data.serverId, data.serverName, data.roleId, data.roleName, data.roleLevel, data.vip, data.orderID, data.extension);
        IosPayment(json);
    }

    /// <summary>
    /// 上传游戏数据
    /// </summary>
    /// <param name="data"></param>
    public override void SubmitGameData(U8ExtraGameData data)
    {
        IosSubmitGameData(data.dataType, data.roleID, data.roleName, data.roleLevel, data.moneyNum, data.serverID, data.serverName);
    }
/// <summary>
    /// 获取本地图片
    /// </summary>
    public override void GetNativeAvatar(int size)
    {
        //IosSubmitGameData(data.dataType, data.roleID, data.roleName, data.roleLevel, data.moneyNum, data.serverID, data.serverName);
    }

    public override void GetVerify(SmsLoginPara loginpara)
    {
        throw new NotImplementedException();
    }

    public override void SubmitVerify(SmsLoginPara loginpara)
    {
        throw new NotImplementedException();
    }

    public override void ShareImageToWeixin(ShareWeixinPara data)
    {
       // throw new NotImplementedException();
    }

    public override void ShareTextToWeixin(ShareWeixinPara data)
    {
       // throw new NotImplementedException();
    }

    public override void ShareUrlToWeixin(ShareWeixinPara data)
    {
       // throw new NotImplementedException();
    }


    /// <summary>
    /// 是否使用SDK
    /// </summary>
    /// <returns></returns>
    public override bool IsUseSdk()
    {
        return IosIsUseThirdPlatform();
    }

    ///// <summary>
    ///// 获取渠道名
    ///// </summary>
    ///// <returns></returns>
    //public override string GetChannelName()
    //{
    //    return IosGetThirdPlatformName();
    //}

    /// <summary>
    /// SDK是否支持用户中心
    /// </summary>
    /// <returns></returns>
    public override bool IsSupportAccountCenter()
    {
        return IosIsUseThirdPlatformCenter();
    }

    /// <summary>
    /// 显示个人中心
    /// </summary>
    /// <returns></returns>
    public override bool ShowAccountCenter()
    {
        if (!IosIsUseThirdPlatformCenter())
        {
            return false;
        }

        IosShowThirdPlatformCenter();
        return true;
    }

    /// <summary>
    /// 调用SDK的退出确认框,返回false，说明SDK不支持退出确认框，游戏需要使用自己的退出确认框
    /// IOS不需要
    /// </summary>
    /// <returns></returns>
    public override bool SDKExit()
    {
        return false;
    }

    /// <summary>
    /// SDK是否支持退出确认框
    /// IOS不需要
    /// </summary>
    /// <returns></returns>
    public override bool IsSupportExit()
    {
        return false;
    }

    /// <summary>
    /// SDK是否支持登出
    /// </summary>
    /// <returns></returns>
    public override bool IsSupportLogout()
    {
        return IosIsSupportLogout();
    }

#if !UNITY_EDITOR && UNITY_IPHONE
    public override string GetAccountFromKeychain()
    {
        return IosGetAccountFromKeychain();
    }

    public override string GetPasswordFromKeychain()
    {
        return IosGetPasswordFromKeychain();
    }

    public override bool SaveAccountPasswordToKeychain(string account, string password)
    {
        return IosSaveAccountPasswordToKeychain(account, password);
    }
#endif

    public override string GetCountry()
    {
        return IosGetCountry();
    }

    public override string GetCarrier()
    {
        return "Unknown";
    }
    
    public override string GetNewCarrier()
    {
        return IosGetNewCarrier();
    }

    public override string GetIDFA()
    {
        return IosGetIDFA();
    }

    public override bool ProcessIpAndAddressFamily(string ipv4, out string newServerIp, out AddressFamily ipAddressFamily)
    {
        string ipv6 = IosGetIpv6(ipv4);
        newServerIp = ipv4;
        ipAddressFamily = AddressFamily.InterNetwork;
        try
        {
            if (!string.IsNullOrEmpty(ipv6))
            {
                string[] m_StrTemp = System.Text.RegularExpressions.Regex.Split(ipv6, "&&");
                if (m_StrTemp != null && m_StrTemp.Length >= 2)
                {
                    string IPType = m_StrTemp[1];
                    if (IPType == "ipv6")
                    {
                        newServerIp = m_StrTemp[0];
                        ipAddressFamily = AddressFamily.InterNetworkV6;
                        return true;
                    }
                    return false;
                }
            }
        }
        catch (Exception e)
        {
            UnityEngine.Debug.LogError("GetIpv6失败:" + e.ToString());
        }
        return false;
    }

    private string encodeGameData(U8ExtraGameData data)
	{
		Dictionary<string, object> map = new Dictionary<string, object>();
		map.Add("dataType", data.dataType);
		map.Add("roleID", data.roleID);
		map.Add("roleName", data.roleName);
		map.Add("roleLevel", data.roleLevel);
		map.Add("serverID", data.serverID);
		map.Add("serverName", data.serverName);
		map.Add("moneyNum", data.moneyNum);
		return Json.Serialize(map);        
	}
	
	private string encodePayParams(U8PayParams data)
	{
		Dictionary<string, object> map = new Dictionary<string, object>();
		map.Add("productId", data.productId);
		map.Add("productName", data.productName);
		map.Add("productDesc", data.productDesc);
		map.Add("price", data.price);
		map.Add("buyNum", data.buyNum);
		map.Add("coinNum", data.coinNum);
		map.Add("serverId", data.serverId);
		map.Add("serverName", data.serverName);
        map.Add("accountId", data.accountId);
		map.Add("roleId", data.roleId);
		map.Add("roleName", data.roleName);
		map.Add("roleLevel", data.roleLevel);
		map.Add("vip", data.vip);
		map.Add("orderID", data.orderID);
        map.Add("payNotifyUrl", data.payNotifyUrl);
		map.Add("extension", data.extension);
		
		return Json.Serialize(map);        
	}

    public override int GetCurBatteryLevel()
    {
        return IosGetCurBatteryLevel();
    }

    public override string GetCurSignalType()
    {
        return IosGetCurSignalType();
    }

    public override int GetCurSignalStrenth()
    {
        return IosGetCurSignalStrenth();
    }

    public override void ShakePhone(long ms)
    {
        IosShakePhone();
    }

    public override bool GetCurChargeState()
    {
        return IosGetCurChargeState();
    }

    public override void InitWechat(string appid)
    {
        IosInitWechat(appid);
    }

    public override void LoginWechat()
    {
		IosLoginWechat ();
    }

    public override void ShareUrl(string json)
    {
		IosShareUrl (json);
    }

    public override void ShareImage(string json)
    {
		IosShareImage (json);
    }

    public override string GetChannelName()
    {
        return IosGetThirdPlatformName();
    }

    public override string GetPackageBunldId()
    {
        return IosGetPackageBunldId();
    }

    public override string ReadFileFromeAssets(string fileName)
    {
        string fileFullPath = Path.Combine(Application.streamingAssetsPath, fileName);
        if (!File.Exists(fileFullPath))
        {
            return "";
        }
        return File.ReadAllText(Path.Combine(Application.streamingAssetsPath, fileName));
    }

    public override bool AssetsFileExist(string fileName)
    {
        string fileFullPath = Path.Combine(Application.streamingAssetsPath, fileName);
        return File.Exists(fileFullPath);
    }

    public override bool RestartApplication()
    {
        throw new NotImplementedException();
    }

    public override void InitBaiduSDK(string appid)
    {
        IosInitBaiduSDK(appid);
    }

    public override void RequestLocation()
    {
        IosRequestLocation();
    }

    public override string GetLocation()
    {
        return IosGetLocation();
    }

    public override string GetInitParam()
    {
        return IosGetInitParam();
    }

    public override void ClearInitParam()
    {
        IosClearInitParam();
    }

    public override bool CopyTextToClipboard(string str)
    {
        return IosCopyTextToClipboard(str);
    }

    public override string GetTextFromClipboard()
    {
        return IosGetTextFromClipboard();
    }

    public override bool IsPkgInstalled(string packageName)
    {
        return IosIsPkgInstalled(packageName);
    }

    public override string GetUnionDeviceId()
    {
        return IosGetUnionDeviceId();
    }
	
	public override void InitIAP(string productsIdStr)
    {
        IosInitIAP(productsIdStr);
    }

    public override void RequestIAP(string productId)
    {
        IosRequestIAP(productId);
    }

    public override void GotoWeChat()
    {

    }
}
#endif