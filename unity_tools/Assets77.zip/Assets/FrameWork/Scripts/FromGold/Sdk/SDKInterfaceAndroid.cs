﻿#if !UNITY_EDITOR && UNITY_ANDROID
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using UnityEngine;
using MyLitJson;


/// <summary>
/// U8SDK Android平台接口的调用
/// </summary>
public class U8SDKInterfaceAndroid : GameSDKInterface 
{
    private AndroidJavaObject jo;

    public U8SDKInterfaceAndroid()
    {
        using (AndroidJavaClass jc = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
        {
            jo = jc.GetStatic<AndroidJavaObject>("currentActivity");
            Debug.Log("U8SDKInterfaceAndroid");
        }
    }

    private T SDKCall<T>(string method, params object[] param)
    {
        try
        {
            return jo.Call<T>(method, param);
        }
        catch (Exception e)
        {
            Debug.LogError(e);
        }
        return default(T);
    }

    private void SDKCall(string method, params object[] param)
    {
        try
        {
            jo.Call(method, param);
        }
        catch (Exception e)
        {
            Debug.LogError(e);
        }
    }

    public override bool IsUseSdk() 
    {
        return SDKCall<bool>("isUseSdk");
    }

    //这里Android中，在onCreate中直接调用了initSDK，所以这里就不用调用了
    public override void Init()
    {
        //SDKCall("initSDK");        
    }

    public override void Login()
    {
        SDKCall("login");
    }

    public override void LoginCustom(string customData)
    {
        SDKCall("loginCustom", customData);
    }

    public override void SwitchLogin()
    {
        SDKCall("switchLogin");
    }

    public override bool Logout()
    {
        if (!IsSupportLogout())
        {
            return false;
        }

        SDKCall("logout");
        return true;
    }

    public override bool ShowAccountCenter()
    {
        if (!IsSupportAccountCenter())
        {
            return false;
        }

        SDKCall("showAccountCenter");
        return true;
    }

    public override void SubmitGameData(U8ExtraGameData data)
    {
        string json = EncodeGameData(data);
        SDKCall("submitExtraData", json);
    }

    public override bool SDKExit()
    {
        if (!IsSupportExit())
        {
            return false;
        }

        SDKCall("exit");
        return true;
    }

    public override void Pay(U8PayParams data)
    {
        string json = EncodePayParams(data);
        SDKCall("pay", json);
    }

    public override bool IsSupportExit()
    {
        return SDKCall<bool>("isSupportExit");
    }

    public override bool IsSupportAccountCenter()
    {
        return SDKCall<bool>("isSupportAccountCenter");
    }

    public override bool IsSupportLogout()
    {
        return SDKCall<bool>("isSupportLogout");
    }

    public override bool RestartApplication() {
        return SDKCall<bool>("restartApplication");
    }

    public override void  GetNativeAvatar(int size)
    {
        SDKCall("getNativeAvatar",size.ToString());
    }

    public override void GetVerify(SmsLoginPara loginpara)
    {
        string json = EncodeLoginParams(loginpara);
        SDKCall("getVerificationCode", json);
    }

    public override void SubmitVerify(SmsLoginPara loginpara)
    {
        string json = EncodeLoginParams(loginpara);
        SDKCall("submitVerificationCode",json);
    }

    public override string GetCountry() 
    {
        return "zh_CN";
    }

    public override string GetCarrier()
    {
        return "Unknown";
    }
    
    public override string GetNewCarrier()
    {
        return "Unknown";
    }

    public override string GetIDFA() 
    {
        return SystemInfo.deviceUniqueIdentifier;
    }

    public override bool ProcessIpAndAddressFamily(string ipv4, out string newServerIp, out AddressFamily ipAddressFamily) 
    {
        newServerIp = ipv4;
        ipAddressFamily = AddressFamily.InterNetwork;
        return true;
    }

    public override void ShareImageToWeixin(ShareWeixinPara data)
    {
        string json = EncodeWinxinParams(data);
        SDKCall("shareImageToWeixin", json);
    }

    public override void ShareTextToWeixin(ShareWeixinPara data)
    {
        string json = EncodeWinxinParams(data);
        SDKCall("shareTextToWeixin", json);
    }

    public override void ShareUrlToWeixin(ShareWeixinPara data)
    {
        string json = EncodeWinxinParams(data);
        SDKCall("shareUrlToWeixin", json);
    }  

    public override int GetCurSignalStrenth()
    {
        return SDKCall<int>("GetCurSignalStrenth");
    }

    public override int GetCurBatteryLevel()
    {
        return SDKCall<int>("GetCurBatteryLevel");
    }

    public override string GetCurSignalType()
    {
        return SDKCall<string>("GetCurSignalType");
    }

    public override void ShakePhone(long ms)
    {
        SDKCall("VibratorPhone", ms);
    }

    public override bool GetCurChargeState()
    {
        return SDKCall<bool>("GetCurChargeState");
    }

    public override void InitWechat(string appid)
    {
        SDKCall("InitWechat", appid);
    }

    public override void LoginWechat()
    {
        SDKCall("LoginWechat");
    }
    public override void ShareUrl(string json)
    {
        SDKCall("ShareUrl", json);
    }

    public override void ShareImage(string json)
    {
        SDKCall("ShareImage", json);
    }

    private string EncodeGameData(U8ExtraGameData data)
    {
        Dictionary<string, object> map = new Dictionary<string, object>();
        map.Add("dataType", data.dataType);
        map.Add("roleID", data.roleID);
        map.Add("roleName", data.roleName);
        map.Add("roleLevel", data.roleLevel);
        map.Add("serverID", data.serverID);
        map.Add("serverName", data.serverName);
        map.Add("moneyNum", data.moneyNum);
        return Json.Serialize(map);        
    }

    private string EncodePayParams(U8PayParams data)
    {
        Dictionary<string, object> map = new Dictionary<string, object>();
        map.Add("productId", data.productId);
        map.Add("productName", data.productName);
        map.Add("productDesc", data.productDesc);
        map.Add("price", data.price);
        map.Add("buyNum", data.buyNum);
        map.Add("coinNum", data.coinNum);
        map.Add("serverId", data.serverId);
        map.Add("serverName", data.serverName);
        map.Add("roleId", data.roleId);
        map.Add("roleName", data.roleName);
        map.Add("roleLevel", data.roleLevel);
        map.Add("vip", data.vip);
        map.Add("orderID", data.orderID);
        map.Add("payNotifyUrl", data.payNotifyUrl);
        map.Add("extension", data.extension);

        return Json.Serialize(map);        
    }
    private string EncodeLoginParams(SmsLoginPara data)
    {
        Dictionary<string, object> map = new Dictionary<string, object>();
        map.Add("country", data.country);
        map.Add("phone", data.phone);
        map.Add("code", data.code);
        return Json.Serialize(map);
    }

    private string EncodeWinxinParams(ShareWeixinPara data)
    {
        Dictionary<string, object> map = new Dictionary<string, object>();
        map.Add("imgpath", data.imgpath);
        map.Add("text", data.text);
        map.Add("url", data.url);
        map.Add("desc", data.desc);
        map.Add("title", data.title);
        map.Add("chat", data.chat);
        return Json.Serialize(map);
    }

    public override string GetChannelName() 
    {
        return SDKCall<string>("getChannelName");
    }

    public override string GetPackageBunldId()
    {
        return SDKCall<string>("getPackageBunldId");
    }

    public override string ReadFileFromeAssets(string fileName) 
    {
        return SDKCall<string>("readFileFromeAssets", fileName);
    }

    public override bool AssetsFileExist(string fileName) 
    {
        return SDKCall<bool>("assetsFileExist", fileName);
    }

    public override void InitBaiduSDK(string appid)
    {
        
    }

    public override void RequestLocation()
    {
        SDKCall("RequestLocation");
    }

    public override string GetLocation()
    {
        return SDKCall<string>("GetLocation");
    }

    public override string GetInitParam()
    {
        return SDKCall<string>("GetInitParam");
    }
    public override void ClearInitParam()
    {
        SDKCall("ClearInitParam");
    }
    public override bool CopyTextToClipboard(string str)
    {
        return SDKCall<bool>("CopyTextToClipboard",str);
    }
    public override string GetTextFromClipboard()
    {
        return SDKCall<string>("GetTextFromClipboard");
    }

    public override bool IsPkgInstalled(string packageName)
    {
        return SDKCall<bool>("IsPkgInstalled", packageName);
    }

    public override string GetUnionDeviceId()
    {
        return SDKCall<string>("GetUnionDeviceId");
    }
	
	public override void InitIAP(string productsIdStr)
    {
        
    }

    public override void RequestIAP(string productId)
    {
        
    }

    public override void GotoWeChat()
    {
        SDKCall("gotoWechat");
    }
}

#endif