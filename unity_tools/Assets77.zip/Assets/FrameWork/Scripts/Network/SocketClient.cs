﻿using UnityEngine;
using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text.RegularExpressions;

public enum ConnectState
{
    Connect = 0,        //连接服务器
    Connecting = 1,     //正在连接 
    Other = 2
}

public enum ConnectType
{
    Hall = 0,
    Room = 1
}

public class SocketClient
{
    private TcpClient client = null;
    private NetworkStream outStream = null;
    private MemoryStream memStream;
    private BinaryReader reader;
    private ConnectType connectType;
    private ConnectState connectState = ConnectState.Other;

    private const int MAX_READ = 8192;
    private byte[] byteBuffer = new byte[MAX_READ];

    public ConnectState MyConnectState
    {
        get
        {
            return connectState;
        }
        private set
        {
            connectState = value;
        }
    }

    // Use this for initialization
    public SocketClient(ConnectType connectType)
    {
        this.connectType = connectType;
    }

    /// <summary>
    /// 注册代理
    /// </summary>
    public void OnRegister()
    {
        memStream = new MemoryStream();
        reader = new BinaryReader(memStream);
    }

    /// <summary>
    /// 移除代理
    /// </summary>
    public void OnRemove()
    {
        if (!string.IsNullOrEmpty(Host))
            Debug.Log(Host + ":" + Port + "的连接被移除");

        this.Close();
        reader.Close();
        memStream.Close();
    }

    public string Host
    {
        private set;
        get;
    }

    public int Port
    {
        private set;
        get;
    }

    /// <summary>
    /// 连接服务器
    /// </summary>
    public void SendConnect(string host, int port)
    {
        Host = host;
        Port = port;

        //设置socket状态为正在连接状态
        MyConnectState = ConnectState.Connecting;

        if (client != null)
        {
            Close();
        }
        try
        {
            if (Regex.Matches(host, "[a-zA-Z]").Count > 0)
            {
                var asyncGetHostAddresse = Dns.BeginGetHostAddresses(host, x =>
                {
                    try
                    {
                        string ipV4 = null;
                        IPAddress[] addresses = Dns.EndGetHostAddresses(x);
                        if (ipV4 == null)
                        {
                            if (addresses != null)
                            {
                                foreach (var item in addresses)
                                {
                                    if (item.AddressFamily == AddressFamily.InterNetwork)
                                    {
                                        ipV4 = item.ToString();
                                        break;
                                    }
                                }
                            }
                        }
                        if (ipV4 == null)
                        {
                            if (addresses != null)
                            {
                                foreach (var item in addresses)
                                {
                                    if (item.AddressFamily == AddressFamily.InterNetworkV6)
                                    {
                                        string ipV6 = item.ToString();
                                        string[] strs = ipV6.Split(':');
                                        if (strs.Length > 2)
                                        {
                                            strs[strs.Length - 2] = strs[strs.Length - 2].PadLeft(4, '0');
                                            strs[strs.Length - 1] = strs[strs.Length - 1].PadLeft(4, '0');
                                            string strs1 = strs[strs.Length - 2].Substring(0, 2);
                                            string strs2 = strs[strs.Length - 2].Substring(2, 2);
                                            string strs3 = strs[strs.Length - 1].Substring(0, 2);
                                            string strs4 = strs[strs.Length - 1].Substring(2, 2);
                                            ipV4 = string.Format("{0}.{1}.{2}.{3}", System.Convert.ToInt32(strs1, 16), System.Convert.ToInt32(strs2, 16), System.Convert.ToInt32(strs3, 16), System.Convert.ToInt32(strs4, 16));
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        if (ipV4 == null)
                        {
                            MyConnectState = ConnectState.Other;
                            return;
                        }
                        else
                        {
                            BeginConnect(ref client, ipV4);
                        }
                    }
                    catch (Exception e)
                    {
                        MyConnectState = ConnectState.Other;
                        Debug.LogError(e.Message);
                    }
                }, null);
            }
            else
            {
                BeginConnect(ref client, host);
            }
        }
        catch (Exception e)
        {
            MyConnectState = ConnectState.Other;
            Debug.LogError(e.Message);
        }
    }

    /// <summary>
    /// 开始连接
    /// </summary>
    /// <param name="client"></param>
    /// <param name="newIp"></param>
    /// <param name="ipAddressFamily"></param>
    void BeginConnect(ref TcpClient client, string host)
    {
        string newIp;
        AddressFamily ipAddressFamily;
        GameSDKInterface.instance.ProcessIpAndAddressFamily(host, out newIp, out ipAddressFamily);
        Host = host;
        if (ipAddressFamily == AddressFamily.InterNetworkV6)
        {
            client = new TcpClient(AddressFamily.InterNetworkV6);
        }
        else
        {
            client = new TcpClient(AddressFamily.InterNetwork);
        }
        client.SendTimeout = 1000;
        client.ReceiveTimeout = 1000;
        client.NoDelay = true;
        client.BeginConnect(newIp, Port, new AsyncCallback(OnConnect), null);
    }

    /// <summary>
    /// 连接上服务器
    /// </summary>
    void OnConnect(IAsyncResult asr)
    {
        if (client.Connected)
        {
            outStream = client.GetStream();
            client.GetStream().BeginRead(byteBuffer, 0, MAX_READ, new AsyncCallback(OnRead), null);
            MyConnectState = ConnectState.Connect;
        }
        else
        {
            Debug.LogError(string.Format("{0}:{1} 无法连接", Host, Port));
            MyConnectState = ConnectState.Other;
            Close();
        }
    }

    /// <summary>
    /// 写数据
    /// </summary>
    void WriteMessage(int mainID, int secondID, byte[] message)
    {
        if (client != null && client.Connected)
        {
            ByteBuffer buffer = new ByteBuffer();
            buffer.WriteInt((message == null ? 0 : message.Length) + 8);
            buffer.WriteInt(mainID);
            buffer.WriteInt(secondID);

            if (message != null)
                buffer.WriteBytes(message);

            buffer.Flush();
            byte[] payload = buffer.ToBytes();
            // PrintBytes(payload);

            outStream.BeginWrite(payload, 0, payload.Length, new AsyncCallback(OnWrite), null);
            buffer.Close();
        }
        else
        {
            Debug.LogError(string.Format("{0}:{1} 未连接,无法发送消息", Host, Port));
        }
    }

    /// <summary>
    /// 读取消息
    /// </summary>
    void OnRead(IAsyncResult asr)
    {

        if (client == null || !client.Connected)
            return;

        int bytesRead = 0;
        try
        {
            lock (client.GetStream())
            {         //读取字节流到缓冲区
                bytesRead = client.GetStream().EndRead(asr);
            }
            if (bytesRead < 1)
            {
                //包尺寸有问题，断线处理
                Disconnected("bytesRead < 1");
                return;
            }
            OnReceive(byteBuffer, bytesRead);   //分析数据包内容，抛给逻辑层
            lock (client.GetStream())
            {         //分析完，再次监听服务器发过来的新消息
                Array.Clear(byteBuffer, 0, byteBuffer.Length);   //清空数组
                client.GetStream().BeginRead(byteBuffer, 0, MAX_READ, new AsyncCallback(OnRead), null);
            }
        }
        catch (Exception ex)
        {
            //PrintBytes();
            Disconnected(ex.Message);
        }
    }

    /// <summary>
    /// 异常断开连接(会触发断线重连)
    /// </summary>
    public void Disconnected(string msg)
    {
        Debug.LogError("连接异常，" + Host + ":" + Port + "的连接被关闭:>" + msg);
        NetworkManager.AddEvent(this, 0, (int)connectType, null);
        MyConnectState = ConnectState.Other;
        Close();                        //关掉客户端链接
    }

    /// <summary>
    /// 打印字节
    /// </summary>
    /// <param name="bytes"></param>
    void PrintBytes(byte[] bytes)
    {
        string returnStr = string.Empty;
        for (int i = 0; i < bytes.Length; i++)
        {
            returnStr += bytes[i].ToString("X2");
        }
    }

    /// <summary>
    /// 向链接写入数据流
    /// </summary>
    void OnWrite(IAsyncResult r)
    {
        try
        {
            outStream.EndWrite(r);
        }
        catch (Exception ex)
        {
            Debug.LogError("OnWrite--->>>" + ex.Message);
        }
    }

    /// <summary>
    /// 接收到消息
    /// </summary>
    void OnReceive(byte[] bytes, int length)
    {
        memStream.Seek(0, SeekOrigin.End);
        memStream.Write(bytes, 0, length);
        //Reset to beginning
        memStream.Seek(0, SeekOrigin.Begin);
        while (RemainingBytes() > 4)
        {
            ByteBuffer buffer = new ByteBuffer(reader.ReadBytes(4));    // 前面4个字节表示消息长度
            int messageLen = buffer.ReadInt();

            if (RemainingBytes() >= messageLen)
            {
                MemoryStream ms = new MemoryStream();
                BinaryWriter writer = new BinaryWriter(ms);
                writer.Write(reader.ReadBytes(messageLen));
                ms.Seek(0, SeekOrigin.Begin);
                OnReceivedMessage(ms);
            }
            else
            {
                //Back up the position 4 bytes
                memStream.Position = memStream.Position - 4;
                break;
            }
        }
        //Create a new stream with any leftover bytes
        byte[] leftover = reader.ReadBytes((int)RemainingBytes());
        memStream.SetLength(0);     //Clear
        memStream.Write(leftover, 0, leftover.Length);
    }

    /// <summary>
    /// 剩余的字节
    /// </summary>
    private long RemainingBytes()
    {
        return memStream.Length - memStream.Position;
    }

    /// <summary>
    /// 接收到消息
    /// </summary>
    /// <param name="ms"></param>
    void OnReceivedMessage(MemoryStream ms)
    {        
        BinaryReader r = new BinaryReader(ms);
        byte[] message = r.ReadBytes((int)(ms.Length - ms.Position));
        //int msglen = message.Length;

        ByteBuffer buffer = new ByteBuffer(message);
        int mainId = buffer.ReadInt();
        int secondID = buffer.ReadInt();

        NetworkManager.AddEvent(this, mainId, secondID, buffer.ReadBytes((int)ms.Length - 8));
    }

    public void Close()
    {
        MyConnectState = ConnectState.Other;

        if (client != null)
        {
            if (client != null)
            {
                client.Close();
                memStream.SetLength(0);
                client = null;
            }
        }
    }

    /// <summary>
    /// 发送消息
    /// </summary>
    public void SendMessage(int mainID, int secondID, byte[] buffer)
    {
        WriteMessage(mainID, secondID, buffer);
    }

    public override string ToString()
    {
        if (client == null || !client.Connected)
        {
            return "disconnected";
        }

        return client.Client.RemoteEndPoint.ToString();
    }
}
