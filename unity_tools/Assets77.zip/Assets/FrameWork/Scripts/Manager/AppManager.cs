﻿using System;
using UnityEngine;

public class AppManager : Singleton<AppManager>
{
    public Action<bool> OnAppPause = (isPause) => { };
    public Action OnAppQuit = () => { };

    public void ReLaunch()
    {
        OnAppPause = (isPause) => { };
        OnAppQuit = () => { };
    }

    void OnApplicationPause(bool isPause)
    {
        if (OnAppPause != null)
            OnAppPause(isPause);
    }

    public void OnApplicationQuit()
    {
        if (OnAppQuit != null)
            OnAppQuit();
    }

    /// <summary>
    /// 设置脚本错误回调
    /// </summary>
    /// <param name="errorCallBack"></param>
    public void SetErorrCallBack(Action<string> errorCallBack)
    {
        LuaManager.LuaEnv.exceptionCallBack = errorCallBack;
    }
}
