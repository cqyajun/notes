﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AutoFixCavas : MonoBehaviour {

    const int width = 1334;
    const int height = 750;

	// Use this for initialization
	void Start () {
        CanvasScaler cs = transform.GetComponent<CanvasScaler>();
        float radio = Screen.width / (float)Screen.height;
        if(radio >= width/(float)height)
        {
            cs.matchWidthOrHeight = 1;
        }
        else
        {
            cs.matchWidthOrHeight = 0;
        }
    }

}
