﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class NetworkManagerWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(NetworkManager);
			Utils.BeginObjectRegister(type, L, translator, 0, 12, 4, 4);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "AddSocket", _m_AddSocket);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "DelSocket", _m_DelSocket);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "SendConnect", _m_SendConnect);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "SendConnectIPAddress", _m_SendConnectIPAddress);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "SendMessage", _m_SendMessage);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetReader", _m_GetReader);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "AddEvent", _m_AddEvent);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetSocket", _m_GetSocket);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "CallWWW", _m_CallWWW);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "PostForm", _m_PostForm);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "PostTab", _m_PostTab);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Upload", _m_Upload);
			
			
			Utils.RegisterFunc(L, Utils.GETTER_IDX, "sockets", _g_get_sockets);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "netMsgs", _g_get_netMsgs);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "isEncrypt", _g_get_isEncrypt);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "key", _g_get_key);
            
			Utils.RegisterFunc(L, Utils.SETTER_IDX, "sockets", _s_set_sockets);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "netMsgs", _s_set_netMsgs);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "isEncrypt", _s_set_isEncrypt);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "key", _s_set_key);
            
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 7, 1, 0);
			Utils.RegisterFunc(L, Utils.CLS_IDX, "AesEncryptor_Base64", _m_AesEncryptor_Base64_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "AesDecryptor_Base64", _m_AesDecryptor_Base64_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "MD5EncryptString", _m_MD5EncryptString_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "UrlEncode", _m_UrlEncode_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "GetTimeStamp", _m_GetTimeStamp_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "RandomStr", _m_RandomStr_xlua_st_);
            
			
            
			Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "Instance", _g_get_Instance);
            
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					NetworkManager gen_ret = new NetworkManager();
					translator.Push(L, gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to NetworkManager constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_AddSocket(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string _socketName = LuaAPI.lua_tostring(L, 2);
                    int _flag = LuaAPI.xlua_tointeger(L, 3);
                    
                    gen_to_be_invoked.AddSocket( _socketName, _flag );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_DelSocket(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string _socketName = LuaAPI.lua_tostring(L, 2);
                    
                    gen_to_be_invoked.DelSocket( _socketName );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SendConnect(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string _socketName = LuaAPI.lua_tostring(L, 2);
                    string _ip = LuaAPI.lua_tostring(L, 3);
                    int _port = LuaAPI.xlua_tointeger(L, 4);
                    
                    gen_to_be_invoked.SendConnect( _socketName, _ip, _port );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SendConnectIPAddress(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string _socketName = LuaAPI.lua_tostring(L, 2);
                    int _data = LuaAPI.xlua_tointeger(L, 3);
                    int _port = LuaAPI.xlua_tointeger(L, 4);
                    
                    gen_to_be_invoked.SendConnectIPAddress( _socketName, _data, _port );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SendMessage(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string _socketName = LuaAPI.lua_tostring(L, 2);
                    int _id = LuaAPI.xlua_tointeger(L, 3);
                    byte[] _msg = LuaAPI.lua_tobytes(L, 4);
                    
                    gen_to_be_invoked.SendMessage( _socketName, _id, _msg );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetReader(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    byte[] _msg = LuaAPI.lua_tobytes(L, 2);
                    
                        object gen_ret = gen_to_be_invoked.GetReader( _msg );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_AddEvent(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string _socketName = LuaAPI.lua_tostring(L, 2);
                    int _id = LuaAPI.xlua_tointeger(L, 3);
                    object _msg = translator.GetObject(L, 4, typeof(object));
                    
                    gen_to_be_invoked.AddEvent( _socketName, _id, _msg );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetSocket(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string _n = LuaAPI.lua_tostring(L, 2);
                    
                        SocketClient gen_ret = gen_to_be_invoked.GetSocket( _n );
                        translator.Push(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_CallWWW(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 6&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<UnityEngine.WWWForm>(L, 3)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Collections.Generic.Dictionary<string, string>>(L, 5)&& translator.Assignable<System.Action<object>>(L, 6)) 
                {
                    string _url = LuaAPI.lua_tostring(L, 2);
                    UnityEngine.WWWForm _form = (UnityEngine.WWWForm)translator.GetObject(L, 3, typeof(UnityEngine.WWWForm));
                    byte[] _postData = LuaAPI.lua_tobytes(L, 4);
                    System.Collections.Generic.Dictionary<string, string> _headers = (System.Collections.Generic.Dictionary<string, string>)translator.GetObject(L, 5, typeof(System.Collections.Generic.Dictionary<string, string>));
                    System.Action<object> _callBack = translator.GetDelegate<System.Action<object>>(L, 6);
                    
                    gen_to_be_invoked.CallWWW( _url, _form, _postData, _headers, _callBack );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 5&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<UnityEngine.WWWForm>(L, 3)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Collections.Generic.Dictionary<string, string>>(L, 5)) 
                {
                    string _url = LuaAPI.lua_tostring(L, 2);
                    UnityEngine.WWWForm _form = (UnityEngine.WWWForm)translator.GetObject(L, 3, typeof(UnityEngine.WWWForm));
                    byte[] _postData = LuaAPI.lua_tobytes(L, 4);
                    System.Collections.Generic.Dictionary<string, string> _headers = (System.Collections.Generic.Dictionary<string, string>)translator.GetObject(L, 5, typeof(System.Collections.Generic.Dictionary<string, string>));
                    
                    gen_to_be_invoked.CallWWW( _url, _form, _postData, _headers );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 4&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<UnityEngine.WWWForm>(L, 3)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)) 
                {
                    string _url = LuaAPI.lua_tostring(L, 2);
                    UnityEngine.WWWForm _form = (UnityEngine.WWWForm)translator.GetObject(L, 3, typeof(UnityEngine.WWWForm));
                    byte[] _postData = LuaAPI.lua_tobytes(L, 4);
                    
                    gen_to_be_invoked.CallWWW( _url, _form, _postData );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 3&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<UnityEngine.WWWForm>(L, 3)) 
                {
                    string _url = LuaAPI.lua_tostring(L, 2);
                    UnityEngine.WWWForm _form = (UnityEngine.WWWForm)translator.GetObject(L, 3, typeof(UnityEngine.WWWForm));
                    
                    gen_to_be_invoked.CallWWW( _url, _form );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 2&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)) 
                {
                    string _url = LuaAPI.lua_tostring(L, 2);
                    
                    gen_to_be_invoked.CallWWW( _url );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to NetworkManager.CallWWW!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_PostForm(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 6&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<UnityEngine.WWWForm>(L, 3)&& translator.Assignable<System.Action<string>>(L, 4)&& translator.Assignable<System.Action<byte[]>>(L, 5)&& translator.Assignable<System.Action<string>>(L, 6)) 
                {
                    string _url = LuaAPI.lua_tostring(L, 2);
                    UnityEngine.WWWForm _form = (UnityEngine.WWWForm)translator.GetObject(L, 3, typeof(UnityEngine.WWWForm));
                    System.Action<string> _strCallback = translator.GetDelegate<System.Action<string>>(L, 4);
                    System.Action<byte[]> _bytesCallback = translator.GetDelegate<System.Action<byte[]>>(L, 5);
                    System.Action<string> _errorCallback = translator.GetDelegate<System.Action<string>>(L, 6);
                    
                    gen_to_be_invoked.PostForm( _url, _form, _strCallback, _bytesCallback, _errorCallback );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 5&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<UnityEngine.WWWForm>(L, 3)&& translator.Assignable<System.Action<string>>(L, 4)&& translator.Assignable<System.Action<byte[]>>(L, 5)) 
                {
                    string _url = LuaAPI.lua_tostring(L, 2);
                    UnityEngine.WWWForm _form = (UnityEngine.WWWForm)translator.GetObject(L, 3, typeof(UnityEngine.WWWForm));
                    System.Action<string> _strCallback = translator.GetDelegate<System.Action<string>>(L, 4);
                    System.Action<byte[]> _bytesCallback = translator.GetDelegate<System.Action<byte[]>>(L, 5);
                    
                    gen_to_be_invoked.PostForm( _url, _form, _strCallback, _bytesCallback );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 4&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<UnityEngine.WWWForm>(L, 3)&& translator.Assignable<System.Action<string>>(L, 4)) 
                {
                    string _url = LuaAPI.lua_tostring(L, 2);
                    UnityEngine.WWWForm _form = (UnityEngine.WWWForm)translator.GetObject(L, 3, typeof(UnityEngine.WWWForm));
                    System.Action<string> _strCallback = translator.GetDelegate<System.Action<string>>(L, 4);
                    
                    gen_to_be_invoked.PostForm( _url, _form, _strCallback );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 3&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<UnityEngine.WWWForm>(L, 3)) 
                {
                    string _url = LuaAPI.lua_tostring(L, 2);
                    UnityEngine.WWWForm _form = (UnityEngine.WWWForm)translator.GetObject(L, 3, typeof(UnityEngine.WWWForm));
                    
                    gen_to_be_invoked.PostForm( _url, _form );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to NetworkManager.PostForm!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_PostTab(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 6&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TTABLE)&& translator.Assignable<System.Action<string>>(L, 4)&& translator.Assignable<System.Action<byte[]>>(L, 5)&& translator.Assignable<System.Action<string>>(L, 6)) 
                {
                    string _url = LuaAPI.lua_tostring(L, 2);
                    XLua.LuaTable _tab = (XLua.LuaTable)translator.GetObject(L, 3, typeof(XLua.LuaTable));
                    System.Action<string> _strCallback = translator.GetDelegate<System.Action<string>>(L, 4);
                    System.Action<byte[]> _bytesCallback = translator.GetDelegate<System.Action<byte[]>>(L, 5);
                    System.Action<string> _errorCallback = translator.GetDelegate<System.Action<string>>(L, 6);
                    
                    gen_to_be_invoked.PostTab( _url, _tab, _strCallback, _bytesCallback, _errorCallback );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 5&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TTABLE)&& translator.Assignable<System.Action<string>>(L, 4)&& translator.Assignable<System.Action<byte[]>>(L, 5)) 
                {
                    string _url = LuaAPI.lua_tostring(L, 2);
                    XLua.LuaTable _tab = (XLua.LuaTable)translator.GetObject(L, 3, typeof(XLua.LuaTable));
                    System.Action<string> _strCallback = translator.GetDelegate<System.Action<string>>(L, 4);
                    System.Action<byte[]> _bytesCallback = translator.GetDelegate<System.Action<byte[]>>(L, 5);
                    
                    gen_to_be_invoked.PostTab( _url, _tab, _strCallback, _bytesCallback );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 4&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TTABLE)&& translator.Assignable<System.Action<string>>(L, 4)) 
                {
                    string _url = LuaAPI.lua_tostring(L, 2);
                    XLua.LuaTable _tab = (XLua.LuaTable)translator.GetObject(L, 3, typeof(XLua.LuaTable));
                    System.Action<string> _strCallback = translator.GetDelegate<System.Action<string>>(L, 4);
                    
                    gen_to_be_invoked.PostTab( _url, _tab, _strCallback );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 3&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TTABLE)) 
                {
                    string _url = LuaAPI.lua_tostring(L, 2);
                    XLua.LuaTable _tab = (XLua.LuaTable)translator.GetObject(L, 3, typeof(XLua.LuaTable));
                    
                    gen_to_be_invoked.PostTab( _url, _tab );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to NetworkManager.PostTab!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Upload(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 7&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<UnityEngine.WWWForm>(L, 3)&& translator.Assignable<System.Action<string>>(L, 4)&& translator.Assignable<System.Action<byte[]>>(L, 5)&& translator.Assignable<System.Action<string>>(L, 6)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 7)) 
                {
                    string _url = LuaAPI.lua_tostring(L, 2);
                    UnityEngine.WWWForm _form = (UnityEngine.WWWForm)translator.GetObject(L, 3, typeof(UnityEngine.WWWForm));
                    System.Action<string> _strCallback = translator.GetDelegate<System.Action<string>>(L, 4);
                    System.Action<byte[]> _bytesCallback = translator.GetDelegate<System.Action<byte[]>>(L, 5);
                    System.Action<string> _errorCallback = translator.GetDelegate<System.Action<string>>(L, 6);
                    bool _useLoading = LuaAPI.lua_toboolean(L, 7);
                    
                        System.Collections.IEnumerator gen_ret = gen_to_be_invoked.Upload( _url, _form, _strCallback, _bytesCallback, _errorCallback, _useLoading );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                if(gen_param_count == 6&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<UnityEngine.WWWForm>(L, 3)&& translator.Assignable<System.Action<string>>(L, 4)&& translator.Assignable<System.Action<byte[]>>(L, 5)&& translator.Assignable<System.Action<string>>(L, 6)) 
                {
                    string _url = LuaAPI.lua_tostring(L, 2);
                    UnityEngine.WWWForm _form = (UnityEngine.WWWForm)translator.GetObject(L, 3, typeof(UnityEngine.WWWForm));
                    System.Action<string> _strCallback = translator.GetDelegate<System.Action<string>>(L, 4);
                    System.Action<byte[]> _bytesCallback = translator.GetDelegate<System.Action<byte[]>>(L, 5);
                    System.Action<string> _errorCallback = translator.GetDelegate<System.Action<string>>(L, 6);
                    
                        System.Collections.IEnumerator gen_ret = gen_to_be_invoked.Upload( _url, _form, _strCallback, _bytesCallback, _errorCallback );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                if(gen_param_count == 5&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<UnityEngine.WWWForm>(L, 3)&& translator.Assignable<System.Action<string>>(L, 4)&& translator.Assignable<System.Action<byte[]>>(L, 5)) 
                {
                    string _url = LuaAPI.lua_tostring(L, 2);
                    UnityEngine.WWWForm _form = (UnityEngine.WWWForm)translator.GetObject(L, 3, typeof(UnityEngine.WWWForm));
                    System.Action<string> _strCallback = translator.GetDelegate<System.Action<string>>(L, 4);
                    System.Action<byte[]> _bytesCallback = translator.GetDelegate<System.Action<byte[]>>(L, 5);
                    
                        System.Collections.IEnumerator gen_ret = gen_to_be_invoked.Upload( _url, _form, _strCallback, _bytesCallback );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                if(gen_param_count == 4&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<UnityEngine.WWWForm>(L, 3)&& translator.Assignable<System.Action<string>>(L, 4)) 
                {
                    string _url = LuaAPI.lua_tostring(L, 2);
                    UnityEngine.WWWForm _form = (UnityEngine.WWWForm)translator.GetObject(L, 3, typeof(UnityEngine.WWWForm));
                    System.Action<string> _strCallback = translator.GetDelegate<System.Action<string>>(L, 4);
                    
                        System.Collections.IEnumerator gen_ret = gen_to_be_invoked.Upload( _url, _form, _strCallback );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                if(gen_param_count == 3&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<UnityEngine.WWWForm>(L, 3)) 
                {
                    string _url = LuaAPI.lua_tostring(L, 2);
                    UnityEngine.WWWForm _form = (UnityEngine.WWWForm)translator.GetObject(L, 3, typeof(UnityEngine.WWWForm));
                    
                        System.Collections.IEnumerator gen_ret = gen_to_be_invoked.Upload( _url, _form );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to NetworkManager.Upload!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_AesEncryptor_Base64_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string _EncryptStr = LuaAPI.lua_tostring(L, 1);
                    string _Key = LuaAPI.lua_tostring(L, 2);
                    
                        string gen_ret = NetworkManager.AesEncryptor_Base64( _EncryptStr, _Key );
                        LuaAPI.lua_pushstring(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_AesDecryptor_Base64_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string _DecryptStr = LuaAPI.lua_tostring(L, 1);
                    string _Key = LuaAPI.lua_tostring(L, 2);
                    
                        string gen_ret = NetworkManager.AesDecryptor_Base64( _DecryptStr, _Key );
                        LuaAPI.lua_pushstring(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_MD5EncryptString_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string _str = LuaAPI.lua_tostring(L, 1);
                    
                        string gen_ret = NetworkManager.MD5EncryptString( _str );
                        LuaAPI.lua_pushstring(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_UrlEncode_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string _str = LuaAPI.lua_tostring(L, 1);
                    
                        string gen_ret = NetworkManager.UrlEncode( _str );
                        LuaAPI.lua_pushstring(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetTimeStamp_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 1&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 1)) 
                {
                    bool _bflag = LuaAPI.lua_toboolean(L, 1);
                    
                        long gen_ret = NetworkManager.GetTimeStamp( _bflag );
                        LuaAPI.lua_pushint64(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                if(gen_param_count == 0) 
                {
                    
                        long gen_ret = NetworkManager.GetTimeStamp(  );
                        LuaAPI.lua_pushint64(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to NetworkManager.GetTimeStamp!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_RandomStr_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    
                        string gen_ret = NetworkManager.RandomStr(  );
                        LuaAPI.lua_pushstring(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_Instance(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, NetworkManager.Instance);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_sockets(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.sockets);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_netMsgs(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.netMsgs);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_isEncrypt(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushboolean(L, gen_to_be_invoked.isEncrypt);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_key(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushstring(L, gen_to_be_invoked.key);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_sockets(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.sockets = (System.Collections.Generic.Dictionary<string, SocketClient>)translator.GetObject(L, 2, typeof(System.Collections.Generic.Dictionary<string, SocketClient>));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_netMsgs(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.netMsgs = (System.Collections.Generic.Queue<NetMsg>)translator.GetObject(L, 2, typeof(System.Collections.Generic.Queue<NetMsg>));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_isEncrypt(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.isEncrypt = LuaAPI.lua_toboolean(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_key(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                NetworkManager gen_to_be_invoked = (NetworkManager)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.key = LuaAPI.lua_tostring(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
