﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class GameEventManagerWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(GameEventManager);
			Utils.BeginObjectRegister(type, L, translator, 0, 4, 1, 1);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "RegisterEvent", _m_RegisterEvent);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "UnRegisterEvent", _m_UnRegisterEvent);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "EventCallback", _m_EventCallback);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetNormalMsgId", _m_GetNormalMsgId);
			
			
			Utils.RegisterFunc(L, Utils.GETTER_IDX, "delegateMap", _g_get_delegateMap);
            
			Utils.RegisterFunc(L, Utils.SETTER_IDX, "delegateMap", _s_set_delegateMap);
            
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 1, 1, 0);
			
			
            
			Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "Instance", _g_get_Instance);
            
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					GameEventManager gen_ret = new GameEventManager();
					translator.Push(L, gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to GameEventManager constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_RegisterEvent(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameEventManager gen_to_be_invoked = (GameEventManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    GameEventManager.EventType _type;translator.Get(L, 2, out _type);
                    GameEventManager.DelegateEvent _callback = translator.GetDelegate<GameEventManager.DelegateEvent>(L, 3);
                    
                    gen_to_be_invoked.RegisterEvent( _type, _callback );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_UnRegisterEvent(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameEventManager gen_to_be_invoked = (GameEventManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    GameEventManager.EventType _type;translator.Get(L, 2, out _type);
                    GameEventManager.DelegateEvent _callback = translator.GetDelegate<GameEventManager.DelegateEvent>(L, 3);
                    
                    gen_to_be_invoked.UnRegisterEvent( _type, _callback );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_EventCallback(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameEventManager gen_to_be_invoked = (GameEventManager)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count >= 3&& translator.Assignable<GameEventManager.EventType>(L, 2)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 3)&& (LuaTypes.LUA_TNONE == LuaAPI.lua_type(L, 4) || translator.Assignable<object>(L, 4))) 
                {
                    GameEventManager.EventType _type;translator.Get(L, 2, out _type);
                    int _id = LuaAPI.xlua_tointeger(L, 3);
                    object[] _msgs = translator.GetParams<object>(L, 4);
                    
                    gen_to_be_invoked.EventCallback( _type, _id, _msgs );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count >= 3&& translator.Assignable<GameEventManager.EventType>(L, 2)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& (LuaTypes.LUA_TNONE == LuaAPI.lua_type(L, 4) || translator.Assignable<object>(L, 4))) 
                {
                    GameEventManager.EventType _type;translator.Get(L, 2, out _type);
                    string _strID = LuaAPI.lua_tostring(L, 3);
                    object[] _msgs = translator.GetParams<object>(L, 4);
                    
                    gen_to_be_invoked.EventCallback( _type, _strID, _msgs );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to GameEventManager.EventCallback!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetNormalMsgId(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                GameEventManager gen_to_be_invoked = (GameEventManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string _key = LuaAPI.lua_tostring(L, 2);
                    
                        int gen_ret = gen_to_be_invoked.GetNormalMsgId( _key );
                        LuaAPI.xlua_pushinteger(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_Instance(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, GameEventManager.Instance);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_delegateMap(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameEventManager gen_to_be_invoked = (GameEventManager)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.delegateMap);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_delegateMap(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                GameEventManager gen_to_be_invoked = (GameEventManager)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.delegateMap = (System.Collections.Generic.Dictionary<GameEventManager.EventType, System.Collections.Generic.List<GameEventManager.DelegateEvent>>)translator.GetObject(L, 2, typeof(System.Collections.Generic.Dictionary<GameEventManager.EventType, System.Collections.Generic.List<GameEventManager.DelegateEvent>>));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
