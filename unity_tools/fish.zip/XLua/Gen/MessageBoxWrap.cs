﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class MessageBoxWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(MessageBox);
			Utils.BeginObjectRegister(type, L, translator, 0, 3, 8, 8);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Init", _m_Init);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "OKClick", _m_OKClick);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "CancelClick", _m_CancelClick);
			
			
			Utils.RegisterFunc(L, Utils.GETTER_IDX, "titleText", _g_get_titleText);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "msgText", _g_get_msgText);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "okBtn", _g_get_okBtn);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "okText", _g_get_okText);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "cancelBtn", _g_get_cancelBtn);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "cancelText", _g_get_cancelText);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "okCallBack", _g_get_okCallBack);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "cancelBack", _g_get_cancelBack);
            
			Utils.RegisterFunc(L, Utils.SETTER_IDX, "titleText", _s_set_titleText);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "msgText", _s_set_msgText);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "okBtn", _s_set_okBtn);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "okText", _s_set_okText);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "cancelBtn", _s_set_cancelBtn);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "cancelText", _s_set_cancelText);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "okCallBack", _s_set_okCallBack);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "cancelBack", _s_set_cancelBack);
            
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 1, 1, 0);
			
			
            
			Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "Instance", _g_get_Instance);
            
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					MessageBox gen_ret = new MessageBox();
					translator.Push(L, gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to MessageBox constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Init(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 7&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Action>(L, 5)&& (LuaAPI.lua_isnil(L, 6) || LuaAPI.lua_type(L, 6) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Action>(L, 7)) 
                {
                    string _title = LuaAPI.lua_tostring(L, 2);
                    string _msg = LuaAPI.lua_tostring(L, 3);
                    string _ok_text = LuaAPI.lua_tostring(L, 4);
                    System.Action _OKCallBack = translator.GetDelegate<System.Action>(L, 5);
                    string _cancel_text = LuaAPI.lua_tostring(L, 6);
                    System.Action _CancelCallBack = translator.GetDelegate<System.Action>(L, 7);
                    
                    gen_to_be_invoked.Init( _title, _msg, _ok_text, _OKCallBack, _cancel_text, _CancelCallBack );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 6&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Action>(L, 5)&& (LuaAPI.lua_isnil(L, 6) || LuaAPI.lua_type(L, 6) == LuaTypes.LUA_TSTRING)) 
                {
                    string _title = LuaAPI.lua_tostring(L, 2);
                    string _msg = LuaAPI.lua_tostring(L, 3);
                    string _ok_text = LuaAPI.lua_tostring(L, 4);
                    System.Action _OKCallBack = translator.GetDelegate<System.Action>(L, 5);
                    string _cancel_text = LuaAPI.lua_tostring(L, 6);
                    
                    gen_to_be_invoked.Init( _title, _msg, _ok_text, _OKCallBack, _cancel_text );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 5&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Action>(L, 5)) 
                {
                    string _title = LuaAPI.lua_tostring(L, 2);
                    string _msg = LuaAPI.lua_tostring(L, 3);
                    string _ok_text = LuaAPI.lua_tostring(L, 4);
                    System.Action _OKCallBack = translator.GetDelegate<System.Action>(L, 5);
                    
                    gen_to_be_invoked.Init( _title, _msg, _ok_text, _OKCallBack );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 4&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)) 
                {
                    string _title = LuaAPI.lua_tostring(L, 2);
                    string _msg = LuaAPI.lua_tostring(L, 3);
                    string _ok_text = LuaAPI.lua_tostring(L, 4);
                    
                    gen_to_be_invoked.Init( _title, _msg, _ok_text );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 3&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)) 
                {
                    string _title = LuaAPI.lua_tostring(L, 2);
                    string _msg = LuaAPI.lua_tostring(L, 3);
                    
                    gen_to_be_invoked.Init( _title, _msg );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to MessageBox.Init!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_OKClick(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.OKClick(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_CancelClick(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.CancelClick(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_Instance(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, MessageBox.Instance);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_titleText(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.titleText);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_msgText(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.msgText);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_okBtn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.okBtn);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_okText(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.okText);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_cancelBtn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.cancelBtn);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_cancelText(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.cancelText);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_okCallBack(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.okCallBack);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_cancelBack(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.cancelBack);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_titleText(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.titleText = (UnityEngine.UI.Text)translator.GetObject(L, 2, typeof(UnityEngine.UI.Text));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_msgText(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.msgText = (UnityEngine.UI.Text)translator.GetObject(L, 2, typeof(UnityEngine.UI.Text));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_okBtn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.okBtn = (UnityEngine.UI.Button)translator.GetObject(L, 2, typeof(UnityEngine.UI.Button));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_okText(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.okText = (UnityEngine.UI.Text)translator.GetObject(L, 2, typeof(UnityEngine.UI.Text));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_cancelBtn(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.cancelBtn = (UnityEngine.UI.Button)translator.GetObject(L, 2, typeof(UnityEngine.UI.Button));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_cancelText(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.cancelText = (UnityEngine.UI.Text)translator.GetObject(L, 2, typeof(UnityEngine.UI.Text));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_okCallBack(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.okCallBack = translator.GetDelegate<System.Action>(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_cancelBack(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MessageBox gen_to_be_invoked = (MessageBox)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.cancelBack = translator.GetDelegate<System.Action>(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
