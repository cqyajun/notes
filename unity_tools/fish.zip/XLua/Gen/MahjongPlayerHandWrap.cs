﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class MahjongPlayerHandWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(Mahjong.PlayerHand);
			Utils.BeginObjectRegister(type, L, translator, 0, 25, 1, 1);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "setTarget", _m_setTarget);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "OnDestroy", _m_OnDestroy);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "sort2_Start", _m_sort2_Start);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "sort2_PickUp", _m_sort2_PickUp);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "sort2_PutDown", _m_sort2_PutDown);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "sort2_End", _m_sort2_End);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "play_Start", _m_play_Start);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "play_PickUp", _m_play_PickUp);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "play_PutDown", _m_play_PutDown);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "play_End", _m_play_End);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "over_Start", _m_over_Start);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "over_PushToTile", _m_over_PushToTile);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "over_End", _m_over_End);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "pressDice_Start", _m_pressDice_Start);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "pressDice_Play", _m_pressDice_Play);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "pressDice_End", _m_pressDice_End);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "changeThree_Start", _m_changeThree_Start);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "changeThree_PutDown", _m_changeThree_PutDown);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "changeThree_End", _m_changeThree_End);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "sortMeld_Start", _m_sortMeld_Start);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "sortMeld_Move", _m_sortMeld_Move);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "sortMeld_End", _m_sortMeld_End);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "hu_Start", _m_hu_Start);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "hu_PutDown", _m_hu_PutDown);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "hu_End", _m_hu_End);
			
			
			Utils.RegisterFunc(L, Utils.GETTER_IDX, "tileObj", _g_get_tileObj);
            
			Utils.RegisterFunc(L, Utils.SETTER_IDX, "tileObj", _s_set_tileObj);
            
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 1, 0, 0);
			
			
            
			
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					Mahjong.PlayerHand gen_ret = new Mahjong.PlayerHand();
					translator.Push(L, gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to Mahjong.PlayerHand constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_setTarget(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    XLua.LuaTable _lua = (XLua.LuaTable)translator.GetObject(L, 2, typeof(XLua.LuaTable));
                    
                    gen_to_be_invoked.setTarget( _lua );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_OnDestroy(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.OnDestroy(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_sort2_Start(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.sort2_Start(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_sort2_PickUp(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.sort2_PickUp(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_sort2_PutDown(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.sort2_PutDown(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_sort2_End(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.sort2_End(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_play_Start(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.play_Start(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_play_PickUp(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.play_PickUp(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_play_PutDown(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.play_PutDown(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_play_End(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.play_End(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_over_Start(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.over_Start(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_over_PushToTile(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.over_PushToTile(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_over_End(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.over_End(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_pressDice_Start(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.pressDice_Start(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_pressDice_Play(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.pressDice_Play(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_pressDice_End(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.pressDice_End(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_changeThree_Start(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.changeThree_Start(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_changeThree_PutDown(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.changeThree_PutDown(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_changeThree_End(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.changeThree_End(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_sortMeld_Start(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.sortMeld_Start(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_sortMeld_Move(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.sortMeld_Move(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_sortMeld_End(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.sortMeld_End(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_hu_Start(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.hu_Start(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_hu_PutDown(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.hu_PutDown(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_hu_End(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.hu_End(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_tileObj(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.tileObj);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_tileObj(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                Mahjong.PlayerHand gen_to_be_invoked = (Mahjong.PlayerHand)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.tileObj = (UnityEngine.GameObject)translator.GetObject(L, 2, typeof(UnityEngine.GameObject));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
