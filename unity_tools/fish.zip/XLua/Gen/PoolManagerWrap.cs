﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class PoolManagerWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(PoolManager);
			Utils.BeginObjectRegister(type, L, translator, 0, 7, 1, 1);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "SpawnTableObjs", _m_SpawnTableObjs);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Spawn", _m_Spawn);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "SpawnAsync", _m_SpawnAsync);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "AddPrefabAsync", _m_AddPrefabAsync);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "AddPrefab", _m_AddPrefab);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "CreatePool", _m_CreatePool);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "DestroyPool", _m_DestroyPool);
			
			
			Utils.RegisterFunc(L, Utils.GETTER_IDX, "pool", _g_get_pool);
            
			Utils.RegisterFunc(L, Utils.SETTER_IDX, "pool", _s_set_pool);
            
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 1, 1, 0);
			
			
            
			Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "Instance", _g_get_Instance);
            
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					PoolManager gen_ret = new PoolManager();
					translator.Push(L, gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to PoolManager constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SpawnTableObjs(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                PoolManager gen_to_be_invoked = (PoolManager)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 9&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TTABLE)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 3)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Type>(L, 5)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 6)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 7)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 8)&& translator.Assignable<System.Action>(L, 9)) 
                {
                    XLua.LuaTable _tab = (XLua.LuaTable)translator.GetObject(L, 2, typeof(XLua.LuaTable));
                    int _count = LuaAPI.xlua_tointeger(L, 3);
                    string _poolName = LuaAPI.lua_tostring(L, 4);
                    System.Type _type = (System.Type)translator.GetObject(L, 5, typeof(System.Type));
                    bool _isInstantiate = LuaAPI.lua_toboolean(L, 6);
                    float _delayDestroy = (float)LuaAPI.lua_tonumber(L, 7);
                    float _delayHide = (float)LuaAPI.lua_tonumber(L, 8);
                    System.Action _callBack = translator.GetDelegate<System.Action>(L, 9);
                    
                    gen_to_be_invoked.SpawnTableObjs( _tab, _count, _poolName, _type, _isInstantiate, _delayDestroy, _delayHide, _callBack );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 8&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TTABLE)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 3)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Type>(L, 5)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 6)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 7)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 8)) 
                {
                    XLua.LuaTable _tab = (XLua.LuaTable)translator.GetObject(L, 2, typeof(XLua.LuaTable));
                    int _count = LuaAPI.xlua_tointeger(L, 3);
                    string _poolName = LuaAPI.lua_tostring(L, 4);
                    System.Type _type = (System.Type)translator.GetObject(L, 5, typeof(System.Type));
                    bool _isInstantiate = LuaAPI.lua_toboolean(L, 6);
                    float _delayDestroy = (float)LuaAPI.lua_tonumber(L, 7);
                    float _delayHide = (float)LuaAPI.lua_tonumber(L, 8);
                    
                    gen_to_be_invoked.SpawnTableObjs( _tab, _count, _poolName, _type, _isInstantiate, _delayDestroy, _delayHide );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 7&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TTABLE)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 3)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Type>(L, 5)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 6)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 7)) 
                {
                    XLua.LuaTable _tab = (XLua.LuaTable)translator.GetObject(L, 2, typeof(XLua.LuaTable));
                    int _count = LuaAPI.xlua_tointeger(L, 3);
                    string _poolName = LuaAPI.lua_tostring(L, 4);
                    System.Type _type = (System.Type)translator.GetObject(L, 5, typeof(System.Type));
                    bool _isInstantiate = LuaAPI.lua_toboolean(L, 6);
                    float _delayDestroy = (float)LuaAPI.lua_tonumber(L, 7);
                    
                    gen_to_be_invoked.SpawnTableObjs( _tab, _count, _poolName, _type, _isInstantiate, _delayDestroy );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 6&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TTABLE)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 3)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Type>(L, 5)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 6)) 
                {
                    XLua.LuaTable _tab = (XLua.LuaTable)translator.GetObject(L, 2, typeof(XLua.LuaTable));
                    int _count = LuaAPI.xlua_tointeger(L, 3);
                    string _poolName = LuaAPI.lua_tostring(L, 4);
                    System.Type _type = (System.Type)translator.GetObject(L, 5, typeof(System.Type));
                    bool _isInstantiate = LuaAPI.lua_toboolean(L, 6);
                    
                    gen_to_be_invoked.SpawnTableObjs( _tab, _count, _poolName, _type, _isInstantiate );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 5&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TTABLE)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 3)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Type>(L, 5)) 
                {
                    XLua.LuaTable _tab = (XLua.LuaTable)translator.GetObject(L, 2, typeof(XLua.LuaTable));
                    int _count = LuaAPI.xlua_tointeger(L, 3);
                    string _poolName = LuaAPI.lua_tostring(L, 4);
                    System.Type _type = (System.Type)translator.GetObject(L, 5, typeof(System.Type));
                    
                    gen_to_be_invoked.SpawnTableObjs( _tab, _count, _poolName, _type );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 4&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TTABLE)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 3)&& (LuaAPI.lua_isnil(L, 4) || LuaAPI.lua_type(L, 4) == LuaTypes.LUA_TSTRING)) 
                {
                    XLua.LuaTable _tab = (XLua.LuaTable)translator.GetObject(L, 2, typeof(XLua.LuaTable));
                    int _count = LuaAPI.xlua_tointeger(L, 3);
                    string _poolName = LuaAPI.lua_tostring(L, 4);
                    
                    gen_to_be_invoked.SpawnTableObjs( _tab, _count, _poolName );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to PoolManager.SpawnTableObjs!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Spawn(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                PoolManager gen_to_be_invoked = (PoolManager)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 5&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Type>(L, 4)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 5)) 
                {
                    string _itemName = LuaAPI.lua_tostring(L, 2);
                    string _poolName = LuaAPI.lua_tostring(L, 3);
                    System.Type _type = (System.Type)translator.GetObject(L, 4, typeof(System.Type));
                    bool _isInstantiate = LuaAPI.lua_toboolean(L, 5);
                    
                        object gen_ret = gen_to_be_invoked.Spawn( _itemName, _poolName, _type, _isInstantiate );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                if(gen_param_count == 4&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Type>(L, 4)) 
                {
                    string _itemName = LuaAPI.lua_tostring(L, 2);
                    string _poolName = LuaAPI.lua_tostring(L, 3);
                    System.Type _type = (System.Type)translator.GetObject(L, 4, typeof(System.Type));
                    
                        object gen_ret = gen_to_be_invoked.Spawn( _itemName, _poolName, _type );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                if(gen_param_count == 3&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)) 
                {
                    string _itemName = LuaAPI.lua_tostring(L, 2);
                    string _poolName = LuaAPI.lua_tostring(L, 3);
                    
                        object gen_ret = gen_to_be_invoked.Spawn( _itemName, _poolName );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to PoolManager.Spawn!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SpawnAsync(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                PoolManager gen_to_be_invoked = (PoolManager)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 6&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Type>(L, 4)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 5)&& translator.Assignable<System.Action<UnityEngine.Object>>(L, 6)) 
                {
                    string _itemName = LuaAPI.lua_tostring(L, 2);
                    string _poolName = LuaAPI.lua_tostring(L, 3);
                    System.Type _type = (System.Type)translator.GetObject(L, 4, typeof(System.Type));
                    bool _isInstantiate = LuaAPI.lua_toboolean(L, 5);
                    System.Action<UnityEngine.Object> _callBack = translator.GetDelegate<System.Action<UnityEngine.Object>>(L, 6);
                    
                    gen_to_be_invoked.SpawnAsync( _itemName, _poolName, _type, _isInstantiate, _callBack );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 5&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Type>(L, 4)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 5)) 
                {
                    string _itemName = LuaAPI.lua_tostring(L, 2);
                    string _poolName = LuaAPI.lua_tostring(L, 3);
                    System.Type _type = (System.Type)translator.GetObject(L, 4, typeof(System.Type));
                    bool _isInstantiate = LuaAPI.lua_toboolean(L, 5);
                    
                    gen_to_be_invoked.SpawnAsync( _itemName, _poolName, _type, _isInstantiate );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 4&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Type>(L, 4)) 
                {
                    string _itemName = LuaAPI.lua_tostring(L, 2);
                    string _poolName = LuaAPI.lua_tostring(L, 3);
                    System.Type _type = (System.Type)translator.GetObject(L, 4, typeof(System.Type));
                    
                    gen_to_be_invoked.SpawnAsync( _itemName, _poolName, _type );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 3&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)) 
                {
                    string _itemName = LuaAPI.lua_tostring(L, 2);
                    string _poolName = LuaAPI.lua_tostring(L, 3);
                    
                    gen_to_be_invoked.SpawnAsync( _itemName, _poolName );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to PoolManager.SpawnAsync!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_AddPrefabAsync(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                PoolManager gen_to_be_invoked = (PoolManager)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 5&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Type>(L, 4)&& translator.Assignable<System.Action<UnityEngine.Object>>(L, 5)) 
                {
                    string _itemName = LuaAPI.lua_tostring(L, 2);
                    string _poolName = LuaAPI.lua_tostring(L, 3);
                    System.Type _type = (System.Type)translator.GetObject(L, 4, typeof(System.Type));
                    System.Action<UnityEngine.Object> _endCallBack = translator.GetDelegate<System.Action<UnityEngine.Object>>(L, 5);
                    
                    gen_to_be_invoked.AddPrefabAsync( _itemName, _poolName, _type, _endCallBack );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 4&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Type>(L, 4)) 
                {
                    string _itemName = LuaAPI.lua_tostring(L, 2);
                    string _poolName = LuaAPI.lua_tostring(L, 3);
                    System.Type _type = (System.Type)translator.GetObject(L, 4, typeof(System.Type));
                    
                    gen_to_be_invoked.AddPrefabAsync( _itemName, _poolName, _type );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 3&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)) 
                {
                    string _itemName = LuaAPI.lua_tostring(L, 2);
                    string _poolName = LuaAPI.lua_tostring(L, 3);
                    
                    gen_to_be_invoked.AddPrefabAsync( _itemName, _poolName );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to PoolManager.AddPrefabAsync!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_AddPrefab(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                PoolManager gen_to_be_invoked = (PoolManager)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 4&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Type>(L, 4)) 
                {
                    string _itemName = LuaAPI.lua_tostring(L, 2);
                    string _poolName = LuaAPI.lua_tostring(L, 3);
                    System.Type _type = (System.Type)translator.GetObject(L, 4, typeof(System.Type));
                    
                    gen_to_be_invoked.AddPrefab( _itemName, _poolName, _type );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 3&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& (LuaAPI.lua_isnil(L, 3) || LuaAPI.lua_type(L, 3) == LuaTypes.LUA_TSTRING)) 
                {
                    string _itemName = LuaAPI.lua_tostring(L, 2);
                    string _poolName = LuaAPI.lua_tostring(L, 3);
                    
                    gen_to_be_invoked.AddPrefab( _itemName, _poolName );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to PoolManager.AddPrefab!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_CreatePool(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                PoolManager gen_to_be_invoked = (PoolManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string _poolName = LuaAPI.lua_tostring(L, 2);
                    
                    gen_to_be_invoked.CreatePool( _poolName );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_DestroyPool(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                PoolManager gen_to_be_invoked = (PoolManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string _poolName = LuaAPI.lua_tostring(L, 2);
                    
                    gen_to_be_invoked.DestroyPool( _poolName );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_Instance(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, PoolManager.Instance);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_pool(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                PoolManager gen_to_be_invoked = (PoolManager)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.pool);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_pool(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                PoolManager gen_to_be_invoked = (PoolManager)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.pool = (System.Collections.Generic.Dictionary<string, System.Collections.Generic.Dictionary<string, NewSpawnPool>>)translator.GetObject(L, 2, typeof(System.Collections.Generic.Dictionary<string, System.Collections.Generic.Dictionary<string, NewSpawnPool>>));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
