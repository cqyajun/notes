﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class SdkToolWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(SdkTool);
			Utils.BeginObjectRegister(type, L, translator, 0, 0, 0, 0);
			
			
			
			
			
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 10, 8, 8);
			Utils.RegisterFunc(L, Utils.CLS_IDX, "initYXD", _m_initYXD_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "getDynamicIPByDomain", _m_getDynamicIPByDomain_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "getDynamicIPByIP", _m_getDynamicIPByIP_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "reportData", _m_reportData_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "getSession", _m_getSession_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "getLocalInfo", _m_getLocalInfo_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "getIp", _m_getIp_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "getPort", _m_getPort_xlua_st_);
            Utils.RegisterFunc(L, Utils.CLS_IDX, "showChatView", _m_showChatView_xlua_st_);
            
			
            
			Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "luaIp", _g_get_luaIp);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "luaPort", _g_get_luaPort);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "ret", _g_get_ret);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "initGameShieldSuccess", _g_get_initGameShieldSuccess);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "iapResult", _g_get_iapResult);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "AppId", _g_get_AppId);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "ChildAppId", _g_get_ChildAppId);
            Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "useSdk", _g_get_useSdk);
            
			Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "luaIp", _s_set_luaIp);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "luaPort", _s_set_luaPort);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "ret", _s_set_ret);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "initGameShieldSuccess", _s_set_initGameShieldSuccess);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "iapResult", _s_set_iapResult);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "AppId", _s_set_AppId);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "ChildAppId", _s_set_ChildAppId);
            Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "useSdk", _s_set_useSdk);
            
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					SdkTool gen_ret = new SdkTool();
					translator.Push(L, gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to SdkTool constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_initYXD_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string _appKey = LuaAPI.lua_tostring(L, 1);
                    string _token = LuaAPI.lua_tostring(L, 2);
                    
                        int gen_ret = SdkTool.initYXD( _appKey, _token );
                        LuaAPI.xlua_pushinteger(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_getDynamicIPByDomain_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string _groupName = LuaAPI.lua_tostring(L, 1);
                    string _token = LuaAPI.lua_tostring(L, 2);
                    string _szDomain = LuaAPI.lua_tostring(L, 3);
                    string _szPort = LuaAPI.lua_tostring(L, 4);
                    
                    SdkTool.getDynamicIPByDomain( _groupName, _token, _szDomain, _szPort );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_getDynamicIPByIP_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string _groupName = LuaAPI.lua_tostring(L, 1);
                    string _token = LuaAPI.lua_tostring(L, 2);
                    string _szIP = LuaAPI.lua_tostring(L, 3);
                    string _szPort = LuaAPI.lua_tostring(L, 4);
                    int _luaFunc = LuaAPI.xlua_tointeger(L, 5);
                    
                    SdkTool.getDynamicIPByIP( _groupName, _token, _szIP, _szPort, _luaFunc );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_reportData_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    int __type = LuaAPI.xlua_tointeger(L, 1);
                    string _report_msg = LuaAPI.lua_tostring(L, 2);
                    int _bsync = LuaAPI.xlua_tointeger(L, 3);
                    int _luaFunc = LuaAPI.xlua_tointeger(L, 4);
                    
                    SdkTool.reportData( __type, _report_msg, _bsync, _luaFunc );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_getSession_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    int _luaFunc = LuaAPI.xlua_tointeger(L, 1);
                    
                    SdkTool.getSession( _luaFunc );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_getLocalInfo_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    int _luaFunc = LuaAPI.xlua_tointeger(L, 1);
                    
                    SdkTool.getLocalInfo( _luaFunc );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_getIp_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    
                    SdkTool.getIp(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_getPort_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    
                    SdkTool.getPort(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_showChatView_xlua_st_(RealStatePtr L)
        {
		    try {
            
            
            
                
                {
                    string _url = LuaAPI.lua_tostring(L, 1);
                    string _param = LuaAPI.lua_tostring(L, 2);
                    
                    SdkTool.showChatView( _url, _param );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_luaIp(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, SdkTool.luaIp);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_luaPort(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, SdkTool.luaPort);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_ret(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.xlua_pushinteger(L, SdkTool.ret);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_initGameShieldSuccess(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushboolean(L, SdkTool.initGameShieldSuccess);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_iapResult(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushstring(L, SdkTool.iapResult);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_AppId(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.xlua_pushinteger(L, SdkTool.AppId);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_ChildAppId(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.xlua_pushinteger(L, SdkTool.ChildAppId);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_useSdk(RealStatePtr L)
        {
		    try {
            
			    LuaAPI.lua_pushboolean(L, SdkTool.useSdk);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_luaIp(RealStatePtr L)
        {
		    try {
                
			    SdkTool.luaIp = LuaAPI.lua_tostring(L, 1);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_luaPort(RealStatePtr L)
        {
		    try {
                
			    SdkTool.luaPort = LuaAPI.lua_tostring(L, 1);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_ret(RealStatePtr L)
        {
		    try {
                
			    SdkTool.ret = LuaAPI.xlua_tointeger(L, 1);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_initGameShieldSuccess(RealStatePtr L)
        {
		    try {
                
			    SdkTool.initGameShieldSuccess = LuaAPI.lua_toboolean(L, 1);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_iapResult(RealStatePtr L)
        {
		    try {
                
			    SdkTool.iapResult = LuaAPI.lua_tostring(L, 1);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_AppId(RealStatePtr L)
        {
		    try {
                
			    SdkTool.AppId = LuaAPI.xlua_tointeger(L, 1);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_ChildAppId(RealStatePtr L)
        {
		    try {
                
			    SdkTool.ChildAppId = LuaAPI.xlua_tointeger(L, 1);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_useSdk(RealStatePtr L)
        {
		    try {
                
			    SdkTool.useSdk = LuaAPI.lua_toboolean(L, 1);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
