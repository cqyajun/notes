﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class SystemRuntimeSerializationFormattersBinaryBinaryFormatterWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(System.Runtime.Serialization.Formatters.Binary.BinaryFormatter);
			Utils.BeginObjectRegister(type, L, translator, 0, 5, 6, 6);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Deserialize", _m_Deserialize);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "DeserializeMethodResponse", _m_DeserializeMethodResponse);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Serialize", _m_Serialize);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "UnsafeDeserialize", _m_UnsafeDeserialize);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "UnsafeDeserializeMethodResponse", _m_UnsafeDeserializeMethodResponse);
			
			
			Utils.RegisterFunc(L, Utils.GETTER_IDX, "AssemblyFormat", _g_get_AssemblyFormat);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "Binder", _g_get_Binder);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "Context", _g_get_Context);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "SurrogateSelector", _g_get_SurrogateSelector);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "TypeFormat", _g_get_TypeFormat);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "FilterLevel", _g_get_FilterLevel);
            
			Utils.RegisterFunc(L, Utils.SETTER_IDX, "AssemblyFormat", _s_set_AssemblyFormat);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "Binder", _s_set_Binder);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "Context", _s_set_Context);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "SurrogateSelector", _s_set_SurrogateSelector);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "TypeFormat", _s_set_TypeFormat);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "FilterLevel", _s_set_FilterLevel);
            
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 1, 1, 1);
			
			
            
			Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "DefaultSurrogateSelector", _g_get_DefaultSurrogateSelector);
            
			Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "DefaultSurrogateSelector", _s_set_DefaultSurrogateSelector);
            
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_ret = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
					translator.Push(L, gen_ret);
                    
					return 1;
				}
				if(LuaAPI.lua_gettop(L) == 3 && translator.Assignable<System.Runtime.Serialization.ISurrogateSelector>(L, 2) && translator.Assignable<System.Runtime.Serialization.StreamingContext>(L, 3))
				{
					System.Runtime.Serialization.ISurrogateSelector _selector = (System.Runtime.Serialization.ISurrogateSelector)translator.GetObject(L, 2, typeof(System.Runtime.Serialization.ISurrogateSelector));
					System.Runtime.Serialization.StreamingContext _context;translator.Get(L, 3, out _context);
					
					System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_ret = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter(_selector, _context);
					translator.Push(L, gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to System.Runtime.Serialization.Formatters.Binary.BinaryFormatter constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Deserialize(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_to_be_invoked = (System.Runtime.Serialization.Formatters.Binary.BinaryFormatter)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 2&& translator.Assignable<System.IO.Stream>(L, 2)) 
                {
                    System.IO.Stream _serializationStream = (System.IO.Stream)translator.GetObject(L, 2, typeof(System.IO.Stream));
                    
                        object gen_ret = gen_to_be_invoked.Deserialize( _serializationStream );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                if(gen_param_count == 3&& translator.Assignable<System.IO.Stream>(L, 2)&& translator.Assignable<System.Runtime.Remoting.Messaging.HeaderHandler>(L, 3)) 
                {
                    System.IO.Stream _serializationStream = (System.IO.Stream)translator.GetObject(L, 2, typeof(System.IO.Stream));
                    System.Runtime.Remoting.Messaging.HeaderHandler _handler = translator.GetDelegate<System.Runtime.Remoting.Messaging.HeaderHandler>(L, 3);
                    
                        object gen_ret = gen_to_be_invoked.Deserialize( _serializationStream, _handler );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to System.Runtime.Serialization.Formatters.Binary.BinaryFormatter.Deserialize!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_DeserializeMethodResponse(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_to_be_invoked = (System.Runtime.Serialization.Formatters.Binary.BinaryFormatter)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    System.IO.Stream _serializationStream = (System.IO.Stream)translator.GetObject(L, 2, typeof(System.IO.Stream));
                    System.Runtime.Remoting.Messaging.HeaderHandler _handler = translator.GetDelegate<System.Runtime.Remoting.Messaging.HeaderHandler>(L, 3);
                    System.Runtime.Remoting.Messaging.IMethodCallMessage _methodCallMessage = (System.Runtime.Remoting.Messaging.IMethodCallMessage)translator.GetObject(L, 4, typeof(System.Runtime.Remoting.Messaging.IMethodCallMessage));
                    
                        object gen_ret = gen_to_be_invoked.DeserializeMethodResponse( _serializationStream, _handler, _methodCallMessage );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Serialize(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_to_be_invoked = (System.Runtime.Serialization.Formatters.Binary.BinaryFormatter)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 3&& translator.Assignable<System.IO.Stream>(L, 2)&& translator.Assignable<object>(L, 3)) 
                {
                    System.IO.Stream _serializationStream = (System.IO.Stream)translator.GetObject(L, 2, typeof(System.IO.Stream));
                    object _graph = translator.GetObject(L, 3, typeof(object));
                    
                    gen_to_be_invoked.Serialize( _serializationStream, _graph );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 4&& translator.Assignable<System.IO.Stream>(L, 2)&& translator.Assignable<object>(L, 3)&& translator.Assignable<System.Runtime.Remoting.Messaging.Header[]>(L, 4)) 
                {
                    System.IO.Stream _serializationStream = (System.IO.Stream)translator.GetObject(L, 2, typeof(System.IO.Stream));
                    object _graph = translator.GetObject(L, 3, typeof(object));
                    System.Runtime.Remoting.Messaging.Header[] _headers = (System.Runtime.Remoting.Messaging.Header[])translator.GetObject(L, 4, typeof(System.Runtime.Remoting.Messaging.Header[]));
                    
                    gen_to_be_invoked.Serialize( _serializationStream, _graph, _headers );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to System.Runtime.Serialization.Formatters.Binary.BinaryFormatter.Serialize!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_UnsafeDeserialize(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_to_be_invoked = (System.Runtime.Serialization.Formatters.Binary.BinaryFormatter)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    System.IO.Stream _serializationStream = (System.IO.Stream)translator.GetObject(L, 2, typeof(System.IO.Stream));
                    System.Runtime.Remoting.Messaging.HeaderHandler _handler = translator.GetDelegate<System.Runtime.Remoting.Messaging.HeaderHandler>(L, 3);
                    
                        object gen_ret = gen_to_be_invoked.UnsafeDeserialize( _serializationStream, _handler );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_UnsafeDeserializeMethodResponse(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_to_be_invoked = (System.Runtime.Serialization.Formatters.Binary.BinaryFormatter)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    System.IO.Stream _serializationStream = (System.IO.Stream)translator.GetObject(L, 2, typeof(System.IO.Stream));
                    System.Runtime.Remoting.Messaging.HeaderHandler _handler = translator.GetDelegate<System.Runtime.Remoting.Messaging.HeaderHandler>(L, 3);
                    System.Runtime.Remoting.Messaging.IMethodCallMessage _methodCallMessage = (System.Runtime.Remoting.Messaging.IMethodCallMessage)translator.GetObject(L, 4, typeof(System.Runtime.Remoting.Messaging.IMethodCallMessage));
                    
                        object gen_ret = gen_to_be_invoked.UnsafeDeserializeMethodResponse( _serializationStream, _handler, _methodCallMessage );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_DefaultSurrogateSelector(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.PushAny(L, System.Runtime.Serialization.Formatters.Binary.BinaryFormatter.DefaultSurrogateSelector);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_AssemblyFormat(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_to_be_invoked = (System.Runtime.Serialization.Formatters.Binary.BinaryFormatter)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.AssemblyFormat);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_Binder(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_to_be_invoked = (System.Runtime.Serialization.Formatters.Binary.BinaryFormatter)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.Binder);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_Context(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_to_be_invoked = (System.Runtime.Serialization.Formatters.Binary.BinaryFormatter)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.Context);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_SurrogateSelector(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_to_be_invoked = (System.Runtime.Serialization.Formatters.Binary.BinaryFormatter)translator.FastGetCSObj(L, 1);
                translator.PushAny(L, gen_to_be_invoked.SurrogateSelector);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_TypeFormat(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_to_be_invoked = (System.Runtime.Serialization.Formatters.Binary.BinaryFormatter)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.TypeFormat);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_FilterLevel(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_to_be_invoked = (System.Runtime.Serialization.Formatters.Binary.BinaryFormatter)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.FilterLevel);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_DefaultSurrogateSelector(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    System.Runtime.Serialization.Formatters.Binary.BinaryFormatter.DefaultSurrogateSelector = (System.Runtime.Serialization.ISurrogateSelector)translator.GetObject(L, 1, typeof(System.Runtime.Serialization.ISurrogateSelector));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_AssemblyFormat(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_to_be_invoked = (System.Runtime.Serialization.Formatters.Binary.BinaryFormatter)translator.FastGetCSObj(L, 1);
                System.Runtime.Serialization.Formatters.FormatterAssemblyStyle gen_value;translator.Get(L, 2, out gen_value);
				gen_to_be_invoked.AssemblyFormat = gen_value;
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_Binder(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_to_be_invoked = (System.Runtime.Serialization.Formatters.Binary.BinaryFormatter)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.Binder = (System.Runtime.Serialization.SerializationBinder)translator.GetObject(L, 2, typeof(System.Runtime.Serialization.SerializationBinder));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_Context(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_to_be_invoked = (System.Runtime.Serialization.Formatters.Binary.BinaryFormatter)translator.FastGetCSObj(L, 1);
                System.Runtime.Serialization.StreamingContext gen_value;translator.Get(L, 2, out gen_value);
				gen_to_be_invoked.Context = gen_value;
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_SurrogateSelector(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_to_be_invoked = (System.Runtime.Serialization.Formatters.Binary.BinaryFormatter)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.SurrogateSelector = (System.Runtime.Serialization.ISurrogateSelector)translator.GetObject(L, 2, typeof(System.Runtime.Serialization.ISurrogateSelector));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_TypeFormat(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_to_be_invoked = (System.Runtime.Serialization.Formatters.Binary.BinaryFormatter)translator.FastGetCSObj(L, 1);
                System.Runtime.Serialization.Formatters.FormatterTypeStyle gen_value;translator.Get(L, 2, out gen_value);
				gen_to_be_invoked.TypeFormat = gen_value;
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_FilterLevel(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter gen_to_be_invoked = (System.Runtime.Serialization.Formatters.Binary.BinaryFormatter)translator.FastGetCSObj(L, 1);
                System.Runtime.Serialization.Formatters.TypeFilterLevel gen_value;translator.Get(L, 2, out gen_value);
				gen_to_be_invoked.FilterLevel = gen_value;
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
