﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class DownloadManagerWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(DownloadManager);
			Utils.BeginObjectRegister(type, L, translator, 0, 11, 4, 4);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetVersion", _m_GetVersion);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetURL", _m_GetURL);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "CheckIsDownLoadGroup", _m_CheckIsDownLoadGroup);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "ChangeDownloadCallback", _m_ChangeDownloadCallback);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "CheckDownLoadGroup", _m_CheckDownLoadGroup);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "DownLoadGroup", _m_DownLoadGroup);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetLocalGroupMsg", _m_GetLocalGroupMsg);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "StartDownLoad", _m_StartDownLoad);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "UpdateWebRequestProgress", _m_UpdateWebRequestProgress);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "UpdateCurrentGroupDownload", _m_UpdateCurrentGroupDownload);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "WebRequestFailure", _m_WebRequestFailure);
			
			
			Utils.RegisterFunc(L, Utils.GETTER_IDX, "startGroupNames", _g_get_startGroupNames);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "luaName", _g_get_luaName);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "downloadGroupCallBack", _g_get_downloadGroupCallBack);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "tabVersion", _g_get_tabVersion);
            
			Utils.RegisterFunc(L, Utils.SETTER_IDX, "startGroupNames", _s_set_startGroupNames);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "luaName", _s_set_luaName);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "downloadGroupCallBack", _s_set_downloadGroupCallBack);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "tabVersion", _s_set_tabVersion);
            
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 1, 1, 0);
			
			
            
			Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "Instance", _g_get_Instance);
            
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					DownloadManager gen_ret = new DownloadManager();
					translator.Push(L, gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to DownloadManager constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetVersion(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        System.Collections.IEnumerator gen_ret = gen_to_be_invoked.GetVersion(  );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetURL(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string _group = LuaAPI.lua_tostring(L, 2);
                    
                        string gen_ret = gen_to_be_invoked.GetURL( _group );
                        LuaAPI.lua_pushstring(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_CheckIsDownLoadGroup(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string _groupName = LuaAPI.lua_tostring(L, 2);
                    
                        bool gen_ret = gen_to_be_invoked.CheckIsDownLoadGroup( _groupName );
                        LuaAPI.lua_pushboolean(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ChangeDownloadCallback(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string _groupName = LuaAPI.lua_tostring(L, 2);
                    System.Action<float> _dgCallback = translator.GetDelegate<System.Action<float>>(L, 3);
                    
                    gen_to_be_invoked.ChangeDownloadCallback( _groupName, _dgCallback );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_CheckDownLoadGroup(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 3&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& translator.Assignable<System.Action<bool>>(L, 3)) 
                {
                    string _groupName = LuaAPI.lua_tostring(L, 2);
                    System.Action<bool> _callBack = translator.GetDelegate<System.Action<bool>>(L, 3);
                    
                        System.Collections.IEnumerator gen_ret = gen_to_be_invoked.CheckDownLoadGroup( _groupName, _callBack );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                if(gen_param_count == 2&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)) 
                {
                    string _groupName = LuaAPI.lua_tostring(L, 2);
                    
                        System.Collections.IEnumerator gen_ret = gen_to_be_invoked.CheckDownLoadGroup( _groupName );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to DownloadManager.CheckDownLoadGroup!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_DownLoadGroup(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 3&& translator.Assignable<System.Collections.Generic.List<string>>(L, 2)&& translator.Assignable<System.Action<float>>(L, 3)) 
                {
                    System.Collections.Generic.List<string> _groupNames = (System.Collections.Generic.List<string>)translator.GetObject(L, 2, typeof(System.Collections.Generic.List<string>));
                    System.Action<float> _dgCallback = translator.GetDelegate<System.Action<float>>(L, 3);
                    
                        System.Collections.IEnumerator gen_ret = gen_to_be_invoked.DownLoadGroup( _groupNames, _dgCallback );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                if(gen_param_count == 2&& translator.Assignable<System.Collections.Generic.List<string>>(L, 2)) 
                {
                    System.Collections.Generic.List<string> _groupNames = (System.Collections.Generic.List<string>)translator.GetObject(L, 2, typeof(System.Collections.Generic.List<string>));
                    
                        System.Collections.IEnumerator gen_ret = gen_to_be_invoked.DownLoadGroup( _groupNames );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to DownloadManager.DownLoadGroup!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetLocalGroupMsg(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string _groupName = LuaAPI.lua_tostring(L, 2);
                    
                    gen_to_be_invoked.GetLocalGroupMsg( _groupName );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_StartDownLoad(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        System.Collections.IEnumerator gen_ret = gen_to_be_invoked.StartDownLoad(  );
                        translator.PushAny(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_UpdateWebRequestProgress(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    long _size = LuaAPI.lua_toint64(L, 2);
                    
                    gen_to_be_invoked.UpdateWebRequestProgress( _size );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_UpdateCurrentGroupDownload(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    string _groupName = LuaAPI.lua_tostring(L, 2);
                    long _size = LuaAPI.lua_toint64(L, 3);
                    
                    gen_to_be_invoked.UpdateCurrentGroupDownload( _groupName, _size );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_WebRequestFailure(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    WebReconnection _webReconnection = (WebReconnection)translator.GetObject(L, 2, typeof(WebReconnection));
                    
                    gen_to_be_invoked.WebRequestFailure( _webReconnection );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_Instance(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, DownloadManager.Instance);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_startGroupNames(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.startGroupNames);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_luaName(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushstring(L, gen_to_be_invoked.luaName);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_downloadGroupCallBack(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.downloadGroupCallBack);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_tabVersion(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.tabVersion);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_startGroupNames(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.startGroupNames = (System.Collections.Generic.List<string>)translator.GetObject(L, 2, typeof(System.Collections.Generic.List<string>));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_luaName(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.luaName = LuaAPI.lua_tostring(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_downloadGroupCallBack(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.downloadGroupCallBack = (System.Collections.Generic.Dictionary<string, System.Action<float>>)translator.GetObject(L, 2, typeof(System.Collections.Generic.Dictionary<string, System.Action<float>>));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_tabVersion(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                DownloadManager gen_to_be_invoked = (DownloadManager)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.tabVersion = (XLua.LuaTable)translator.GetObject(L, 2, typeof(XLua.LuaTable));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
