group_1016 = {{["fishType"] = 1,["startFps"] = 1,["trackID"] = 1016,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 50,["trackID"] = 1016,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 100,["trackID"] = 1016,["x"] = 0,["y"] = 0},
{["fishType"] = 36,["startFps"] = 150,["trackID"] = 1016,["x"] = 0,["y"] = 0},
}