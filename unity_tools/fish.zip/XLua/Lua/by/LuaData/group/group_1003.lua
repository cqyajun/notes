group_1003 = {{["fishType"] = 4,["startFps"] = 1,["trackID"] = 1003,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 100,["trackID"] = 1003,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 200,["trackID"] = 1003,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 300,["trackID"] = 1003,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 400,["trackID"] = 1003,["x"] = 0,["y"] = 0},
}