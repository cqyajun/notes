group_2020 = {{["fishType"] = 15,["startFps"] = 1,["trackID"] = 2020,["x"] = 0,["y"] = 0},
}