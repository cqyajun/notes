group_20 = {{["fishType"] = 2,["startFps"] = 1,["trackID"] = 219,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 6,["trackID"] = 219,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 11,["trackID"] = 219,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 16,["trackID"] = 219,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 21,["trackID"] = 219,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 26,["trackID"] = 219,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 31,["trackID"] = 219,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 36,["trackID"] = 219,["x"] = 0,["y"] = 0},
}