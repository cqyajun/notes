group_1018 = {{["fishType"] = 1,["startFps"] = 1,["trackID"] = 1018,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 50,["trackID"] = 1018,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 100,["trackID"] = 1018,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 150,["trackID"] = 1018,["x"] = 0,["y"] = 0},
{["fishType"] = 37,["startFps"] = 200,["trackID"] = 1018,["x"] = 0,["y"] = 0},
}