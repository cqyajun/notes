group_1034 = {{["fishType"] = 11,["startFps"] = 1,["trackID"] = 1034,["x"] = 0,["y"] = 0},
{["fishType"] = 11,["startFps"] = 300,["trackID"] = 1034,["x"] = 0,["y"] = 0},
{["fishType"] = 11,["startFps"] = 600,["trackID"] = 1034,["x"] = 0,["y"] = 0},
{["fishType"] = 11,["startFps"] = 900,["trackID"] = 1034,["x"] = 0,["y"] = 0},
{["fishType"] = 11,["startFps"] = 1200,["trackID"] = 1034,["x"] = 0,["y"] = 0},
}