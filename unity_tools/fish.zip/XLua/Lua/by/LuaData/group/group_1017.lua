group_1017 = {{["fishType"] = 5,["startFps"] = 1,["trackID"] = 1017,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 50,["trackID"] = 1017,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 100,["trackID"] = 1017,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 150,["trackID"] = 1017,["x"] = 0,["y"] = 0},
}