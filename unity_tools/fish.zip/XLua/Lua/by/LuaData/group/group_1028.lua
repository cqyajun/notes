group_1028 = {{["fishType"] = 6,["startFps"] = 1,["trackID"] = 1028,["x"] = 0,["y"] = 0},
{["fishType"] = 7,["startFps"] = 100,["trackID"] = 1028,["x"] = 0,["y"] = 0},
{["fishType"] = 8,["startFps"] = 200,["trackID"] = 1028,["x"] = 0,["y"] = 0},
{["fishType"] = 9,["startFps"] = 300,["trackID"] = 1028,["x"] = 0,["y"] = 0},
{["fishType"] = 6,["startFps"] = 400,["trackID"] = 1028,["x"] = 0,["y"] = 0},
}