group_2013 = {{["fishType"] = 1,["startFps"] = 1,["trackID"] = 2013,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 20,["trackID"] = 2013,["x"] = 0,["y"] = 0},
{["fishType"] = 36,["startFps"] = 40,["trackID"] = 2013,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 60,["trackID"] = 2013,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 80,["trackID"] = 2013,["x"] = 0,["y"] = 0},
}