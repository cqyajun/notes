group_3013 = {{["fishType"] = 4,["startFps"] = 1,["trackID"] = 3013,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 20,["trackID"] = 3013,["x"] = 0,["y"] = 50},
{["fishType"] = 4,["startFps"] = 20,["trackID"] = 3013,["x"] = 0,["y"] = -50},
{["fishType"] = 4,["startFps"] = 40,["trackID"] = 3013,["x"] = 0,["y"] = 80},
{["fishType"] = 4,["startFps"] = 40,["trackID"] = 3013,["x"] = 0,["y"] = -80},
}