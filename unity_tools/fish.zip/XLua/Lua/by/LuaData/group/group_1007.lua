group_1007 = {{["fishType"] = 4,["startFps"] = 1,["trackID"] = 1007,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 30,["trackID"] = 1007,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 60,["trackID"] = 1007,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 90,["trackID"] = 1007,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 120,["trackID"] = 1007,["x"] = 0,["y"] = 0},
}