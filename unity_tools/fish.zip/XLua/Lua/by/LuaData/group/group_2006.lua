group_2006 = {{["fishType"] = 2,["startFps"] = 1,["trackID"] = 2006,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 20,["trackID"] = 2006,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 40,["trackID"] = 2006,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 60,["trackID"] = 2006,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 80,["trackID"] = 2006,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 100,["trackID"] = 2006,["x"] = 0,["y"] = 0},
}