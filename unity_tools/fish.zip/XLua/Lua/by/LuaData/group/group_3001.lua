group_3001 = {{["fishType"] = 1,["startFps"] = 1,["trackID"] = 3001,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 30,["trackID"] = 3001,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 60,["trackID"] = 3001,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 90,["trackID"] = 3001,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 120,["trackID"] = 3001,["x"] = 0,["y"] = 0},
}