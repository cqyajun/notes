group_2011 = {{["fishType"] = 5,["startFps"] = 1,["trackID"] = 2011,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 30,["trackID"] = 2011,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 60,["trackID"] = 2011,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 90,["trackID"] = 2011,["x"] = 0,["y"] = 0},
}