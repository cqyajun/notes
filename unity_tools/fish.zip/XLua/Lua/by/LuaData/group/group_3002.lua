group_3002 = {{["fishType"] = 1,["startFps"] = 1,["trackID"] = 3002,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 20,["trackID"] = 3002,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 40,["trackID"] = 3002,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 60,["trackID"] = 3002,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 80,["trackID"] = 3002,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 100,["trackID"] = 3002,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 120,["trackID"] = 3002,["x"] = 0,["y"] = 0},
}