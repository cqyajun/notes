group_21 = {{["fishType"] = 3,["startFps"] = 1,["trackID"] = 220,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 6,["trackID"] = 220,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 11,["trackID"] = 220,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 16,["trackID"] = 220,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 21,["trackID"] = 220,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 26,["trackID"] = 220,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 31,["trackID"] = 220,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 36,["trackID"] = 220,["x"] = 0,["y"] = 0},
}