group_3014 = {{["fishType"] = 2,["startFps"] = 1,["trackID"] = 3014,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 20,["trackID"] = 3014,["x"] = 0,["y"] = 80},
{["fishType"] = 2,["startFps"] = 20,["trackID"] = 3014,["x"] = 0,["y"] = -80},
{["fishType"] = 2,["startFps"] = 40,["trackID"] = 3014,["x"] = 0,["y"] = 0},
}