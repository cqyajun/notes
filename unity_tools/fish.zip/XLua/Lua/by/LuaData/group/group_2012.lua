group_2012 = {{["fishType"] = 5,["startFps"] = 1,["trackID"] = 2012,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 25,["trackID"] = 2012,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 50,["trackID"] = 2012,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 75,["trackID"] = 2012,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 100,["trackID"] = 2012,["x"] = 0,["y"] = 0},
}