group_2016 = {{["fishType"] = 4,["startFps"] = 1,["trackID"] = 2016,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 30,["trackID"] = 2016,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 60,["trackID"] = 2016,["x"] = 0,["y"] = 0},
{["fishType"] = 37,["startFps"] = 90,["trackID"] = 2016,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 120,["trackID"] = 2016,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 150,["trackID"] = 2016,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 180,["trackID"] = 2016,["x"] = 0,["y"] = 0},
}