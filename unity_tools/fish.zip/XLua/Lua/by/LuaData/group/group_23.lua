group_23 = {{["fishType"] = 29,["startFps"] = 1,["trackID"] = 222,["x"] = 0,["y"] = 0},
{["fishType"] = 29,["startFps"] = 480,["trackID"] = 222,["x"] = 0,["y"] = 0},
{["fishType"] = 29,["startFps"] = 960,["trackID"] = 222,["x"] = 0,["y"] = 0},
{["fishType"] = 29,["startFps"] = 1440,["trackID"] = 222,["x"] = 0,["y"] = 0},
}