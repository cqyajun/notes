group_3012 = {{["fishType"] = 3,["startFps"] = 1,["trackID"] = 3012,["x"] = 0,["y"] = 80},
{["fishType"] = 3,["startFps"] = 1,["trackID"] = 3012,["x"] = 0,["y"] = -80},
{["fishType"] = 3,["startFps"] = 20,["trackID"] = 3012,["x"] = 0,["y"] = 80},
{["fishType"] = 3,["startFps"] = 20,["trackID"] = 3012,["x"] = 0,["y"] = -80},
}