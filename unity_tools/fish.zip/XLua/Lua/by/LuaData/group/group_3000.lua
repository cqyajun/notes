group_3000 = {{["fishType"] = 1,["startFps"] = 1,["trackID"] = 3000,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 20,["trackID"] = 3000,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 40,["trackID"] = 3000,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 60,["trackID"] = 3000,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 80,["trackID"] = 3000,["x"] = 0,["y"] = 0},
}