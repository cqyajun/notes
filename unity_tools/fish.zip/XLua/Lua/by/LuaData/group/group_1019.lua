group_1019 = {{["fishType"] = 5,["startFps"] = 1,["trackID"] = 1019,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 25,["trackID"] = 1019,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 50,["trackID"] = 1019,["x"] = 0,["y"] = 0},
}