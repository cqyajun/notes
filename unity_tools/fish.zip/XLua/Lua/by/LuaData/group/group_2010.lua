group_2010 = {{["fishType"] = 4,["startFps"] = 1,["trackID"] = 2010,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 30,["trackID"] = 2010,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 60,["trackID"] = 2010,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 90,["trackID"] = 2010,["x"] = 0,["y"] = 0},
}