group_3003 = {{["fishType"] = 4,["startFps"] = 1,["trackID"] = 3003,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 25,["trackID"] = 3003,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 50,["trackID"] = 3003,["x"] = 0,["y"] = 0},
}