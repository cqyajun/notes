group_2019 = {{["fishType"] = 5,["startFps"] = 1,["trackID"] = 2019,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 30,["trackID"] = 2019,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 60,["trackID"] = 2019,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 90,["trackID"] = 2019,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 120,["trackID"] = 2019,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 150,["trackID"] = 2019,["x"] = 0,["y"] = 0},
}