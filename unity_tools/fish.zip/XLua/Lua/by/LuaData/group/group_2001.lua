group_2001 = {{["fishType"] = 2,["startFps"] = 1,["trackID"] = 2001,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 20,["trackID"] = 2001,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 40,["trackID"] = 2001,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 60,["trackID"] = 2001,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 80,["trackID"] = 2001,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 100,["trackID"] = 2001,["x"] = 0,["y"] = 0},
}