group_3028 = {{["fishType"] = 23,["startFps"] = 1,["trackID"] = 1000,["x"] = 0,["y"] = 0},
{["fishType"] = 24,["startFps"] = 1,["trackID"] = 1002,["x"] = 0,["y"] = 0},
{["fishType"] = 25,["startFps"] = 1,["trackID"] = 1007,["x"] = 0,["y"] = 0},
{["fishType"] = 26,["startFps"] = 1,["trackID"] = 1008,["x"] = 0,["y"] = 0},
{["fishType"] = 27,["startFps"] = 1,["trackID"] = 1009,["x"] = 0,["y"] = 0},
}