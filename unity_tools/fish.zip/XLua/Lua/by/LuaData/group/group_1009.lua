group_1009 = {{["fishType"] = 3,["startFps"] = 1,["trackID"] = 1009,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 30,["trackID"] = 1009,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 60,["trackID"] = 1009,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 90,["trackID"] = 1009,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 120,["trackID"] = 1009,["x"] = 0,["y"] = 0},
}