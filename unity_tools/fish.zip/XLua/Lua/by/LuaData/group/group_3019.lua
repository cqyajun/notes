group_3019 = {{["fishType"] = 2,["startFps"] = 1,["trackID"] = 3019,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 20,["trackID"] = 3019,["x"] = 0,["y"] = 0},
{["fishType"] = 37,["startFps"] = 40,["trackID"] = 3019,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 60,["trackID"] = 3019,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 80,["trackID"] = 3019,["x"] = 0,["y"] = 0},
}