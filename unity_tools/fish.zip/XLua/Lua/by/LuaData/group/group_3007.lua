group_3007 = {{["fishType"] = 36,["startFps"] = 1,["trackID"] = 3007,["x"] = 0,["y"] = 0},
{["fishType"] = 36,["startFps"] = 30,["trackID"] = 3007,["x"] = 0,["y"] = 0},
{["fishType"] = 36,["startFps"] = 60,["trackID"] = 3007,["x"] = 0,["y"] = 0},
{["fishType"] = 36,["startFps"] = 90,["trackID"] = 3007,["x"] = 0,["y"] = 0},
{["fishType"] = 36,["startFps"] = 120,["trackID"] = 3007,["x"] = 0,["y"] = 0},
}