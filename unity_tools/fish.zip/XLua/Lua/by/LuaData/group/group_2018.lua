group_2018 = {{["fishType"] = 1,["startFps"] = 1,["trackID"] = 2018,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 50,["trackID"] = 2018,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 100,["trackID"] = 2018,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 150,["trackID"] = 2018,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 200,["trackID"] = 2018,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 250,["trackID"] = 2018,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 300,["trackID"] = 2018,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 350,["trackID"] = 2018,["x"] = 0,["y"] = 0},
}