group_3025 = {{["fishType"] = 15,["startFps"] = 1,["trackID"] = 3025,["x"] = 0,["y"] = 0},
{["fishType"] = 12,["startFps"] = 100,["trackID"] = 3025,["x"] = 0,["y"] = 0},
{["fishType"] = 12,["startFps"] = 200,["trackID"] = 3025,["x"] = 0,["y"] = 0},
{["fishType"] = 12,["startFps"] = 300,["trackID"] = 3025,["x"] = 0,["y"] = 0},
{["fishType"] = 12,["startFps"] = 400,["trackID"] = 3025,["x"] = 0,["y"] = 0},
{["fishType"] = 12,["startFps"] = 500,["trackID"] = 3025,["x"] = 0,["y"] = 0},
{["fishType"] = 12,["startFps"] = 600,["trackID"] = 3025,["x"] = 0,["y"] = 0},
{["fishType"] = 12,["startFps"] = 700,["trackID"] = 3025,["x"] = 0,["y"] = 0},
}