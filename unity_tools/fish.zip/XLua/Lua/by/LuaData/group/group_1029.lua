group_1029 = {{["fishType"] = 20,["startFps"] = 1,["trackID"] = 1029,["x"] = 0,["y"] = 0},
{["fishType"] = 8,["startFps"] = 150,["trackID"] = 1029,["x"] = 0,["y"] = 0},
{["fishType"] = 8,["startFps"] = 300,["trackID"] = 1029,["x"] = 0,["y"] = 0},
{["fishType"] = 9,["startFps"] = 450,["trackID"] = 1029,["x"] = 0,["y"] = 0},
{["fishType"] = 13,["startFps"] = 600,["trackID"] = 1029,["x"] = 0,["y"] = 0},
}