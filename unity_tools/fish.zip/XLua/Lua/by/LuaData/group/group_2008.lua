group_2008 = {{["fishType"] = 5,["startFps"] = 1,["trackID"] = 2008,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 50,["trackID"] = 2008,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 100,["trackID"] = 2008,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 150,["trackID"] = 2008,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 200,["trackID"] = 2008,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 250,["trackID"] = 2008,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 300,["trackID"] = 2008,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 350,["trackID"] = 2008,["x"] = 0,["y"] = 0},
}