group_2003 = {{["fishType"] = 4,["startFps"] = 1,["trackID"] = 2003,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 30,["trackID"] = 2003,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 60,["trackID"] = 2003,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 90,["trackID"] = 2003,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 120,["trackID"] = 2003,["x"] = 0,["y"] = 0},
}