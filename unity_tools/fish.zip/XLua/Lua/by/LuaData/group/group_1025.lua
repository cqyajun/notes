group_1025 = {{["fishType"] = 28,["startFps"] = 1,["trackID"] = 1025,["x"] = 0,["y"] = 0},
}