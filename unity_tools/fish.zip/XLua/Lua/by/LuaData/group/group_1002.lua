group_1002 = {{["fishType"] = 3,["startFps"] = 1,["trackID"] = 1002,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 30,["trackID"] = 1002,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 60,["trackID"] = 1002,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 90,["trackID"] = 1002,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 120,["trackID"] = 1002,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 150,["trackID"] = 1002,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 180,["trackID"] = 1002,["x"] = 0,["y"] = 0},
}