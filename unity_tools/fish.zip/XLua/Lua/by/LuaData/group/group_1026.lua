group_1026 = {{["fishType"] = 11,["startFps"] = 1,["trackID"] = 1026,["x"] = 0,["y"] = 0},
{["fishType"] = 11,["startFps"] = 20,["trackID"] = 1027,["x"] = 0,["y"] = 0},
}