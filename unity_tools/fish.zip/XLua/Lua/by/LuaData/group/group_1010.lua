group_1010 = {{["fishType"] = 4,["startFps"] = 1,["trackID"] = 1010,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 25,["trackID"] = 1010,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 50,["trackID"] = 1010,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 75,["trackID"] = 1010,["x"] = 0,["y"] = 0},
}