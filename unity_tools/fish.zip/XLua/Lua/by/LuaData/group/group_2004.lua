group_2004 = {{["fishType"] = 5,["startFps"] = 1,["trackID"] = 2004,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 20,["trackID"] = 2004,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 40,["trackID"] = 2004,["x"] = 0,["y"] = 0},
}