group_1001 = {{["fishType"] = 1,["startFps"] = 1,["trackID"] = 1001,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 50,["trackID"] = 1001,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 100,["trackID"] = 1001,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 150,["trackID"] = 1001,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 200,["trackID"] = 1001,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 250,["trackID"] = 1001,["x"] = 0,["y"] = 0},
}