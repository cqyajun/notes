group_2017 = {{["fishType"] = 3,["startFps"] = 1,["trackID"] = 2017,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 25,["trackID"] = 2017,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 50,["trackID"] = 2017,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 75,["trackID"] = 2017,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 100,["trackID"] = 2017,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 125,["trackID"] = 2017,["x"] = 0,["y"] = 0},
}