group_1005 = {{["fishType"] = 1,["startFps"] = 1,["trackID"] = 1005,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 30,["trackID"] = 1005,["x"] = 0,["y"] = 0},
{["fishType"] = 36,["startFps"] = 60,["trackID"] = 1005,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 90,["trackID"] = 1005,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 120,["trackID"] = 1005,["x"] = 0,["y"] = 0},
{["fishType"] = 36,["startFps"] = 150,["trackID"] = 1005,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 180,["trackID"] = 1005,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 210,["trackID"] = 1005,["x"] = 0,["y"] = 0},
}