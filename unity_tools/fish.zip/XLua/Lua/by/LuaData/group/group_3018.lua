group_3018 = {{["fishType"] = 4,["startFps"] = 1,["trackID"] = 3018,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 20,["trackID"] = 3018,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 40,["trackID"] = 3018,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 60,["trackID"] = 3018,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 80,["trackID"] = 3018,["x"] = 0,["y"] = 0},
}