group_1022 = {{["fishType"] = 36,["startFps"] = 1,["trackID"] = 1017,["x"] = 0,["y"] = 0},
{["fishType"] = 36,["startFps"] = 50,["trackID"] = 1017,["x"] = 0,["y"] = 0},
{["fishType"] = 36,["startFps"] = 100,["trackID"] = 1017,["x"] = 0,["y"] = 0},
{["fishType"] = 36,["startFps"] = 150,["trackID"] = 1017,["x"] = 0,["y"] = 0},
}