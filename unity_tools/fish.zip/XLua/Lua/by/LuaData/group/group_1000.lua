group_1000 = {{["fishType"] = 2,["startFps"] = 1,["trackID"] = 1000,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 100,["trackID"] = 1000,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 200,["trackID"] = 1000,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 300,["trackID"] = 1000,["x"] = 0,["y"] = 0},
{["fishType"] = 2,["startFps"] = 400,["trackID"] = 1000,["x"] = 0,["y"] = 0},
}