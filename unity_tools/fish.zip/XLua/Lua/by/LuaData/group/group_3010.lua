group_3010 = {{["fishType"] = 1,["startFps"] = 1,["trackID"] = 3010,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 1,["trackID"] = 3010,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 20,["trackID"] = 3010,["x"] = 0,["y"] = 80},
{["fishType"] = 1,["startFps"] = 20,["trackID"] = 3010,["x"] = 0,["y"] = -10},
{["fishType"] = 1,["startFps"] = 40,["trackID"] = 3010,["x"] = 0,["y"] = 0},
}