group_1011 = {{["fishType"] = 1,["startFps"] = 1,["trackID"] = 1011,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 30,["trackID"] = 1011,["x"] = 0,["y"] = 80},
{["fishType"] = 1,["startFps"] = 30,["trackID"] = 1011,["x"] = 0,["y"] = -80},
{["fishType"] = 1,["startFps"] = 60,["trackID"] = 1011,["x"] = 0,["y"] = 0},
}