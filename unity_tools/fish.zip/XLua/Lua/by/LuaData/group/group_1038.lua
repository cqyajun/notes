group_1038 = {{["fishType"] = 14,["startFps"] = 1,["trackID"] = 1038,["x"] = 0,["y"] = 0},
{["fishType"] = 24,["startFps"] = 200,["trackID"] = 1004,["x"] = 0,["y"] = 0},
{["fishType"] = 25,["startFps"] = 200,["trackID"] = 1005,["x"] = 0,["y"] = 0},
{["fishType"] = 26,["startFps"] = 200,["trackID"] = 1009,["x"] = 0,["y"] = 0},
{["fishType"] = 27,["startFps"] = 200,["trackID"] = 1007,["x"] = 0,["y"] = 0},
{["fishType"] = 23,["startFps"] = 200,["trackID"] = 1001,["x"] = 0,["y"] = 0},
}