group_1021 = {{["fishType"] = 37,["startFps"] = 1,["trackID"] = 1009,["x"] = 0,["y"] = 0},
{["fishType"] = 37,["startFps"] = 50,["trackID"] = 1009,["x"] = 0,["y"] = 0},
{["fishType"] = 37,["startFps"] = 100,["trackID"] = 1009,["x"] = 0,["y"] = 0},
{["fishType"] = 37,["startFps"] = 150,["trackID"] = 1009,["x"] = 0,["y"] = 0},
}