group_2009 = {{["fishType"] = 37,["startFps"] = 1,["trackID"] = 2009,["x"] = 0,["y"] = 0},
{["fishType"] = 37,["startFps"] = 20,["trackID"] = 2009,["x"] = 0,["y"] = 0},
{["fishType"] = 37,["startFps"] = 20,["trackID"] = 2009,["x"] = 0,["y"] = -80},
{["fishType"] = 37,["startFps"] = 20,["trackID"] = 2009,["x"] = 0,["y"] = 80},
{["fishType"] = 37,["startFps"] = 40,["trackID"] = 2009,["x"] = 0,["y"] = 0},
}