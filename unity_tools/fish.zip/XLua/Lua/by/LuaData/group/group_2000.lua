group_2000 = {{["fishType"] = 1,["startFps"] = 1,["trackID"] = 2000,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 25,["trackID"] = 2000,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 50,["trackID"] = 2000,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 75,["trackID"] = 2000,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 100,["trackID"] = 2000,["x"] = 0,["y"] = 0},
}