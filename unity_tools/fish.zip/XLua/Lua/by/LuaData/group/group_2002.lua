group_2002 = {{["fishType"] = 3,["startFps"] = 1,["trackID"] = 2002,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 50,["trackID"] = 2002,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 100,["trackID"] = 2002,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 150,["trackID"] = 2002,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 200,["trackID"] = 2002,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 250,["trackID"] = 2002,["x"] = 0,["y"] = 0},
{["fishType"] = 3,["startFps"] = 300,["trackID"] = 2002,["x"] = 0,["y"] = 0},
}