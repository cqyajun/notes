group_1013 = {{["fishType"] = 1,["startFps"] = 1,["trackID"] = 1013,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 15,["trackID"] = 1013,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 30,["trackID"] = 1013,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 45,["trackID"] = 1013,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 60,["trackID"] = 1013,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 75,["trackID"] = 1013,["x"] = 0,["y"] = 0},
}