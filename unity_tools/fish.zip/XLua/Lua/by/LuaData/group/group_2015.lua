group_2015 = {{["fishType"] = 4,["startFps"] = 1,["trackID"] = 2015,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 20,["trackID"] = 2015,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 20,["trackID"] = 2015,["x"] = 0,["y"] = 100},
{["fishType"] = 4,["startFps"] = 20,["trackID"] = 2015,["x"] = 0,["y"] = -100},
{["fishType"] = 4,["startFps"] = 40,["trackID"] = 2015,["x"] = 0,["y"] = 0},
}