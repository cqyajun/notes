group_1014 = {{["fishType"] = 5,["startFps"] = 1,["trackID"] = 1014,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 20,["trackID"] = 1014,["x"] = 0,["y"] = 100},
{["fishType"] = 5,["startFps"] = 20,["trackID"] = 1014,["x"] = 0,["y"] = -100},
{["fishType"] = 5,["startFps"] = 20,["trackID"] = 1014,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 40,["trackID"] = 1014,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 60,["trackID"] = 1014,["x"] = 0,["y"] = 0},
}