group_3006 = {{["fishType"] = 5,["startFps"] = 1,["trackID"] = 3006,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 50,["trackID"] = 3006,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 100,["trackID"] = 3006,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 150,["trackID"] = 3006,["x"] = 0,["y"] = 0},
{["fishType"] = 5,["startFps"] = 200,["trackID"] = 3006,["x"] = 0,["y"] = 0},
}