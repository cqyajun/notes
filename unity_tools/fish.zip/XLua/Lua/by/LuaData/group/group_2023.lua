group_2023 = {{["fishType"] = 11,["startFps"] = 1,["trackID"] = 2023,["x"] = 0,["y"] = 0},
{["fishType"] = 11,["startFps"] = 100,["trackID"] = 2023,["x"] = 0,["y"] = 0},
{["fishType"] = 11,["startFps"] = 200,["trackID"] = 2023,["x"] = 0,["y"] = 0},
{["fishType"] = 11,["startFps"] = 300,["trackID"] = 2023,["x"] = 0,["y"] = 0},
{["fishType"] = 11,["startFps"] = 400,["trackID"] = 2023,["x"] = 0,["y"] = 0},
}