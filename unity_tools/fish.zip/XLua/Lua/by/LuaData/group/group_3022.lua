group_3022 = {{["fishType"] = 21,["startFps"] = 1,["trackID"] = 3022,["x"] = 0,["y"] = 0},
{["fishType"] = 21,["startFps"] = 400,["trackID"] = 3022,["x"] = 0,["y"] = 0},
}