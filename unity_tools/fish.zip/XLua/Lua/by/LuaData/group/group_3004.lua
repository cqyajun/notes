group_3004 = {{["fishType"] = 1,["startFps"] = 1,["trackID"] = 3004,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 50,["trackID"] = 3004,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 100,["trackID"] = 3004,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 150,["trackID"] = 3004,["x"] = 0,["y"] = 0},
{["fishType"] = 1,["startFps"] = 200,["trackID"] = 3004,["x"] = 0,["y"] = 0},
}