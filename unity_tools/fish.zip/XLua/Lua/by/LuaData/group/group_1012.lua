group_1012 = {{["fishType"] = 4,["startFps"] = 1,["trackID"] = 1012,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 15,["trackID"] = 1012,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 30,["trackID"] = 1012,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 45,["trackID"] = 1012,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 60,["trackID"] = 1012,["x"] = 0,["y"] = 0},
{["fishType"] = 4,["startFps"] = 75,["trackID"] = 1012,["x"] = 0,["y"] = 0},
}