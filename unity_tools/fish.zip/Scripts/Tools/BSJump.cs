﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BSJump : MonoBehaviour
{
    public Vector3 endPot;
    public Vector2 rangeMin;
    public Vector2 rangeMax;
    public float speed;
    // Use this for initialization
    void Start ()
    {
        endPot = new Vector3(Random.Range(this.transform.localPosition.x + rangeMin.x, this.transform.localPosition.x + rangeMax.x),
            Random.Range(this.transform.localPosition.y + rangeMin.y, this.transform.localPosition.y + rangeMax.y));
        StartCoroutine(Moving());
    }
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    public IEnumerator Moving()
    {
        while (this.transform.localPosition != endPot)
        {
            this.transform.localPosition = Vector3.MoveTowards(this.transform.localPosition, endPot, Time.deltaTime * speed);

            yield return 1;
        }
    }
}
