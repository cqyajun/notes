﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;

[LuaCallCSharp]
public class SendEvent : MonoBehaviour
{
    public float delay;
    public string luaName;
    public string eventID;
    public List<GameObject> objs = new List<GameObject>();
    // Use this for initialization
    void Start () {
        Invoke("SendEventCall", delay);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void SendEventCall()
    {
        if (LuaManager.Instance != null)
        {
            LuaManager.Instance.CallFunction("NormalEventCallBack", luaName, eventID, this);
        }
    }

}
