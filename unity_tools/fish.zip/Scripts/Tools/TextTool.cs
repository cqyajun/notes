﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextTool : MonoBehaviour
{
    public bool isEditor;
    public Font font;
    public Sprite[] sprites;
	// Use this for initialization
	public void Setting ()
    {
        CharacterInfo[] cis = new CharacterInfo[sprites.Length];
        for (int i = 0; i < sprites.Length; i++)
        {
            CharacterInfo ci = new CharacterInfo();
            ci.index = i;
            ci.uvBottomLeft = sprites[i].uv[3];
            ci.uvBottomRight = sprites[i].uv[2];
            ci.uvTopRight = sprites[i].uv[1];
            ci.uvTopLeft = sprites[i].uv[0];
            ci.minX = (int)sprites[i].rect.xMin;
            ci.maxX = (int)sprites[i].rect.xMax;
            ci.minY = (int)sprites[i].rect.yMax;
            ci.maxY = (int)sprites[i].rect.yMin;

            cis[i] = ci;
        }
        font.characterInfo = cis;



    }
	
	// Update is called once per frame
	void Update ()
    {
		
	}
}
