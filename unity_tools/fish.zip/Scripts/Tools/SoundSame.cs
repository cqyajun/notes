﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundSame : MonoBehaviour
{
    public AudioSource audioSource;
    public bool bgm;
    public bool sound;
	// Use this for initialization
	void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
		if(bgm)
        {
            audioSource.volume = SoundManager.Instance.GetBGMValue();
        }

        if(sound)
        {
            audioSource.volume = SoundManager.Instance.GetSoundValue();
        }
	}
}
