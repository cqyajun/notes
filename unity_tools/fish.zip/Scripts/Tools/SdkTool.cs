using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using XLua;


[LuaCallCSharp]
public class SdkTool : MonoBehaviour
{
    static AndroidJavaObject guardInstance = null;
    public static string luaIp = "";
    public static string luaPort = "";
    public static int ret = 0;
    public static bool initGameShieldSuccess = false;
    public static string iapResult = "";
    public static int AppId = 1000;
    public static int ChildAppId = 12;
#if UNITY_EDITOR
    public static bool useSdk = false;
#else
    public static bool useSdk = false;
#endif

#if UNITY_IOS
    /* Interface to native implementation */
    [DllImport("__Internal")]
    private static extern int GetIPortByDomain(string token, string groupname, string domain, string port);
    [DllImport("__Internal")]
    private static extern string GetIp();
    [DllImport("__Internal")]
    private static extern string GetPort();
    [DllImport("__Internal")]
    private static extern void goChat(string url, string szParams);
    [DllImport("__Internal")]
    private static extern int InitGameShield(string appkey, string token);
    [DllImport("__Internal")]
    private static extern void purchaseAction(string pid,int uid, string utoken, string url);
    [DllImport("__Internal")]
    private static extern string getLocalServerIAPActionInfo();
#endif

    // Use this for initialization
    void Start ()
    {

	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    //public static GameVersionInfo.GameShieldConfig initGSConfig() {
    //    GameVersionInfo.GameShieldConfig gsc = new GameVersionInfo.GameShieldConfig();
    //    return gsc;
    //}



    public static int initYXD(string appKey, string token){

#if UNITY_IOS
        ret = InitGameShield(appKey, token);
#else
        guardInstance = new AndroidJavaClass(Application.identifier + ".Guard").CallStatic<AndroidJavaObject>("getInstance");
        ret = guardInstance.Call<int>("initYXD",appKey,token);
#endif
        return ret;
    }

    public static void getDynamicIPByDomain(string groupName, string token, string szDomain, string szPort){
        Console.WriteLine("getDynamicIPByDomain.....");

#if UNITY_IOS
        GetIPortByDomain(token, groupName, szDomain, szPort);
#else

        guardInstance.Call("getDynamicIPByDomain",groupName,token,szDomain,szPort);
#endif
       
}
#if UNITY_IOS
    public static void IAPPurchaseCompleteion() {
        iapResult = getLocalServerIAPActionInfo();
        Console.WriteLine("iapresult is .................." + iapResult);
    }

    public static void IAPPurchaseAction(string pId,int userid, string utoken, string url) {
        Console.WriteLine("payurl is ..........." + url);
        purchaseAction(pId,userid,utoken,url);
    }
#endif
    public static void getDynamicIPByIP(string groupName, string token, string szIP, string szPort,int luaFunc){
        print("getDynamicIPByIP.......");
        guardInstance.Call("getDynamicIPByIP",groupName,token,szIP,szPort,luaFunc);
    }

    public static void reportData(int _type,string report_msg ,int bsync,int luaFunc){
        guardInstance.Call("reportData", _type,report_msg,bsync,luaFunc);
    }

    public static void getSession(int luaFunc){
        guardInstance.Call("getSession",luaFunc);
    }

    public static void getLocalInfo(int luaFunc){
        guardInstance.Call("getLocalInfo",luaFunc);
    }

    public static void getIp() {
#if UNITY_IOS
        luaIp = GetIp();
#else
        luaIp = guardInstance.Call<string>("getLuaip");
#endif
        //print("shield  getIp......."+luaIp);
        Console.WriteLine("shield  getIp......." + luaIp);
    }

    public static void getPort() {
#if UNITY_IOS
        luaPort = GetPort();
#else
        luaPort = guardInstance.Call<string>("getLuaport");
#endif

        //print("shield getPort......"+luaPort);
        Console.WriteLine("shield getPort......" + luaPort);
    }

    public static void showChatView(string url, string param){
#if UNITY_IOS
        goChat(url, param);
#else
        guardInstance.Call("showChatView", url,param);
#endif
        Console.WriteLine("QuickPay url.........."+url+"....QuickPay param........"+param);
    }

}