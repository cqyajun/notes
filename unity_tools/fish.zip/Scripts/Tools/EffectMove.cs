﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;

[LuaCallCSharp]
public class EffectMove : MonoBehaviour
{
    public bool sendEvent;
    public bool moveChild;
    public bool showBaoFu;
    public float delay;
    public float repeat = 0.02f;

    public float speed;
    public Vector3 target;
    public bool moveEndDestroy;
    public string luaName;
    public string eventID = "effect_move_end";
    public string eventMsg;
    public List<GameObject> objs = new List<GameObject>();
    int num = 0;

    // Use this for initialization
    void Start()
    {
        if(moveChild)
        {
            for(int i = 0;i<this.transform.childCount;i++)
            {
                num++;
                StartCoroutine(Move(delay + i * repeat, target, this.transform.GetChild(i).gameObject));
            }
        }
        else
        {
            num++;
            StartCoroutine(Move(delay, target, this.gameObject));
        }
    }

    // Update is called once per frame
    void Update()
    {

    }

    IEnumerator Move(float delay, Vector3 targetPos, GameObject obj)
    {
        yield return new WaitForSeconds(delay);
        while (obj.transform.position != targetPos)
        {
            obj.transform.position = Vector3.MoveTowards(obj.transform.position,
                targetPos, Time.deltaTime * speed);
            yield return 1;
        }
        num--;
        if (moveEndDestroy && num == 0)
        {
            GameObject.Destroy(this.gameObject);
        }
        if (num == 0)
        {
            if (sendEvent)
            {
                //GameEventManager.Instance.EventCallback(GameEventManager.EventType.Normal, eventID, this);
                if (LuaManager.Instance != null)
                {
                    LuaManager.Instance.CallFunction("NormalEventCallBack", luaName, eventID, this);
                }
            }
        }
    }
}
