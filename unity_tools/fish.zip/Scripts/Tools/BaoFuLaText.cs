﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using XLua;

[LuaCallCSharp]
public class BaoFuLaText : MonoBehaviour
{
    public List<Sprite> nums = new List<Sprite>();
    public List<Image> images = new List<Image>();
    public List<GameObject> panels = new List<GameObject>();
    // Use this for initialization
    void Start ()
    {
    }
	
	// Update is called once per frame
	void Update ()
    {
		
	}
    public void SetText(string str)
    {
        char[] cs = str.ToCharArray();
        int index = cs.Length - 1;
        int offset = (panels.Count - cs.Length) / 2;
        for (int i = 0; i < panels.Count; i++)
        {
            if(i >= offset && i < offset + cs.Length)
            {
                panels[i].SetActive(true);
                if(cs[index] == '.')
                {
                    images[i].sprite = nums[10];
                }
                else
                {
                    images[i].sprite = nums[int.Parse(cs[index].ToString())];
                }
                index--;
            }
            else
            {
                panels[i].SetActive(false);
            }
        }
    }
}
