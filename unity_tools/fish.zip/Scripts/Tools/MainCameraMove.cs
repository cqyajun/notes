﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainCameraMove : MonoBehaviour
{
    public string actName = "move";
	// Use this for initialization
	void Start ()
    {
        Camera.main.GetComponent<Animator>().SetBool(actName,true);
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}
}
