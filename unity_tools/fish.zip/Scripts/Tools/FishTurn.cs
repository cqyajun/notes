﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishTurn : MonoBehaviour {

    public List<Transform> changeTrans = new List<Transform>();
    public int state = 1;
    // Use this for initialization
    void Start () {
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (state == 1)
        {
            if (this.transform.localRotation.eulerAngles.z < 180 && changeTrans[0].localScale.x > 0)
            {
                //this.transform.localScale = new Vector3(-1, 1, 1);
                for (int i = 0; i < changeTrans.Count; i++)
                {
                    changeTrans[i].localScale = new Vector3(-changeTrans[i].localScale.x, changeTrans[i].localScale.y, changeTrans[i].localScale.z);
                }
            }
            else if (this.transform.localRotation.eulerAngles.z > 180 && changeTrans[0].localScale.x < 0)
            {
                //this.transform.localScale = new Vector3(1, 1, 1);
                for (int i = 0; i < changeTrans.Count; i++)
                {
                    changeTrans[i].localScale = new Vector3(-changeTrans[i].localScale.x, changeTrans[i].localScale.y, changeTrans[i].localScale.z);
                }
            }
        }
        else if(state == 2)
        {
            if (this.transform.localRotation.eulerAngles.z < 180 && changeTrans[0].localScale.x < 0)
            {
                //this.transform.localScale = new Vector3(-1, 1, 1);
                for (int i = 0; i < changeTrans.Count; i++)
                {
                    changeTrans[i].localScale = new Vector3(-changeTrans[i].localScale.x, changeTrans[i].localScale.y, changeTrans[i].localScale.z);
                }
            }
            else if (this.transform.localRotation.eulerAngles.z > 180 && changeTrans[0].localScale.x > 0)
            {
                //this.transform.localScale = new Vector3(1, 1, 1);
                for (int i = 0; i < changeTrans.Count; i++)
                {
                    changeTrans[i].localScale = new Vector3(-changeTrans[i].localScale.x, changeTrans[i].localScale.y, changeTrans[i].localScale.z);
                }
            }
        }
    }
}
