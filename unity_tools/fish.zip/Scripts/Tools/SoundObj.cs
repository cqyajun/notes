﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundObj : MonoBehaviour
{
    public string soundName;
    public string groupName;
	// Use this for initialization
	void Start () {
        SoundManager.Instance.PlaySound(soundName, groupName);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
