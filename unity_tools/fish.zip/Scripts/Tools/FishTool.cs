﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishTool : MonoBehaviour
{

    public BezierCurve bc;
    public Vector3 offset;
    public int delayTime;
    public int curFps;
    SpriteRenderer sr;
    // Use this for initialization
    void Start () {
        this.transform.position = bc.pots[0];
        sr = this.gameObject.GetComponent<SpriteRenderer>();
        if(sr == null)
        {
            sr = this.transform.Find("body").GetComponent<SpriteRenderer>();
        }
        sr.enabled = false;
        //delayTime = Random.Range(0,500);
        //offset = Vector3.zero;//new Vector3(Random.Range(0, 100), Random.Range(0, 100), 0);
    }
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    private void FixedUpdate()
    {
        if (curFps - delayTime < bc.pots.Count)
        {
            Moving(curFps);
            curFps++;
        }
    }

    public void Moving(int index)
    {
        if (delayTime <= index && bc.pots.Count > index - delayTime)
        {
            sr.enabled = true;
            index = index - delayTime;
            this.transform.position = bc.pots[index] + offset;
            if (index + 1 < bc.pots.Count && bc.pots[index] != bc.pots[index + 1])
            {
                this.transform.localRotation = Quaternion.Euler(0, 0, bc.rotesZ[index]);
            }
        }
    }
}
