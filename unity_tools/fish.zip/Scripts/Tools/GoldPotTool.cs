﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoldPotTool : MonoBehaviour
{
    public bool isEditor;
    public List<Transform> golds = new List<Transform>();
	// Use this for initialization
	void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

}
