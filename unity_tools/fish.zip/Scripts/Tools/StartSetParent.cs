﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartSetParent : MonoBehaviour
{
    public Transform pr;
	// Use this for initialization
	void Start ()
    {
        this.transform.SetParent(pr);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
