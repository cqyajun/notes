﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoomMove : MonoBehaviour {
    [System.NonSerialized]
    public Vector2 min;
    [System.NonSerialized]
    public Vector2 max;

    public float speed;
    public float time;

    float curTime = 0;

    // Use this for initialization
    void Start () {
        float cameraHeight = Camera.main.orthographicSize * 2;
        Vector2 cameraSize = new Vector2(Camera.main.aspect * cameraHeight, cameraHeight);
        Vector3 offset = new Vector3(cameraSize.x / 2f, -cameraSize.y / 2f) - Camera.main.transform.localPosition;
        min.y = -cameraSize.y;
        min.x -= offset.x;
        max.x = cameraSize.x - offset.x;
        this.transform.up = new Vector3(Random.Range(300, 1000), Random.Range(-620, -100), this.transform.position.z) - this.transform.position;
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    void FixedUpdate()
    {
        if (FishingManager.Instance.isOver)
        {
            return;
        }
        if (speed > 0)
        {
            if(time > 0)
            {
                curTime += Time.deltaTime;
                if(curTime > time)
                {
                    return;
                }
            }
            this.transform.position = this.transform.position + this.transform.up * speed;
            CheckRect();
        }
    }


    void CheckRect()
    {
        if (this.transform.position.x < min.x)
        {
            this.transform.position = new Vector3(min.x + (min.x - this.transform.position.x), this.transform.position.y);
            float dot = Vector3.Dot(this.transform.up, Vector3.up);
            float angle = Vector3.Angle(this.transform.up, Vector3.up);
            this.transform.Rotate(0, 0, -angle * 2);
        }
        else if (this.transform.position.x > max.x)
        {
            this.transform.position = new Vector3(max.x - (this.transform.position.x - max.x), this.transform.position.y);
            float dot = Vector3.Dot(this.transform.up, Vector3.up);
            float angle = Vector3.Angle(this.transform.up, Vector3.up);
            this.transform.Rotate(0, 0, angle * 2);
        }
        else if (this.transform.position.y < min.y)
        {
            this.transform.position = new Vector3(this.transform.position.x, min.y + (min.y - this.transform.position.y));
            float dot = Vector3.Dot(this.transform.up, Vector3.right);
            float angle = Vector3.Angle(this.transform.up, Vector3.right);
            this.transform.Rotate(0, 0, angle * 2);
        }
        else if (this.transform.position.y > max.y)
        {
            this.transform.position = new Vector3(this.transform.position.x, max.y - (this.transform.position.y - max.y));
            float dot = Vector3.Dot(this.transform.up, Vector3.right);
            float angle = Vector3.Angle(this.transform.up, Vector3.right);
            this.transform.Rotate(0, 0, -angle * 2);
        }
    }
}
