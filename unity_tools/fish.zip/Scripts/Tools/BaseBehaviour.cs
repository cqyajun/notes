﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using XLua;

[LuaCallCSharp]
public class BaseBehaviour : MonoBehaviour
{
    public List<Image> images = new List<Image>();
    public List<AnimationClip> animationClips = new List<AnimationClip>();
    public List<SpriteRenderer> spriteRenderers = new List<SpriteRenderer>();

    public virtual void OnDestroy()
    {
        for (int i = 0; i < animationClips.Count; i++)
        {
            if (animationClips[i] != null)
            {
                Resources.UnloadAsset(animationClips[i]);
            }
        }

        for (int i = 0; i < images.Count; i++)
        {
            if (images[i] != null)
            {
                Resources.UnloadAsset(images[i].sprite);
            }
        }
        
        for (int i = 0; i < spriteRenderers.Count; i++)
        {
            if (spriteRenderers[i] != null)
            {
                Resources.UnloadAsset(spriteRenderers[i].sprite);
            }
        }
        Resources.UnloadUnusedAssets();
    }
}
