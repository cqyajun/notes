﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;
using System.IO;
using UnityEngine.Networking;
using System.Collections.Generic;
using System.Text;

/// <summary>
/// Debug测试。
/// 将Debug写入到本地硬件
/// 这里使用的是Unity5.3.3版本
/// </summary>
public class LoggerMono : MonoBehaviour
{
    public int count = 5;
    private string m_txt;
    public bool log;
    public bool warning;
    public bool error;
    public bool isSendLog;
    public bool isShow;

    void Awake()
    {
        DontDestroyOnLoad(this.gameObject);
        Application.logMessageReceived += OnLogCallBack;
    }

    private void OnLogCallBack(string condition, string stackTrace, LogType type)
    {
        string logStr = string.Empty;
        switch (type)
        {
            case LogType.Log:
                {
                    if (log)
                    {
                        logStr = string.Format("{0}：{1}\n", type, condition);
                    }
                }
                break;
            case LogType.Warning:
                {
                    if (warning)
                    {
                        logStr = string.Format("{0}：{1}\n", type, condition);
                    }
                }
                break;
            case LogType.Assert:
            case LogType.Exception:
            case LogType.Error:
                {
                    if (error)
                    {
                        if(count > 0)
                        {
                            count--;
                        }
                        else
                        {
                            return;
                        }
                        if (string.IsNullOrEmpty(stackTrace))
                        {
                            /// 发布到对应平台后，调用堆栈获取不到。使用 Environment.StackTrace 获取调用堆栈
                            logStr = System.DateTime.Now + " " + string.Format("{0}：{1}\n{2}", type, condition, Environment.StackTrace);
                            Debug.Log(logStr);
                        }
                        else
                        {
                            logStr = System.DateTime.Now + " " + string.Format("{0}：{1}\n{2}", type, condition, stackTrace);
                            Debug.Log(logStr);
                        }
                       
                    }
                }
                break;
        }

        if (logStr != string.Empty)
        {
            if (isSendLog)
            {
                StartCoroutine(SendLog(logStr));
            }
            if (isShow)
            {
                logStr += "\n";
                m_txt += logStr;
            }
        }
       
    }

    private void OnGUI()
    {
        if (isShow)
        {
            GUI.Label(new Rect(50, 0, 1000, 1000), m_txt);
        }
    }

    void Update()
    {
        //if(Input.GetKeyUp(KeyCode.S))
        //{
        //    GameObject go = UIManager.Instance.ShowUI("log_view");
        //    logText = go.transform.GetChild(0).GetChild(0).GetChild(0).GetComponent<Text>();
        //    logText.text = m_txt;
        //}

        //if (Input.GetKeyUp(KeyCode.D))
        //{
        //    UIManager.Instance.DelUI("log_view");
        //    logText = null;
        //}

        //if(Input.GetKeyUp(KeyCode.F))
        //{
        //    Debug.LogError("123456");
        //}
    }

    public IEnumerator SendLog(string log)
    {
        yield return 0;
        WWWForm form = new WWWForm();
        form.AddField("canal", GameMaster.Instance.cid);
        form.AddField("appVersion", "test_version_1_0");
        form.AddField("userId", "");
        form.AddField("content", log);
        form.AddField("platform", GameMaster.Instance.dtype);
        yield return StartCoroutine(NetworkManager.Instance.Upload(
            GameMaster.Instance.tab.GetInPath<string>("obj.appConfig.debug_url") + "gamelog/add", form,
            (str) => {
                //Debug.LogError(str);
                
            },
            (bytes) => {

            },
            (error) => {
                Debug.Log("upload log error!!!");
            }));
    }
}