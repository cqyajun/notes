﻿using UnityEngine;

public class SpriteText : MonoBehaviour
{
    public int layerID;
    public int order;
    void Start()
    {
        var renderer = GetComponent<Renderer>();
        renderer.sortingLayerID = layerID;
        renderer.sortingOrder = order;
    }
}