using UnityEngine;
using XLua;
using System.Collections.Generic;
using System.Collections;
using System;

[LuaCallCSharp]
public class Coroutine_Runner : MonoBehaviour
{
    static Coroutine_Runner instance;
    public static Coroutine_Runner Instance
    {
        get { return instance; }
    }

    void Awake()
    {
        instance = this;
    }

    public void YieldAndCallback(object to_yield, Action callback)
    {
        StartCoroutine(CoBody(to_yield, callback));
    }

    private IEnumerator CoBody(object to_yield, Action callback)
    {
        if (to_yield is IEnumerator)
            yield return StartCoroutine((IEnumerator)to_yield);
        else
            yield return to_yield;
        callback();
    }

    Dictionary<string, List<Coroutine>> signCoroutineDict = new Dictionary<string, List<Coroutine>>();

    public void YieldAndCallback(string sign, object to_yield, Action callback)
    {
        Coroutine cor = StartCoroutine(CoBody(to_yield, callback));

        if (!signCoroutineDict.ContainsKey(sign))
            signCoroutineDict.Add(sign, new List<Coroutine>());

        signCoroutineDict[sign].Add(cor);
    }

    public void StopAllCoroutines(string sign)
    {
        foreach (var item in signCoroutineDict)
        {
            if (item.Key == sign && item.Value != null)
            {
                foreach (var cor in signCoroutineDict[sign])
                    StopCoroutine(cor);

                Debug.Log("�ɹ�ͣ��" + sign + "��Э��");
                signCoroutineDict[sign].Clear();
            }
        }
    }

    public void BreakCoroutine(object to_yield, Action callback)
    {
        Coroutine cor = StartCoroutine(CoBody(to_yield, callback));
        StopCoroutine(cor);
    }

}


public static class CoroutineConfig
{
    [LuaCallCSharp]
    public static List<Type> LuaCallCSharp
    {
        get
        {
            return new List<Type>()
            {
                typeof(WaitForSeconds),
                typeof(WWW)
            };
        }
    }
}
