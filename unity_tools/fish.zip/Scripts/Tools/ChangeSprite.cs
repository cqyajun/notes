﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;

[LuaCallCSharp]
public class ChangeSprite : MonoBehaviour
{
    public SpriteRenderer spriteRenderer;
    public int curIndex;
    public int jumpIndex;
    public int curJump;
    public List<Sprite> sprites = new List<Sprite>();
   
	// Use this for initialization
	void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    public void ChangeNext()
    {
        if (curJump >= jumpIndex)
        {
            curJump = 0;
            curIndex++;
            if (curIndex >= sprites.Count)
            {
                curIndex = 0;
            }
            spriteRenderer.sprite = sprites[curIndex];
        }
        curJump++;
    }
}
