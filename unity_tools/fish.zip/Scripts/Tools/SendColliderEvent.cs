﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SendColliderEvent : MonoBehaviour
{
    public bool sendToSelf;
    public bool sendToParent;
    public bool sendToChild;
    public string methodName;
    void OnTriggerEnter2D(Collider2D other)
    {
        if (methodName != "")
        {
            if (sendToSelf)
            {
                SendMessage(methodName, other);
            }
            if (sendToParent)
            {
                SendMessageUpwards(methodName, other);
            }
            if (sendToChild)
            {
                BroadcastMessage(methodName, other);
            }
        }
    }
}
