﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;

[LuaCallCSharp]
public class DragonPot : MonoBehaviour
{
    public bool save = true;
    public bool run = true;
    public int delay = 0;
    public int time = 0;
    public float speed = 100;
    public float fps = 0.0000f;
    public int startFPS;
    public int totalFPS;
    public int curFPS;
    public int timeRange;
    public float curTime;
    public int spIndex;
    public Vector3 savePot;
    public Transform root;
    public SpriteRenderer sr;
    public List<Vector3> pots = new List<Vector3>();
    public List<Sprite> sps = new List<Sprite>();
    
    // Use this for initialization
    void Start ()
    {
        InvokeRepeating("Running", delay, 1f/ fps);
	}
	
	// Update is called once per frame
	void Update ()
    {
        
    }

    public void SetTime()
    {
        time = ((curFPS - startFPS) % timeRange) * pots.Count / timeRange;
        Debug.LogError(time);
    }


    public void Running()
    {
        if(Vector3.Distance(savePot, root.position) > 50)
        {
            time = 0;
        }

        if (run && time < pots.Count)
        {
            this.transform.localPosition = pots[time];
            sr.sprite = sps[spIndex];
            time++;
            spIndex++;
            if (spIndex >= sps.Count)
            {
                spIndex = 0;
            }
            if (time >= pots.Count)
            {
                time = 0;
            }
        }

        savePot = root.position;
    }

    private void FixedUpdate()
    {
        
    }
}
