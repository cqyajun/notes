﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;

[LuaCallCSharp]
public class HideObj : MonoBehaviour
{
    public GameObject obj;
    public float delay;
	// Use this for initialization
	void OnEnable ()
    {
        Invoke("HObj", delay);
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    public void HObj()
    {
        obj.SetActive(false);
    }
}
