﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShowObj : MonoBehaviour
{
    public float delay;
    public GameObject[] objs;
    public bool isChildren;
    // Use this for initialization
    void Start()
    {
        Invoke("Show", delay);
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void Show()
    {
        if (isChildren)
        {
            for (int i = 0; i < this.transform.childCount; i++)
            {
                this.transform.GetChild(i).gameObject.SetActive(true);
            }
        }
        else
        {
            for (int i = 0; i < objs.Length; i++)
            {
                objs[i].SetActive(true);
            }
        }
    }

    public void Hide()
    {
        if (isChildren)
        {
            for (int i = 0; i < this.transform.childCount; i++)
            {
                this.transform.GetChild(i).gameObject.SetActive(false);
            }
        }
        else
        {
            for (int i = 0; i < objs.Length; i++)
            {
                objs[i].SetActive(false);
            }
        }
    }

}
