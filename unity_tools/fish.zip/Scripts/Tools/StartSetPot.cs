﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartSetPot : MonoBehaviour
{
    public Transform target;
	// Use this for initialization
	void Start () {
        this.transform.position = target.position;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
