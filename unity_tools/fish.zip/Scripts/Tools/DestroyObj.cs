﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;

[LuaCallCSharp]
public class DestroyObj : MonoBehaviour
{
    public GameObject obj;
    public float delay;
	// Use this for initialization
	void Start ()
    {
        Invoke("DesObj", delay);
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    public void DesObj()
    {
        GameObject.Destroy(obj);
    }
}
