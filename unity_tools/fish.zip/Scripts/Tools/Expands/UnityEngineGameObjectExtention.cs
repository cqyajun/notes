﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using XLua;

/**
 * 
 * 扩展一些简便的GameObject工具,主要提供给Lua使用.
 * 
 * 
 * 
 * */
[LuaCallCSharp]
public static class UnityEngineGameObjectExtention {

    /**
     * 对Button增加Click事件,并移除之前添加的事件
     * 
     * @param obj 挂载Button 的 GameObject
     * @param call UnityAction
     * 
     * */
    public static void AddButtonClickEvent(this GameObject obj, UnityAction call) {
        Button btn = obj.GetComponent<Button>();
        btn.onClick.RemoveAllListeners();
        btn.onClick.AddListener(call);
    }

    public static void AddToggleValueEvent(this GameObject obj, UnityAction<bool> call) {
        Toggle tog = obj.GetComponent<Toggle>();
        tog.onValueChanged.RemoveAllListeners();
        tog.onValueChanged.AddListener(call);
    }

    public static void destoryAllChildren(this GameObject obj) {
        foreach (Transform child in obj.transform) {
            GameObject.Destroy(child.gameObject);
        }
    }
}