﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CopyTool : MonoBehaviour
{
    public InputField inputField;
#if UNITY_IPHONE
    /* Interface to native implementation */
    //[DllImport ("__Internal")]
    //private static extern void _copyTextToClipboard(string text);
#endif
    // Use this for initialization
    void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    public void CopyClick()
    {
//#if UNITY_ANDROID
//        // Get the Main Plugin activity class
//        AndroidJavaClass actClass = new AndroidJavaClass("com.xxx.xxx.PluginActivity");

//        // Get a reference to an instance of the PluginActivity
//        AndroidJavaObject pluginActivity = actClass.CallStatic<AndroidJavaObject>("getInstance");

//        pluginActivity.Call("CopyTextToClipboard", input);

//#elif UNITY_IPHONE
//        _copyTextToClipboard(input);
//#elif UNITY_EDITOR
//        TextEditor t = new TextEditor();
//        t.text = inputField.text;
//        t.OnFocus();
//        t.Copy();
//#endif
    }
}
