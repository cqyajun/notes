﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class SwatchMsg
{
    public int fishType;  //如果=100说明是鱼群
    public int startFps;
    public int trackOrGroup;
}


public class Swatch : MonoBehaviour
{
    public int delay;
    string fishPath = "by/Prefabs/fishs/";
    string trackPath = "data/track/";
    string groupPath = "data/group/";
    public bool isRandom;
    public int groupNum;
    public int fishNum;
    public bool setGroupIDs;
    public Vector3 timeGroupIDs;
    public List<int> groupIDs = new List<int>();

    public bool setfishIDs;
    public Vector3 timefishIDs;
    public List<int> trackIDs = new List<int>();
    public List<int> fishIDs = new List<int>();

    public bool changeFish;
    public Vector2 fishChangID;

    public List<SwatchMsg> swatchs = new List<SwatchMsg>();
    public Dictionary<int, GameObject> tracks = new Dictionary<int, GameObject>();
    // Use this for initialization
    void Start ()
    {
        FishDataSaver.Instance.fileName = this.gameObject.name;
        for (int i = 0; i < swatchs.Count; i++)
        {
            if(swatchs[i].fishType == 100)
            {
                GameObject go = Resources.Load(groupPath + "group_" + swatchs[i].trackOrGroup) as GameObject;
                if (go == null)
                {
                    Debug.LogError(swatchs[i].trackOrGroup);
                }

                go = GameObject.Instantiate(go, this.transform);
                go.GetComponent<Group>().delay = swatchs[i].startFps;
            }
            else
            {
                if (!tracks.ContainsKey(swatchs[i].trackOrGroup))
                {
                    GameObject go = Resources.Load(trackPath + "track_" + swatchs[i].trackOrGroup) as GameObject;
                    go = GameObject.Instantiate(go, GameObject.Find("bg").transform);
                    if (go != null)
                    {
                        tracks[swatchs[i].trackOrGroup] = go;
                    }
                }
                GameObject fishObj = Resources.Load(fishPath + "fish_" + swatchs[i].fishType) as GameObject;
                FishDataSaver.Instance.fishs[swatchs[i].fishType]++;
                fishObj = GameObject.Instantiate(fishObj);
                FishTool fishTool = fishObj.AddComponent<FishTool>();
                fishTool.delayTime = swatchs[i].startFps;
                fishTool.offset = Vector3.zero;
                fishTool.bc = tracks[swatchs[i].trackOrGroup].GetComponent<BezierCurve>();
            }
        }
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    void FixedUpdate()
    {
        
    }

    public string MakeLuaData(string dataName)
    {
        Sort();
        string val = dataName + " = {\n";
        for (int i = 0; i < swatchs.Count; i++)
        {
            if(swatchs[i].startFps == 0)
            {
                swatchs[i].startFps = 1;
            }
            val += "{[\"fishID\"] = " + swatchs[i].fishType + ",[\"startFps\"] = " + (swatchs[i].startFps + delay) + ",[\"trackOrGroup\"] = " + swatchs[i].trackOrGroup + "},\n";
        }
        val += "}";
        return val;
    }


    public string MakeTextData(string dataName)
    {
        Sort();
        string val = "";
        for (int i = 0; i < swatchs.Count; i++)
        {
            if (swatchs[i].startFps == 0)
            {
                swatchs[i].startFps = 1;
            }
            val += "(" + swatchs[i].fishType + "," + (swatchs[i].startFps + delay) + "," + swatchs[i].trackOrGroup + ",0,0,0,0,0.000000,0.000000)\n";
        }
       
        return val;
    }

    public void Sort()
    {
        for (int i = 0; i < swatchs.Count; i++)
        {
            for (int j = i + 1; j < swatchs.Count; j++)
            {
                if (swatchs[i].startFps > swatchs[j].startFps)
                {
                    SwatchMsg msg = new SwatchMsg();
                    msg.fishType = swatchs[i].fishType;
                    msg.startFps = swatchs[i].startFps;
                    msg.trackOrGroup = swatchs[i].trackOrGroup;
                    swatchs[i] = swatchs[j];
                    swatchs[j] = msg;
                }
            }
        }
    }
}
