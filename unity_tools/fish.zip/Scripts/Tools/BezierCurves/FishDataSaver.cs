﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishDataSaver : MonoBehaviour
{
    static FishDataSaver instance;
    public static FishDataSaver Instance
    {
        get
        {
            return instance;
        }
    }

    public int[] fishs = new int[40];
    public string fileName;
    // Use this for initialization
    private void Awake()
    {
        fishs = new int[40];
        instance = this;
    }
    void Start ()
    {
        

    }
	
	// Update is called once per frame
	void Update ()
    {
		if(Input.GetKeyUp(KeyCode.T))
        {
            string str = "";
            for (int i = 1; i < 40; i++)
            {
                str += "fishID = " + i + " count = " + fishs[i] + "\n";
            }
            using (var s = System.IO.File.Create("Assets/Scenes/Tools/" + fileName + ".txt"))
            {
                byte[] data = System.Text.Encoding.UTF8.GetBytes(str);
                s.Write(data, 0, data.Length);
            }
        }
	}
}
