﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class LineMsg
{
    public int groupID;
    public int startFps;
}


public class Line : MonoBehaviour
{
    public string groupPath = "data/group/";
    public Vector2 time;
    public List<LineMsg> lines = new List<LineMsg>();
 
	// Use this for initialization
	void Start ()
    {
        for (int i = 0; i < lines.Count; i++)
        {
            GameObject go = Resources.Load(groupPath + "group_" + lines[i].groupID) as GameObject;
            go = GameObject.Instantiate(go, this.transform);
            go.GetComponent<Group>().delay = lines[i].startFps;
        }
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    void FixedUpdate()
    {
        
    }

    public string MakeLuaData(string dataName)
    {
        Sort();
        if (time.x == 0)
        {
            time.x = 1;
        }
        string val = dataName + " = {{[\"startTime\"] = " + time.x + ",[\"endTime\"] = " + time.y + "},\n";
        for (int i = 0; i < lines.Count; i++)
        {
            if(lines[i].startFps == 0)
            {
                lines[i].startFps = 1;
            }
            val += "{[\"groupID\"] = " + lines[i].groupID + ",[\"startFps\"] = " + lines[i].startFps + "},\n";
        }
        val += "}";
        return val;
    }

    public string MakeTextData(string dataName)
    {
        Sort();
        if (time.x == 0)
        {
            time.x = 1;
        }
        string val = "{" + time.x + "-" + time.y + "}\n";
        for (int i = 0; i < lines.Count; i++)
        {
            if (lines[i].startFps == 0)
            {
                lines[i].startFps = 1;
            }
            val += "(" + lines[i].groupID + "," + lines[i].startFps + ")\n";
        }
        
        return val;
    }

    public void Sort()
    {
        for (int i = 0; i < lines.Count; i++)
        {
            for (int j = i + 1; j < lines.Count; j++)
            {
                if (lines[i].startFps > lines[j].startFps)
                {
                    LineMsg msg = new LineMsg();
                    msg.groupID = lines[i].groupID;
                    msg.startFps = lines[i].startFps;
                    lines[i] = lines[j];
                    lines[j] = msg;
                }
            }
        }
    }
}
