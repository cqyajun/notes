﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class GroupMsg
{
    public int fishType;
    public int startFps;
    public int trackID;
    public Vector2 offset;
}


public class Group : MonoBehaviour
{
    
    string fishPath = "by/Prefabs/fishs/";
    string trackPath = "data/track/";
    public int delay;
    public bool isInsert;
    public int insertIndex;
    public bool isRemove;
    public int removeIndex;
    public bool isChangeFishType;
    public string fishType;
    public bool setStartFps;
    public int startFPS;
    public int distance;
    public bool isChangeTrackID;
    public int trackID;
    
    public List<GroupMsg> groupMsgs = new List<GroupMsg>();
    public Dictionary<int, GameObject> tracks = new Dictionary<int, GameObject>();
    // Use this for initialization
    void Start ()
    {
        for (int i = 0; i < groupMsgs.Count; i++)
        {
            if(!tracks.ContainsKey(groupMsgs[i].trackID))
            {
                GameObject go = Resources.Load(trackPath + "track_" + groupMsgs[i].trackID) as GameObject;
                if (go == null)
                {
                    Debug.LogError(groupMsgs[i].trackID);
                }
                else
                {
                    go = GameObject.Instantiate(go, GameObject.Find("bg").transform);
                    if (go != null)
                    {
                        tracks[groupMsgs[i].trackID] = go;
                    }
                }
            }
            GameObject fishObj = Resources.Load(fishPath + "fish_" + groupMsgs[i].fishType) as GameObject;
            FishDataSaver.Instance.fishs[groupMsgs[i].fishType]++;
            fishObj = GameObject.Instantiate(fishObj);
            FishTool fishTool = fishObj.AddComponent<FishTool>();
            fishTool.delayTime = delay + groupMsgs[i].startFps;
            fishTool.offset = groupMsgs[i].offset;
            fishTool.bc = tracks[groupMsgs[i].trackID].GetComponent<BezierCurve>();
            //fishTool.bc = (BezierCurve)Resources.Load(trackPath + "track_" + groupMsgs[i].trackID, typeof(BezierCurve));
        }
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    public string MakeLuaData(string dataName)
    {
        Sort();
        string val = dataName + " = {";
        for (int i = 0; i < groupMsgs.Count; i++)
        {
            if(groupMsgs[i].startFps == 0)
            {
                groupMsgs[i].startFps = 1;
            }
            val += "{[\"fishType\"] = " + groupMsgs[i].fishType + ",[\"startFps\"] = " + groupMsgs[i].startFps + ",[\"trackID\"] = " + groupMsgs[i].trackID + ",[\"x\"] = " + groupMsgs[i].offset.x + ",[\"y\"] = " + groupMsgs[i].offset.y + "},\n";
        }
        val += "}";
        return val;
    }

    public string MakeTextData(string dataName)
    {
        Sort();
        string val = "1\n";
        for (int i = 0; i < groupMsgs.Count; i++)
        {
            if (groupMsgs[i].startFps == 0)
            {
                groupMsgs[i].startFps = 1;
            }
            val += "(1," + groupMsgs[i].fishType + "," + groupMsgs[i].startFps + "," + groupMsgs[i].trackID + "," + groupMsgs[i].offset.x + "," + groupMsgs[i].offset.y + ")\n";
        }
        
        return val;
    }


    public void Sort()
    {
        for (int i = 0; i < groupMsgs.Count; i++)
        {
            for (int j = i + 1; j < groupMsgs.Count; j++)
            {
                if (groupMsgs[i].startFps > groupMsgs[j].startFps)
                {
                    GroupMsg msg = new GroupMsg();
                    msg.fishType = groupMsgs[i].fishType;
                    msg.startFps = groupMsgs[i].startFps;
                    msg.offset = groupMsgs[i].offset;
                    msg.trackID = groupMsgs[i].trackID;
                    groupMsgs[i] = groupMsgs[j];
                    groupMsgs[j] = msg;
                }
            }
        }
    }
}
