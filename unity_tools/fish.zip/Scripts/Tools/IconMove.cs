﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IconMove : MonoBehaviour
{
    public Vector3 startPot;
    public Vector3 endPot;
    public float speed;
	// Use this for initialization
	void Start ()
    {
        StartCoroutine(Moving());
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    public IEnumerator Moving()
    {
        this.transform.localPosition = startPot;
        while (this.transform.localPosition != endPot)
        {
            this.transform.localPosition = Vector3.MoveTowards(this.transform.localPosition, endPot, Time.deltaTime * speed);

            yield return 1;
        }
    }
}
