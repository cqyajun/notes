﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Shadow : MonoBehaviour
{
    public Transform fish;
    public Transform root;
    public Renderer render;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (FishingManager.Instance.closeShadow)
        {
            render.enabled = false;
        }
        else
        {
            if(!render.enabled)
            {
                render.enabled = true;
            }
            try
            {
                this.transform.localRotation = fish.localRotation;
                root.localEulerAngles = -fish.localRotation.eulerAngles;
            }
            catch
            {
                Debug.LogError(this.transform.parent.parent.name);
            }
        }
    }
}
