﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;

public class WWWGetTexture : MonoBehaviour {
    Texture2D texture2D;         //下载的图片
    public Transform m_tSprite;  //场景中的一个Sprite
    string filePath;             //保存的文件路径

    void Start () {
        filePath = StaticData.resPath + "/qrCode.jpg";
        StartCoroutine(LoadImg());
        //Debug.LogError(StaticData.resPath);

    }

    IEnumerator LoadImg()
    {
        //开始下载图片
        if (!File.Exists(filePath))
        {
            //Debug.LogError("下载");
            WWW www = new WWW("https://www.qizhihulian.com/util/qrcode?ctn=http://www.baidu.com&wh=300");
            yield return www;

            texture2D = www.texture;

            byte[] bytes = texture2D.EncodeToPNG();
            File.WriteAllBytes(filePath, bytes);
        }else
        {
            //Debug.LogError("本地读取");
            WWW www = new WWW(filePath);
            yield return www;

            texture2D = www.texture;
        }
        //将图片赋给场景上的Sprite
        Sprite tempSp = Sprite.Create(texture2D, new Rect(0, 0, texture2D.width, texture2D.height), new Vector2(0, 0));
        m_tSprite.GetComponent<Image>().sprite = tempSp;
        //Debug.Log("加载完成");
    }
}
