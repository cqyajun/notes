﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShowCurrectFPS : MonoBehaviour
{
    int i = 0;
	// Use this for initialization
	void Start ()
    {
		
	}

    private void OnGUI()
    {
        GUI.Label(new Rect(0, 0, 1000, 500), i.ToString());
    }
    // Update is called once per frame
    void Update ()
    {
		
	}

    private void FixedUpdate()
    {
        i++;
    }
}
