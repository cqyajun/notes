﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using XLua;

[LuaCallCSharp]
public class MessageBox : MonoBehaviour
{
    private static MessageBox instance = null;
    public static MessageBox Instance
    {
        get
        {
            if(instance == null)
            {
                GameObject go = Resources.Load("public/Prefabs/uis/message_box") as GameObject;
                go = GameObject.Instantiate(go);
                instance = go.GetComponent<MessageBox>();
            }
            return instance;
        }
    }
    public Text titleText;
    public Text msgText;
    public Button okBtn;
    public Text okText;
    public Button cancelBtn;
    public Text cancelText;
    public Action okCallBack;
    public Action cancelBack;
    // Use this for initialization

    public void Init(string title, string msg,
        string ok_text = null, Action OKCallBack = null,
        string cancel_text = null, Action CancelCallBack = null)
    {
        titleText.text = title;
        msgText.text = msg;
        if (ok_text != null)
        {
            if(ok_text != "确认")
            {
                okText.text = ok_text;
            }
            okCallBack = OKCallBack;
        }
        if (cancel_text != null)
        {
            if (cancel_text != "取消")
            {
                cancelText.text = cancel_text;
            }
            cancelBack = CancelCallBack;
        }

        if(ok_text != null && cancel_text == null)
        {
            okBtn.transform.localPosition = new Vector3(0, okBtn.transform.localPosition.y);
            cancelBtn.gameObject.SetActive(false);
        }
        else if(ok_text == null && cancel_text != null)
        {
            cancelBtn.transform.localPosition = new Vector3(0, cancelBtn.transform.localPosition.y);
            okBtn.gameObject.SetActive(false);
        }
        else if(ok_text == null && cancel_text == null)
        {
            cancelBtn.gameObject.SetActive(false);
            okBtn.gameObject.SetActive(false);
        }
    }

    public void OKClick()
    {
        GameObject.Destroy(this.gameObject);
        if(okCallBack != null)
        {
            okCallBack();
        }
    }


    public void CancelClick()
    {
        GameObject.Destroy(this.gameObject);
        if (cancelBack != null)
        {
            cancelBack();
        }
    }
}
