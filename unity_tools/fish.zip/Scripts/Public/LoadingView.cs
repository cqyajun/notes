﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using XLua;

[LuaCallCSharp]
public class LoadingView : BaseBehaviour
{
    static LoadingView instance;
    public static LoadingView Instance
    {
        get { return instance; }
    }
    public enum EndType
    {
        Event,
        Hide,
        Del,
    }

    public Slider progress;
    public EndType endtype;
    public float delay = 0.5f;
    public float curNum = 0;
    public string loadingGroups;
    public string luaName;
    public int loadCount;
    public Dictionary<string, float> loadNum = new Dictionary<string, float>();

    void Awake()
    {
        instance = this;
    }
    // Use this for initialization
    void Start()
    {
        string[] groups = loadingGroups.Split('|');
        for (int i = 0; i < groups.Length; i++)
        {
            if (groups[i] != "")
            {
                SetProgress(groups[i], 0);
            }
        }
    }

    public void Init()
    {
        string[] groups = loadingGroups.Split('|');
        for (int i = 0; i < groups.Length; i++)
        {
            if (groups[i] != "")
            {
                SetProgress(groups[i], 0);
            }
        }
    }

    // Update is called once per frame
    void Update ()
    {
        loadCount = loadNum.Count;

    }

    /// <summary>
    /// 设置进度
    /// </summary>
    public void SetProgress(string flag, float num)
    {
        
        if (curNum < 1)
        {
            if (loadNum.ContainsKey(flag))
            {
                loadNum[flag] = num;
            }
            else
            {
                loadNum.Add(flag, num);
                Debug.Log("加载标识：" + flag);
            }
            if(num == 1)
            {
                Debug.Log("完成加载：" + flag);
            }

            float val = 0;
            foreach (string key in loadNum.Keys)
            {
                val += loadNum[key];
            }
            val = val / loadNum.Keys.Count;
            if (curNum < val)
            {
                curNum = val;
                SetValue(curNum);
            }
            if (curNum >= 1)
            {
                SetValue(1);
                if (endtype == EndType.Hide)
                {
                    Invoke("Hide", delay);
                }
                else if (endtype == EndType.Del)
                {
                    Invoke("Del", delay);
                }
                else if (endtype == EndType.Event)
                {
                    if (GameMaster.Instance.luaReady)
                    {
                        Invoke("SendEvent", delay);
                    }
                    else
                    {
                        StartCoroutine(WaitSendEvent());
                    }
                }
                
            }
        }
    }


    public void Hide()
    {
        this.gameObject.SetActive(false);
    }

    public void Del()
    {
        //GameObject.Destroy(this.gameObject);
        UIManager.Instance.DelUI(this.gameObject.name);
    }

    public void SendEvent()
    {
        //GameEventManager.Instance.EventCallback(GameEventManager.EventType.Normal, this.gameObject.name);
        if (LuaManager.Instance != null)
        {
            LuaManager.Instance.CallFunction("NormalEventCallBack", luaName, this.gameObject.name, this);
        }
    }

    public IEnumerator WaitSendEvent()
    {
        while(!GameMaster.Instance.luaReady)
        {
            yield return 1;
        }
        //GameEventManager.Instance.EventCallback(GameEventManager.EventType.Normal, this.gameObject.name);
        if (LuaManager.Instance != null)
        {
            LuaManager.Instance.CallFunction("NormalEventCallBack", luaName, this.gameObject.name, this);
        }
    }

    /// <summary>
    /// 设置进度
    /// </summary>
    private void SetValue(float num)
    {
        progress.value = num;
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        Resources.UnloadUnusedAssets();
    }

}
