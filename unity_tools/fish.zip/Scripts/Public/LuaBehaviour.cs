﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using XLua;

[LuaCallCSharp]
public class LuaBehaviour : BaseBehaviour
{
    public bool editorSettting;
    public string path;
    public string tableName;
    public List<GameObject> objs = new List<GameObject>();
    public LuaTable table;
    
    protected Action luaStart;
    protected Action luaUpdate;
    protected Action luaFixedUpdate;
    protected Action luaOnDestroy;

    [CSharpCallLua]
    public delegate void GetEventCallBack(PointerEventData data);

    protected GetEventCallBack touchDown;
    protected GetEventCallBack touchUp;
    protected GetEventCallBack touckClick;

    // Use this for initialization
    void Start ()
    {
        LuaManager.Instance.DoFile(path);
        table = LuaManager.Instance.GetLuaTable(tableName);
        for (int i = 0; i < objs.Count; i++)
        {
            table.Set(objs[i].name,objs[i]);
        }

        luaStart = table.Get<Action>("Start");
        luaUpdate = table.Get<Action>("Updata");
        luaFixedUpdate = table.Get<Action>("FixedUpdate");
        luaOnDestroy = table.Get<Action>("OnDestroy");

        touchDown = table.Get<GetEventCallBack>("TouchDown");
        touchUp = table.Get<GetEventCallBack>("TouchUp");
        touckClick = table.Get<GetEventCallBack>("TouchClick");

        if (luaStart != null)
        {
            luaStart();
        }
    }
	
	// Update is called once per frame
	void Update ()
    {
        if (luaUpdate != null)
        {
            luaUpdate();
        }
    }

    void FixedUpdate()
    {
        if(luaFixedUpdate != null)
        {
            luaFixedUpdate();
        }
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        if (luaOnDestroy != null)
        {
            luaOnDestroy();
        }
        if(table != null)
        {
            table.Dispose();
        }
        luaOnDestroy = null;
        luaUpdate = null;
        luaFixedUpdate = null;
        luaStart = null;

        touchDown = null;
        touchUp = null;
        touckClick = null;
    }

    public void TouchDown(BaseEventData data)
    {
        PointerEventData p = (PointerEventData)data;
        if (touchDown != null)
        {
            touchDown(p);
        }
    }

    public void TouchUp(BaseEventData data)
    {
        PointerEventData p = (PointerEventData)data;
        if (touchUp != null)
        {
            touchUp(p);
        }
    }

    public void TouchClick(BaseEventData data)
    {
        PointerEventData p = (PointerEventData)data;
        if (touckClick != null)
        {
            touckClick(p);
        }
    }
}
