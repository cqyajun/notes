﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using XLua;

[LuaCallCSharp]
public class LuaBehaviourNew : LuaBehaviour
{
 
    private LuaTable _initData = null;
    private bool isStart = false;

    [CSharpCallLua]
    public delegate LuaTable newCallBack();
    protected newCallBack luaNew;
    // Use this for initialization
    void Start ()
    {
        LuaManager.Instance.DoFile(path);
        table = LuaManager.Instance.GetLuaTable(tableName);

        luaNew = table.Get<newCallBack>("New");
        if(luaNew != null){
            table = luaNew();
        }

        for (int i = 0; i < objs.Count; i++)
        {
            table.Set(objs[i].name,objs[i]);
        }

        luaStart = table.Get<Action>("Start");
        luaUpdate = table.Get<Action>("Updata");
        luaFixedUpdate = table.Get<Action>("FixedUpdate");
        luaOnDestroy = table.Get<Action>("OnDestroy");

        touchDown = table.Get<GetEventCallBack>("TouchDown");
        touchUp = table.Get<GetEventCallBack>("TouchUp");
        touckClick = table.Get<GetEventCallBack>("TouchClick");

        if (luaStart != null)
        {
            luaStart();
        }

        preloadData();
        isStart = true;
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
    }

    public void setInitData(LuaTable data) {
        if (data == null) {
            return;
        }
        _initData = data;
        if (isStart) {
            preloadData();
        }
    }

    private void preloadData() {
        if (_initData != null) {
            Action<LuaTable, LuaTable> luaPreload = table.Get<Action<LuaTable, LuaTable>>("preloadData");
            if (luaPreload != null)
            {
                luaPreload(table, _initData);
            }
        }
    }
}
