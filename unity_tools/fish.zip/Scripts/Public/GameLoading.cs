﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;

[LuaCallCSharp]
public class GameLoading : MonoBehaviour
{

    private static GameLoading instance = null;
    public static GameLoading Instance
    {
        get
        {
            if (instance == null)
            {
                GameObject go = Resources.Load("public/Prefabs/uis/game_loading") as GameObject;
                go = GameObject.Instantiate(go);
                instance = go.GetComponent<GameLoading>();
            }
            return instance;
        }
    }
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    public void Show()
    {
        this.gameObject.SetActive(true);
    }

    public void Hide()
    {
        this.gameObject.SetActive(false);
    }
}
