﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;

[LuaCallCSharp]
[System.Serializable]
public class FishMsg
{
    public SpriteRenderer body;
    public Collider2D collider2D;
    public Transform shootPot;
    public Animator animator;
    public float speed;
}

[LuaCallCSharp]
public class Fish : BaseBehaviour
{
    public string id; //mainID|subID|fishType
    public bool big;
    public bool destroyResRunTime;
    public bool dieJump;
    public bool showGoldText;
    public bool cameraMove;
    public string dieEffect;
    public int dieGoldEffect;
    public string dieSound;
    public string bgm;
    public int gold;
    public float destroyDelay;
    public bool alive = true;
    public bool closeSettingMove;

    public List<FishMsg> fishMsgs = new List<FishMsg>();
    
    
	// Use this for initialization
	void Start ()
    {

    }
	
	// Update is called once per frame
	void Update ()
    {
        if (FishingManager.Instance != null)
        {
            if (alive && !closeSettingMove)
            {
                for (int i = 0; i < fishMsgs.Count; i++)
                {
                    if (fishMsgs[i].speed != 0)
                    {
                        fishMsgs[i].animator.Play("move", 0, FishingManager.Instance.time * fishMsgs[i].speed);
                    }
                }
            }
        }
    }


    public void Hit(Bullet bullet)
    {
        if (FishingManager.Instance.isOver)
        {
            return;
        }
        if(bullet != null && bullet.isPlayer)
        {
            if(bullet.targetFish != null && bullet.targetFish != this)
            {
                return;
            }
            bullet.fishIDs.Add(id);
            for (int i = 0; i < fishMsgs.Count; i++)
            {
                fishMsgs[i].animator.SetBool("hit", true);
            }
        }
    }

    public void ZTLXHit(ZTLXBullet bullet)
    {
        if (FishingManager.Instance.isOver)
        {
            return;
        }
        if (bullet != null && bullet.isPlayer)
        {
            bullet.fishIDs.Add(id);
            for (int i = 0; i < fishMsgs.Count; i++)
            {
                fishMsgs[i].animator.SetBool("hit", true);
            }
        }
    }

    public void Die()
    {
        if (FishingManager.Instance.isOver)
        {
            return;
        }
        Debug.Log(this.gameObject.name + " Die!!!");
        
    }

   

    public override void OnDestroy()
    {
        if(destroyResRunTime || FishingManager.Instance.isOver)
        {
            base.OnDestroy();
        }
    }
}
