﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;

[LuaCallCSharp]
public class ZTLXBullet : MonoBehaviour
{
    public Animator animator;
    public Collider2D pc2D;
    public bool isPlayer;   //玩家标识，用于判断是否发送捕鱼消息和鱼被击中表现判断
    public int id;
    public float speed;
    public float moveTime;
    public List<string> fishIDs = new List<string>();
    [System.NonSerialized]
    public Vector2 min;
    [System.NonSerialized]
    public Vector2 max;

    public bool speedDown;
    // Use this for initialization
    void Start ()
    {
        float cameraHeight = Camera.main.orthographicSize * 2;
        Vector2 cameraSize = new Vector2(Camera.main.aspect * cameraHeight, cameraHeight);
        Vector3 offset = new Vector3(cameraSize.x / 2f, -cameraSize.y / 2f) - Camera.main.transform.localPosition;
        min.y = -cameraSize.y;
        min.x -= offset.x;
        max.x = cameraSize.x - offset.x;
        pc2D.enabled = true;
        Invoke("Over", moveTime);
    }
	
	// Update is called once per frame
	void Update ()
    {
		
	}


    void FixedUpdate()
    {
        if (FishingManager.Instance.isOver)
        {
            return;
        }

        if(speedDown)
        {
            speed -= Time.deltaTime * speed * 2;
        }

        if (speed > 0)
        {
            this.transform.position = this.transform.position + this.transform.up * speed;
            CheckRect();
        }

        if (isPlayer && fishIDs.Count > 0)
        {
            //发送消息，如果已经发送过消息就isPlayer = false
            LuaManager.Instance.CallFunction("FishingScene.HitFish", id, fishIDs);
            fishIDs.Clear();
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (FishingManager.Instance.isOver)
        {
            return;
        }
        //Debug.LogError(other.name + "=" + other.tag);
        if (other.tag == "fish")
        {
            LuaManager.Instance.CallFunction("FishingScene.ZTLXBulletCollider", other.transform.position);
            other.SendMessageUpwards("ZTLXHit", this);
        }
    }


    void CheckRect()
    {
        if (this.transform.position.x < min.x)
        {
            this.transform.position = new Vector3(min.x + (min.x - this.transform.position.x), this.transform.position.y);
            float dot = Vector3.Dot(this.transform.up, Vector3.up);
            float angle = Vector3.Angle(this.transform.up, Vector3.up);
            this.transform.Rotate(0, 0, -angle * 2);
        }
        else if (this.transform.position.x > max.x)
        {
            this.transform.position = new Vector3(max.x - (this.transform.position.x - max.x), this.transform.position.y);
            float dot = Vector3.Dot(this.transform.up, Vector3.up);
            float angle = Vector3.Angle(this.transform.up, Vector3.up);
            this.transform.Rotate(0, 0, angle * 2);
        }
        else if (this.transform.position.y < min.y)
        {
            this.transform.position = new Vector3(this.transform.position.x, min.y + (min.y - this.transform.position.y));
            float dot = Vector3.Dot(this.transform.up, Vector3.right);
            float angle = Vector3.Angle(this.transform.up, Vector3.right);
            this.transform.Rotate(0, 0, angle * 2);
        }
        else if (this.transform.position.y > max.y)
        {
            this.transform.position = new Vector3(this.transform.position.x, max.y - (this.transform.position.y - max.y));
            float dot = Vector3.Dot(this.transform.up, Vector3.right);
            float angle = Vector3.Angle(this.transform.up, Vector3.right);
            this.transform.Rotate(0, 0, -angle * 2);
        }
    }


    public void Over()
    {
        animator.enabled = true;
        pc2D.enabled = false;
        speedDown = true;
        if (isPlayer)
        {
            LuaManager.Instance.CallFunction("FishingScene.ZTLXBulletOver", this);
            FishingManager.Instance.shootCount--;
        }
    }
}
