﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;

[LuaCallCSharp]
public class FishingManager : MonoBehaviour
{
    static FishingManager instance;
    public static FishingManager Instance
    {
        get
        {
            return instance;
        }
    }

    public float time;
    public bool isOver;
    public int shootCount;
    public bool closeShadow;
    public Dictionary<string, GameObject> saveObjects = new Dictionary<string, GameObject>();
    public int objsNum;
	// Use this for initialization
	void Awake ()
    {
        instance = this;
        //DontDestroyOnLoad(this.gameObject);
    }
	
	// Update is called once per frame
	void Update ()
    {
        if (!isOver)
        {
            time += Time.deltaTime;
            if (time > 600)
            {
                time = 0;
            }
        }
        else if(shootCount != 0)
        {
            shootCount = 0;
        }
        else if(saveObjects.Count > 0)
        {
            foreach(var item in saveObjects)
            {
                if(item.Value != null)
                {
                    GameObject.Destroy(item.Value);
                }
            }
            saveObjects.Clear();
        }

        if(objsNum != saveObjects.Count)
        {
            objsNum = saveObjects.Count;
        }
    }
}
