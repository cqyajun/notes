﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;

[LuaCallCSharp]
public class Cannon : MonoBehaviour
{
    public Animator animator;
    public Transform cannon;
    public Transform shootPot;
	// Use this for initialization
	void Start ()
    {
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}
}
