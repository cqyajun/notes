﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;

[LuaCallCSharp]
public class Bullet : MonoBehaviour
{
    public GameObject bullet;
    public GameObject net;
    public float speed;
    [System.NonSerialized]
    public Vector2 min;
    [System.NonSerialized]
    public Vector2 max;
    

    public bool isPlayer;   //玩家标识，用于判断是否发送捕鱼消息和鱼被击中表现判断
    public int id;
    public Fish targetFish;
    public Transform targetFishShootPot;
    public List<string> fishIDs = new List<string>();
    public int maxFish = 50;
    
    // Use this for initialization
    void Start ()
    {
        float cameraHeight = Camera.main.orthographicSize * 2;
        Vector2 cameraSize = new Vector2(Camera.main.aspect * cameraHeight, cameraHeight);
        Vector3 offset = new Vector3(cameraSize.x / 2f, -cameraSize.y / 2f) - Camera.main.transform.localPosition;
        min.y = -cameraSize.y;
        min.x -= offset.x;
        max.x = cameraSize.x - offset.x;
    }
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    void FixedUpdate()
    {
        if(FishingManager.Instance.isOver)
        {
            return;
        }
        if (speed > 0)
        {
            if (targetFish != null && targetFish.alive)
            {
                string fishID = targetFish.id;
                Vector3 tp = targetFishShootPot.position;
                tp.z = this.transform.position.z;
                this.transform.up = tp - this.transform.position;
                this.transform.position = this.transform.position + this.transform.up * speed;
                CheckRect();
                if(targetFish == null && isPlayer)
                {
                    LuaManager.Instance.CallFunction("FishingView.ChangeLockFish", fishID);
                }
            }
            else
            {
                this.transform.position = this.transform.position + this.transform.up * speed;
                CheckRect();
            }
        }
        else if(isPlayer && fishIDs.Count > 0)
        {
            if(fishIDs.Count > maxFish)
            {
                fishIDs.RemoveRange(maxFish, fishIDs.Count - maxFish);
            }
            //List<string> ts = fishIDs;
            //fishIDs = new List<string>();
            //fishIDs.Add(ts[0]);
            //发送消息，如果已经发送过消息就isPlayer = false
            LuaManager.Instance.CallFunction("FishingScene.HitFish", id, fishIDs);
            //FishingManager.Instance.shootCount--;
            isPlayer = false;
        }
    }

    void OnDestroy()
    {
        //if(isPlayer)
        //{
        //    FishingManager.Instance.shootCount--;
        //}
    }


    void OnBulletCollider2D(Collider2D other)
    {
        if (FishingManager.Instance.isOver)
        {
            return;
        }
        //Debug.Log(other.name + "=" + other.tag);
        if(targetFish == null && other.tag == "fish")
        {
            StartCoroutine(ShowNet());
        }
        else if(targetFish != null)
        {
            for (int i = 0; i < targetFish.fishMsgs.Count; i++)
            {
                if(targetFish.fishMsgs[i].collider2D.gameObject == other.gameObject)
                {
                    StartCoroutine(ShowNet());
                }
            }
        }
    }

    void OnNetCollider2D(Collider2D other)
    {
        if (FishingManager.Instance.isOver)
        {
            return;
        }
        if (isPlayer && other.tag == "fish")
        {
            other.SendMessageUpwards("Hit",this);
        }
    }

    IEnumerator ShowNet()
    {
        speed = 0;
        bullet.SetActive(false);
        net.SetActive(true);
        yield return new WaitForSeconds(1);
        if (FishingManager.Instance.isOver)
        {
            yield break;
        }
        GameObject.Destroy(this.gameObject);
    }



    void CheckRect()
    {
        if (this.transform.position.x < min.x)
        {
            this.transform.position = new Vector3(min.x + (min.x - this.transform.position.x), this.transform.position.y);
            float angle = Vector3.Angle(this.transform.up, Vector3.up);
            this.transform.Rotate(0, 0, -angle * 2);
            targetFish = null;
        }
        else if (this.transform.position.x > max.x)
        {
            this.transform.position = new Vector3(max.x - (this.transform.position.x - max.x), this.transform.position.y);
            float angle = Vector3.Angle(this.transform.up, Vector3.up);
            this.transform.Rotate(0, 0, angle * 2);
            targetFish = null;
        }
        else if (this.transform.position.y < min.y)
        {
            this.transform.position = new Vector3(this.transform.position.x, min.y + (min.y - this.transform.position.y));
            float angle = Vector3.Angle(this.transform.up, Vector3.right);
            this.transform.Rotate(0, 0, angle * 2);
            targetFish = null;
        }
        else if (this.transform.position.y > max.y)
        {
            this.transform.position = new Vector3(this.transform.position.x, max.y - (this.transform.position.y - max.y));
            float angle = Vector3.Angle(this.transform.up, Vector3.right);
            this.transform.Rotate(0, 0, -angle * 2);
            targetFish = null;
        }
    }
}
