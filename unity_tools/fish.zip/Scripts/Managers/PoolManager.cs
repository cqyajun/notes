﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;

[LuaCallCSharp]
public class NewSpawnPool
{
    public UnityEngine.Object prefab;
    public List<UnityEngine.Object> haveObjs = new List<UnityEngine.Object>();
}

[LuaCallCSharp]
public class PoolManager : MonoBehaviour
{
    static PoolManager instance;
    public static PoolManager Instance
    {
        get { return instance; }
    }

    public Dictionary<string, Dictionary<string, NewSpawnPool>> pool = new Dictionary<string, Dictionary<string, NewSpawnPool>>();

    void Awake()
    {
        instance = this;
        GameObject.DontDestroyOnLoad(this.gameObject);
    }

    // Use this for initialization
    void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    public void SpawnTableObjs(LuaTable tab, int count, string poolName, Type type = null, bool isInstantiate = true, float delayDestroy = 0, float delayHide = 0, Action callBack = null)
    {
        LoadingView.Instance.SetProgress(poolName, 0);
        StartCoroutine(TableObjsLoading(tab, count, poolName, type, isInstantiate, delayDestroy, delayHide, callBack));
    }

    IEnumerator TableObjsLoading(LuaTable tab, int count, string poolName, Type type = null, bool isInstantiate = true, float delayDestroy = 0, float delayHide = 0, Action callBack = null)
    {
        int num = 0;
        for (int i = 1; i <= count; i++)
        {
            Action<UnityEngine.Object> endCallBack = (obj) =>
            {
                num++;
                if (LoadingView.Instance != null)
                {
                    LoadingView.Instance.SetProgress(poolName, num / count);
                }
                if(isInstantiate && delayDestroy != 0)
                {
                    //如果是实例化
                    GameObject go = (GameObject)obj;
                    DestroyObj dobj = go.AddComponent<DestroyObj>();
                    dobj.obj = go;
                    dobj.delay = delayDestroy;

                }
                else if(isInstantiate && delayHide != 0)
                {
                    //如果是实例化
                    GameObject go = (GameObject)obj;
                    HideObj dobj = go.AddComponent<HideObj>();
                    dobj.obj = go;
                    dobj.delay = delayHide;
                }
                else if(isInstantiate && delayHide == 0)
                {
                    GameObject go = (GameObject)obj;
                    go.SetActive(false);
                }
                if (num == count && callBack != null)
                {
                    callBack();
                }
            };
            SpawnAsync(tab.Get<int,string>(i), poolName, type, isInstantiate, endCallBack);
            yield return 1;
        }
    }

    public object Spawn(string itemName, string poolName, Type type = null, bool isInstantiate = true)
    {
        //this.gameObject.transform.position
        AddPrefab(itemName, poolName, type);
        if (pool[poolName][itemName].prefab != null)
        {
            if (isInstantiate)
            {
                GameObject obj = GameObject.Instantiate(pool[poolName][itemName].prefab) as GameObject;
                if (obj != null)
                {
                    pool[poolName][itemName].haveObjs.Add(obj);
                }
                obj.name = itemName;
                return obj;
            }
            else
            {
                return pool[poolName][itemName].prefab;
            }
        }
        return null;
    }
    

    public void SpawnAsync(string itemName, string poolName, Type type = null, bool isInstantiate = true, Action<UnityEngine.Object> callBack = null)
    {
        Action<UnityEngine.Object> endCallBack = (loadObj) =>
        {
            try
            {
                if (callBack != null)
                {
                    if (isInstantiate)
                    {
                        GameObject obj = GameObject.Instantiate(loadObj, this.transform) as GameObject;
                        if (obj != null)
                        {
                            obj.name = itemName;
                            pool[poolName][itemName].haveObjs.Add(obj);
                            //obj.transform.SetParent(this.transform);
                            //obj.transform.localPosition = Vector3.zero;
                        }
                        callBack(obj);
                    }
                    else
                    {
                        callBack(pool[poolName][itemName].prefab);
                    }
                }
            }
            catch(Exception e)
            {
                Debug.LogError(itemName);
                Debug.LogError(poolName);
                Debug.LogError(e);
            }
        };

        AddPrefabAsync(itemName, poolName, type, endCallBack);

    }
    public void AddPrefabAsync(string itemName, string poolName, Type type = null, Action<UnityEngine.Object> endCallBack = null)
    {
        CreatePool(poolName);
        if (!pool[poolName].ContainsKey(itemName))
        {
            Action<UnityEngine.Object> callBack = (obj) =>
            {
                pool[poolName][itemName] = new NewSpawnPool();
                pool[poolName][itemName].prefab = obj;
                if (endCallBack != null)
                {
                    endCallBack(obj);
                }
            };
            StartCoroutine(LoadManager.Instance.LoadAsync(itemName, poolName, type, callBack));
        }
        else
        {
            if(type == pool[poolName][itemName].prefab.GetType())
            {
                if (endCallBack != null)
                {
                    endCallBack(pool[poolName][itemName].prefab);
                }
            }
            else
            {
                Action<UnityEngine.Object> callBack = (obj) =>
                {
                    pool[poolName][itemName] = new NewSpawnPool();
                    pool[poolName][itemName].prefab = obj;
                    if (endCallBack != null)
                    {
                        endCallBack(obj);
                    }
                };
                StartCoroutine(LoadManager.Instance.LoadAsync(itemName, poolName, type, callBack));
            }
            //Debug.LogError(pool[poolName].ContainsKey(itemName));
            
        }
    }

    public void AddPrefab(string itemName, string poolName, Type type = null)
    {
        CreatePool(poolName);
        if (!pool[poolName].ContainsKey(itemName))
        {
            //UnityEngine.Object obj = Instantiate(LoadManager.Instance.Load(itemName, poolName, type));
            pool[poolName][itemName] = new NewSpawnPool();
            pool[poolName][itemName].prefab = LoadManager.Instance.Load(itemName, poolName, type);
        }
    }


    public void CreatePool(string poolName)
    {
        if (!pool.ContainsKey(poolName))
        {
            pool[poolName] = new Dictionary<string, NewSpawnPool>();
        }
    }

    public void DestroyPool(string poolName)
    {
        if (pool.ContainsKey(poolName))
        {
            Dictionary<string, NewSpawnPool> destroyPool = pool[poolName];
            foreach (KeyValuePair<string, NewSpawnPool> pair in destroyPool)
            {
                for (int i = 0; i < destroyPool[pair.Key].haveObjs.Count; i++)
                {
                    GameObject.DestroyImmediate((UnityEngine.Object)(destroyPool[pair.Key].haveObjs[i]));
                }
                destroyPool[pair.Key].prefab = null;
                destroyPool[pair.Key].haveObjs = null;
            }
            destroyPool.Clear();
            pool.Remove(poolName);
            LoadManager.Instance.UnLoadGroup(poolName);
        }
    }
}
