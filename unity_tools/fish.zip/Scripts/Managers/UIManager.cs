﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using XLua;

[LuaCallCSharp]
public class UIManager : MonoBehaviour
{
    static UIManager instance;
    public static UIManager Instance
    {
        get { return instance; }
    }
    public Transform root;
    public Camera uiCamera;
    public Dictionary<string, GameObject> uis = new Dictionary<string, GameObject>();
    void Awake()
    {
        instance = this;
        GameObject.DontDestroyOnLoad(this.gameObject);
    }
    // Use this for initialization
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

    }

    public GameObject GetUI(string uiName)
    {
        if (uis.ContainsKey(uiName) && uis[uiName] != null)
        {
            return uis[uiName];
        }
        else
        {
            Transform tr = this.transform.Find(uiName);
            if (tr != null)
            {
                return tr.gameObject;
            }
        }
        return null;
    }

    public GameObject ShowUI(string group, string uiName, Transform parTrans = null)
    {
        if (uis.ContainsKey(uiName) && uis[uiName] != null)
        {
            return uis[uiName];
        }
        else
        {
            GameObject go = PoolManager.Instance.Spawn(uiName, group) as GameObject;
            if (parTrans == null)
            {
                go.transform.SetParent(root, false);
            }
            else
            {
                go.transform.SetParent(parTrans, false);
            }

            uis[uiName] = go;
            go.name = uiName;
            return go;
        }
    }

    public void ShowUIAsync(string group, string uiName, Transform parTrans = null, Action<GameObject> ui_callback = null)
    {
        if (uis.ContainsKey(uiName) && uis[uiName] != null)
        {
            if (ui_callback != null)
            {
                ui_callback(uis[uiName]);
            }
        }
        else
        {
            Action<UnityEngine.Object> callBack = (obj) =>
            {
                GameObject go = obj as GameObject;
                if (parTrans == null)
                {
                    go.transform.SetParent(root, false);
                }
                else
                {
                    go.transform.SetParent(parTrans, false);
                }
                uis[uiName] = go;
                go.name = uiName;
                if (ui_callback != null)
                {
                    ui_callback(go);
                }
            };
            PoolManager.Instance.SpawnAsync(uiName, group, null, true, callBack);
        }
    }

    public void DelUI(string uiName)
    {
        if (uis.ContainsKey(uiName) && uis[uiName] != null)
        {
            GameObject.Destroy(GetUI(uiName));
            uis.Remove(uiName);
        }
        else
        {
            Transform tr = this.transform.Find(uiName);
            if (tr != null)
            {
                GameObject.Destroy(tr.gameObject);
            }
        }
        //PoolManager.Instance.DestroyPool(uiName);
    }

    public void DelAllUI()
    {
        foreach (var ui in uis)
        {
            string uiName = ui.Key;
            GameObject.Destroy(GetUI(uiName));
            //uis.Remove(uiName);
            //PoolManager.Instance.DestroyPool(uiName);
        }
        uis.Clear();
    }

}
