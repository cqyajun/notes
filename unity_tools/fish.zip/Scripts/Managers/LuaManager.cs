﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using UnityEngine;
using XLua;

[LuaCallCSharp]
public class LuaManager : MonoBehaviour
{
    private static LuaManager instance = null;
    public static LuaManager Instance
    {
        get
        {
            return instance;
        }
    }
    public bool needLuaAB;
    public string luaInitFile;
    public string luaInitFunction;
    public LuaEnv luaEnv = null;
    public Dictionary<string, AssetBundle> luaABs = new Dictionary<string, AssetBundle>();
    //public Dictionary<string, byte[]> luaFiles = new Dictionary<string, byte[]>();
    public Dictionary<string, LuaFunction> funs = new Dictionary<string, LuaFunction>();
    internal static float lastGCTime = 0;
    internal const float GCInterval = 1;//1 second 
    void Awake()
    {
        instance = this;
        GameObject.DontDestroyOnLoad(this.gameObject);
        luaEnv = new LuaEnv();
    }
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update ()
    {
        if (luaEnv != null && Time.time - lastGCTime > GCInterval)
        {
            luaEnv.Tick();
            lastGCTime = Time.time;
        }
    }

    void OnDestroy()
    {
        //CallFunction("OnDisconnect");
    }


    public IEnumerator Init()
    {
        if (luaEnv != null)
        {
            yield return 0;
#if UNITY_WEBGL
#if UNITY_EDITOR
            luaEnv.AddLoader((ref string filename) =>
            {
                filename = Application.dataPath + "/XLua/Lua/" + filename.Replace(".", "/") + ".lua";
                if (File.Exists(filename))
                {
                    return File.ReadAllBytes(filename);
                }
                Debug.LogError(filename);
                return null;
            });
#else
            luaEnv.AddLoader((ref string filename) =>
            {
                filename ="Lua/" + filename.Replace(".", "/") + ".lua";
                return Resources.Load<TextAsset>(filename).bytes;
            });
#endif
            LuaReady();
            yield return 0;
#else
            if (GameMaster.Instance.isHotFix)
            {
                if (needLuaAB)
                {
                    luaEnv.AddLoader((ref string filename) =>
                    {
                        filename = filename.Replace(".", "/");
                        string[] subName = filename.Split('/');
                        string abName = subName[0] + "_lua";
                        for (int i = 1; i < subName.Length - 1; i++)
                        {
                            abName += "_" + subName[i].ToLower();
                        }

                        if (luaABs.ContainsKey(abName))
                        {
                            TextAsset luaCode = luaABs[abName].LoadAsset<TextAsset>(subName[subName.Length - 1] + ".lua");
                            if (luaCode != null)
                            {
                                byte[] data = luaCode.bytes;
                                Resources.UnloadAsset(luaCode);
                                return data;
                            }
                            else
                            {
                                Debug.LogError("空:" + filename);
                            }
                        }
                        else
                        {
                            Debug.LogError("没有ab：" + abName);
                        }
                        return null;
                    });
                }
                else
                {
                    luaEnv.AddLoader((ref string filename) =>
                    {
                        filename = Application.dataPath + "/XLua/Lua/" + filename.Replace(".", "/") + ".lua";
                        if (File.Exists(filename))
                        {
                            return File.ReadAllBytes(filename);
                        }
                        Debug.LogError(filename);
                        return null;
                    });
                }
            }
            else
            {
                luaEnv.AddLoader((ref string filename) =>
                {
                    filename = "Lua/" + filename.Replace(".", "/") + ".lua";
                    return Resources.Load<TextAsset>(filename).bytes;
                });
            }
           
#endif
        }
    }

    public IEnumerator LuaInit(List<string> groupName,Action callBack = null)
    {
        if (GameMaster.Instance.isHotFix)
        {
            for (int n = 0; n < groupName.Count; n++)
            {
                if (File.Exists(StaticData.resPath + "/" + groupName[n] + ".ver.txt"))
                {
                    string[] luaMsgs = File.ReadAllLines(StaticData.resPath + "/" + groupName[n] + ".ver.txt");
                    for (int i = 0; i < luaMsgs.Length; i++)
                    {
                        if (luaMsgs[i].Contains("lua"))
                        {
                            yield return StartCoroutine(LoadLua(groupName[n], luaMsgs[i]));
                        }
                    }
                }
                else
                {
                    Debug.LogError("本地没有lua文件 group = " + groupName[n]);
                }
            }
        }
        if(callBack != null)
        {
            callBack();
        }
    }

    IEnumerator LoadLua(string groupName, string luaMsgs)
    {
        if (GameMaster.Instance.isHotFix)
        {
            string abName = luaMsgs.Split('|')[0];
            if (luaABs.ContainsKey((groupName + "/" + abName.Replace(".unity3d", "")).Replace("/", "_")))
            {
                luaABs[(groupName + "/" + abName.Replace(".unity3d", "")).Replace("/", "_")].Unload(true);
                luaABs.Remove((groupName + "/" + abName.Replace(".unity3d", "")).Replace("/", "_"));
            }
            AssetBundleCreateRequest abcq = AssetBundle.LoadFromFileAsync(StaticData.resPath + "/" + groupName + "/" + abName);
            yield return abcq;
            luaABs[(groupName + "/" + abName.Replace(".unity3d", "")).Replace("/", "_")] = abcq.assetBundle;
            if (luaABs[(groupName + "/" + abName.Replace(".unity3d", "")).Replace("/", "_")] == null)
            {
                Debug.LogError("加载失败:" + (groupName + "/" + abName.Replace(".unity3d", "")).Replace("/", "_"));
            }
            else
            {
                Debug.Log("加载成功:" + (groupName + "/" + abName.Replace(".unity3d", "")).Replace("/", "_"));
            }
        }
    }

   
    public IEnumerator LuaReady()
    {
        //DoFile("public/Start");
        //CallFunction("StartGame");
        DoFile(luaInitFile);
        CallFunction(luaInitFunction);
        GameMaster.Instance.luaReady = true;
        yield return StartCoroutine(GameMaster.Instance.LuaInitOver());
    }


    public object[] DoFile(string file)
    {
         return luaEnv.DoString("require '" + file + "'");
    }

    public object[] DoString(string str)
    {
        return luaEnv.DoString(str);
    }

    public void JsonToTab(string json, LuaTable tab)
    {
        JsonDocument doc = JsonDocument.FromString(json);
        if (doc.IsObject())
        {
            JsonObject jsobj = doc.Object;
            SearchJsonObject(jsobj, tab);
        }
    }

    public void SearchJsonObject(JsonObject jsobj, LuaTable tab)
    {
        foreach (string key in jsobj.Keys)
        {
            switch (jsobj[key].Valuetype)
            {
                case JsonType.BOOL:
                    tab.Set<string, bool>(key, jsobj[key].ToBool());
                    break;
                case JsonType.DOUBLE:
                    tab.Set<string, double>(key, jsobj[key].ToDouble());
                    break;
                case JsonType.LONG:
                    tab.Set<string, long>(key, jsobj[key].ToLong());
                    break;
                case JsonType.STRING:
                    tab.Set<string, string>(key, jsobj[key].ToString());
                    break;
                case JsonType.OBJECT:
                    LuaTable subTab = luaEnv.NewTable();
                    JsonObject jo = jsobj[key].ToObject();
                    SearchJsonObject(jo, subTab);
                    tab.Set<string, LuaTable>(key, subTab);
                    break;
                case JsonType.ARRAY:
                    LuaTable arrayTab = luaEnv.NewTable();
                    JsonArray ja = jsobj[key].ToArray();
                    SearchJsonArray(ja, arrayTab);
                    tab.Set<string, LuaTable>(key, arrayTab);
                    break;
            }
        }
    }

    public void SearchJsonArray(JsonArray jv, LuaTable tab)
    {
        for (int i = 0; i < jv.Count; i++)
        {
            switch (jv[i].Valuetype)
            {
                case JsonType.BOOL:
                    tab.Set<int, bool>(i + 1, jv[i].ToBool());
                    break;
                case JsonType.DOUBLE:
                    tab.Set<int, double>(i + 1, jv[i].ToDouble());
                    break;
                case JsonType.LONG:
                    tab.Set<int, long>(i + 1, jv[i].ToLong());
                    break;
                case JsonType.STRING:
                    tab.Set<int, string>(i + 1, jv[i].ToString());
                    break;
                case JsonType.OBJECT:
                    LuaTable subTab = luaEnv.NewTable();
                    JsonObject jo = jv[i].ToObject();
                    SearchJsonObject(jo, subTab);
                    tab.Set<int, LuaTable>(i + 1, subTab);
                    break;
                case JsonType.ARRAY:
                    LuaTable arrayTab = luaEnv.NewTable();
                    JsonArray ja = jv[i].ToArray();
                    SearchJsonArray(ja, arrayTab);
                    tab.Set<int, LuaTable>(i + 1, arrayTab);
                    break;
            }

        }
    }




    public object[] CallFunction(string fun, params object[] args)
    {

        if (luaEnv != null)
        {
            try
            {
                if (funs.ContainsKey(fun) && funs[fun] != null)
                {
                    return funs[fun].Call(args);
                }
            }
            catch(Exception e)
            {
                Debug.LogError(e);
            }
            LuaFunction func = luaEnv.Global.GetInPath<LuaFunction>(fun);
            if (func != null)
            {
                funs[fun] = func;
                return func.Call(args);
            }
            else
            {
                Debug.LogError(fun);
            }
        }
        return null;
    }
    

    public LuaTable GetLuaTable(string path)
    {
        return luaEnv.Global.GetInPath<LuaTable>(path);
    }

    public object[] CallMethod(string module, string func, params object[] args)
    {
        return CallFunction(module + "." + func, args);
    }

    public LuaEnv GetLuaEnv()
    {
        return luaEnv;
    }

    public string GetString(string str)
    {
        string[] t = str.Split('\0');
        return t[0];
    }

    public void TableDispose(LuaTable tab)
    {
        tab.Dispose();
    }
}
