﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text;
using UnityEngine;
using XLua;



[LuaCallCSharp]
public class GameMaster : MonoBehaviour
{
    private static GameMaster instance = null;
    public static GameMaster Instance
    {
        get
        {
            return instance;
        }
    }
    public bool AllReady
    {
        get
        {
            return luaReady && downloadReady && loadReady;
        }
    }
    
    public string UserName
    {
        set
        {
            userName = value;
            PlayerPrefs.SetString("userName", userName);
        }
        get
        {
            return userName;
        }
    }

    public string Password
    {
        set
        {
            password = value;
            PlayerPrefs.SetString("password", password);
        }
        get
        {
            return password;
        }
    }

    public string MAC
    {
        set
        {
            mac = value;
            PlayerPrefs.SetString("mac", mac);
        }
        get
        {
            return mac;
        }
    }
    public class GitHubInfo
    {
        public string content;
    }

    public bool yxdReady;
    public bool gateReady;
    public bool downloadReady;
    public bool luaReady;
    public bool loadReady;
    public bool isLog;
    public bool isClearPrefs;
    public bool isHotFix;
    public bool useSaveUrl;
    public int gateErrorCount;
    public int fps;



    public string userName;
    public string password;
    public string cid;
    public string scid;
    public string dtype;
    public string mac;
    public string token;
    public string localIP;
    public string gameKey;
    public string cosUrl;
    public string githubUrl;
    public string aesKey;
    public List<string> gateURLs = new List<string>();
    public Dictionary<string, bool> gameState = new Dictionary<string, bool>();
    public string[] url_744;
    private readonly System.DateTime Epoch0 = new System.DateTime(1970, 1, 1, 0, 0, 0, System.DateTimeKind.Utc);
    

    public LuaTable tab;
#if UNITY_WEBGL
    [DllImport("__Internal")]
    private static extern string StringReturnValueFunction();
    public string UrlMsg;
#endif
    void Awake()
    {
        instance = this;
        GameObject.DontDestroyOnLoad(this.gameObject);
        Debug.unityLogger.logEnabled = isLog;
        if (isClearPrefs)
        {
            PlayerPrefs.DeleteAll();
        }

        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        Application.targetFrameRate = fps;
        mac = PlayerPrefs.GetString("mac");
        if (mac == "")
        {
#if UNITY_WEBGL
            //mac = SystemInfo.deviceUniqueIdentifier;
#elif UNITY_ANDROID
            mac = SystemInfo.deviceUniqueIdentifier;
#elif UNITY_IOS
            mac = SystemInfo.deviceUniqueIdentifier;
#endif
            PlayerPrefs.SetString("mac", mac);
        }
        userName = PlayerPrefs.GetString("userName");
        password = PlayerPrefs.GetString("password");
        string key = PlayerPrefs.GetString("gameKey");
        
        if (key != "")
        {
            string sk = NetworkManager.AesDecryptor_Base64(key, aesKey);
            Debug.Log(sk);
            if (sk != gameKey)
            {
                gameKey = sk;
            }
        }
        

#if UNITY_WEBGL
        dtype = "0";
#elif UNITY_ANDROID
        dtype = "1";
#elif UNITY_IOS
        dtype = "2";
#endif
    }
    // Use this for initialization
    public IEnumerator Start()
    {
        yield return 1;
        if (!useSaveUrl)
        {
#if !UNITY_WEBGL && !UNITY_EDITOR

        if (!InitYXD(gameKey,mac))
        {
            WWW wwwCOS = new WWW(cosUrl + "?timestamp = " + System.DateTime.Now.Ticks.ToString());
            yield return wwwCOS;
            //Debug.LogError(wwwCOS.bytes);
            //Debug.LogError(wwwCOS.text);
            gameKey = NetworkManager.AesDecryptor_Base64(wwwCOS.text, aesKey);
            if (wwwCOS.error != null || !InitYXD(gameKey, mac))
            {
                WWW wwwGitHub = new WWW(githubUrl + "?timestamp = " + System.DateTime.Now.Ticks.ToString());
                yield return wwwGitHub;
                //Debug.LogError(wwwGitHub.bytes);
                //Debug.LogError(wwwGitHub.text);
                GitHubInfo g = JsonUtility.FromJson<GitHubInfo>(wwwGitHub.text);
                byte[] bs = Convert.FromBase64String(g.content);
                gameKey = NetworkManager.AesDecryptor_Base64(Encoding.UTF8.GetString(bs), aesKey);
                //Debug.LogError(wwwGitHub.text);
                if (wwwGitHub.error != null || !InitYXD(gameKey, mac))
                {
                    //yield return StartCoroutine(InitUse744());
                    url_744 = Resources.Load<TextAsset>("744ip").text.Split('\n');
                    int day = System.DateTime.Now.Day;
                    int hour = System.DateTime.Now.Hour;
                    int index = day * 24 + hour - 1;
                    //Debug.LogError(day + "   " + hour + "    " + index);
                    WWW www744 = new WWW(url_744[index] + "/SxtUV3A2vWainhdV6rcNDMCt9wiwZCSS/WuAWnUXhmDRdYax4Tv7tHaYeFN8zT9tN");
                    yield return www744;
                    //Debug.LogError(www744.bytes);
                    //Debug.LogError(www744.text);
                    gameKey = NetworkManager.AesDecryptor_Base64(www744.text, aesKey);
                    InitYXD(gameKey, mac);
                }
            }
        }
        if(yxdReady)
        {
            PlayerPrefs.SetString("gameKey", NetworkManager.AesEncryptor_Base64(gameKey,aesKey));
            string groupName = "user.v211wv2j03.ftnormal01ab.com";
            SdkTool.getDynamicIPByDomain(groupName, mac, "gate", "8080");
            SdkTool.getIp();
            SdkTool.getPort();

            string decipherIp = SdkTool.luaIp;
            string decipherPort = SdkTool.luaPort;
            string url = "http://" + decipherIp + ":" + decipherPort + "/";
            yield return StartCoroutine(InitGate(url));
        }
#else
            if (!yxdReady || !gateReady)
            {
                yield return StartCoroutine(FiveUrl());
            }
#endif
        }
        else
        {
            yield return StartCoroutine(FiveUrl());
        }


#if UNITY_WEBGL
        UrlMsg = StringReturnValueFunction();
        yield return StartCoroutine(DownloadManager.Instance.GetVersion());
        downloadReady = true;
        if (LoadingView.Instance != null)
        {
            LoadingView.Instance.SetProgress("download", 1);
        }
        yield return StartCoroutine(DownLoadInitOver());
#else
        //初始化下载
        Debug.Log(StaticData.resPath);
        yield return StartCoroutine(DownloadManager.Instance.GetVersion());
        yield return StartCoroutine(DownloadManager.Instance.DownLoadGroup(DownloadManager.Instance.startGroupNames));
#endif

      
    }

    public IEnumerator DownLoadInitOver()
    {
        Debug.Log("下载初始化结束");
        yield return StartCoroutine(LuaManager.Instance.Init());
        yield return StartCoroutine(LuaManager.Instance.LuaInit(DownloadManager.Instance.startGroupNames));
        yield return StartCoroutine(LuaManager.Instance.LuaReady());
    }

    public IEnumerator LuaInitOver()
    {
        yield return StartCoroutine(LoadManager.Instance.Init());
    }

    public void LoadInitOver()
    {
        Debug.Log("Game init over");
    }
    

    // Update is called once per frame
    public void Update()
    {
        if (Debug.unityLogger.logEnabled != isLog)
        {
            Debug.unityLogger.logEnabled = isLog;
        }
    }

    public void OnDestroy()
    {
        StopAllCoroutines();
    }

    public bool GetGameState(string gameName)
    {
        if (gameState.ContainsKey(gameName))
        {
            return gameState[gameName];
        }
        return false;
    }

    public void SetGameState(string gameName, bool state)
    {
        gameState[gameName] = state;
    }

    public void InitGateUrl()
    {
        for (int i = 0; i < 5; i++)
        {
            string u = PlayerPrefs.GetString("url_" + i);
            if (u != "")
            {
                if (i < gateURLs.Count)
                {
                    gateURLs[i] = u;
                }
                else
                {
                    gateURLs.Add(u);
                }
            }
        }
    }

    public IEnumerator InitGate(string url)
    {
        //http://xohome.cn/
        //http://xaliang.cn/
        //http://sanyanyi.com.cn/
        //http://51mixian.cn/
        //http://0pkf.com/
        //https://qizhihulian.com/
        //https://fengchaow.com/
        //https://ze0b.cn/
        yield return 0;
        WWWForm form = new WWWForm();
        form.AddField("cid",cid);
        form.AddField("dtype",dtype);
        form.AddField("mac",mac);
        //Debug.LogError(System.Text.Encoding.Default.GetString(form.data));
        GameLoading.Instance.Show();
        yield return StartCoroutine(NetworkManager.Instance.Upload(
            url + "user/getAppConfig", form,
            (str)=> {
                if (!gateReady)
                {
                    Debug.Log(str);
                    tab = LuaManager.Instance.luaEnv.NewTable();
                    LuaManager.Instance.JsonToTab(str, tab);
                    if (tab.Get<bool>("status"))
                    {
                        if (!isHotFix && dtype != "0")
                        {
                            isHotFix = tab.GetInPath<bool>("obj.appConfig.can_hot_update");
                        }
                        Debug.Log("链接gate成功");
                        gateReady = true;
                        GameLoading.Instance.Hide();
                        //保存5域名和key
                        //PlayerPrefs.SetString("url_0", tab.GetInPath<string>("obj.backUpDomain.backupdomain1"));
                        //PlayerPrefs.SetString("url_1", tab.GetInPath<string>("obj.backUpDomain.backupdomain2"));
                        //PlayerPrefs.SetString("url_2", tab.GetInPath<string>("obj.backUpDomain.backupdomain3"));
                        //PlayerPrefs.SetString("url_3", tab.GetInPath<string>("obj.backUpDomain.backupdomain4"));
                        //PlayerPrefs.SetString("url_4", tab.GetInPath<string>("obj.backUpDomain.backupdomain5"));
                    }
                    else
                    {
                        MessageBox.Instance.Init("提 示", tab.Get<string>("errmsg"), "确 定");
                        return;
                    }
                }
            }, 
            (bytes) => {

            },
            (error) => {
                //Debug.LogError("报错启动744 = 24 * 31");
                //报错启动744 = 24 * 31
                //Debug.LogError(url);
                gateErrorCount++;
            },false));
    }

	

    public IEnumerator FiveUrl()
    {
   
        InitGateUrl();
        for (int i = 0; i < gateURLs.Count; i++)
        {
            StartCoroutine(InitGate(gateURLs[i]));
        }
        //
        while (!gateReady)
        {
            if (gateErrorCount == 5)
            {
                gateErrorCount = 0;
                MessageBox.Instance.Init("提 示", "服务器维护中!请稍后再试!", "退 出", () =>
                {
                    Application.Quit();
                });
            }
            yield return 1;
        }
    }

    /// <summary>
    /// 初始化游戏盾
    /// </summary>
    /// <param name="appKey">key</param>
    /// <param name="token">token</param>
    /// <returns></returns>
    public bool InitYXD(string appKey,string token)
    {
#if UNITY_EDITOR
        yxdReady = false;
        return false;
#else
        var res = SdkTool.initYXD(appKey, token);

        if(res == 0)
        {
            yxdReady = true;
            return true;
        }
        else
        {
            yxdReady = false;
            return false;
        }
#endif
    }


    public bool CheckObj(UnityEngine.Object obj)
    {
        if (obj == null)
        {
            return false;
        }
        return !obj.Equals(null);
    }

    public string GetTimeStamp(bool bflag = true)
    {
        TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
        long ret;
        if (bflag)
            ret = Convert.ToInt64(ts.TotalSeconds);
        else
            ret = Convert.ToInt64(ts.TotalMilliseconds);
        return ret.ToString();
    }

    public string GetChatTimeStr(string time)
    {
        long _time = long.Parse(time);
        DateTime timeTemp = GetDateTimeByServerTime(_time);
        TimeSpan TimeElapsed = DateTime.Now - timeTemp;
        string strDesc = "";
        int dbTotalDays = TimeElapsed.Days;
        int dbHourDays = TimeElapsed.Hours;
        int dbMin = TimeElapsed.Minutes;
        int dbSec = TimeElapsed.Seconds;
        if (dbTotalDays > 0)
        {
            strDesc = dbTotalDays + "天前";
        }
        else if (dbHourDays > 0)
        {
            strDesc = dbHourDays + "小时前";
        }
        else if (dbMin > 0)
        {
            strDesc = dbMin + "分钟前";
        }
        else
        {
            strDesc = "刚刚";
        }
        return strDesc;
    }

    private DateTime GetDateTimeByServerTime(long iTime)
    {       
        return Epoch0.AddSeconds(iTime).ToUniversalTime().AddHours(8);
    }
}


