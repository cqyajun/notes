﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using XLua;

[LuaCallCSharp]
public class GameEventManager : MonoBehaviour
{

    public enum EventType
    {
        Normal = 1,
        Socket = 2,
        State = 3,
    }


    private static GameEventManager instance;
    public static GameEventManager Instance
    {
        get
        {
            return instance;
        }
    }

    [CSharpCallLua]
    public delegate void DelegateEvent(int id, params object[] msgs);
    public Dictionary<EventType, List<DelegateEvent>> delegateMap = new Dictionary<EventType, List<DelegateEvent>>();
    private LuaTable normalTab = null;
    private LuaTable stateTab = null;
    void Awake()
    {
        instance = this;
        GameObject.DontDestroyOnLoad(this.gameObject);
    }

    void Start()
    {

    }


    /// <summary>
    /// 注册消息
    /// </summary>
    /// <param name="type">消息类型</param>
    /// <param name="callback">回调函数</param>
    public void RegisterEvent(EventType type, DelegateEvent callback)
    {

        if (!delegateMap.ContainsKey(type))
        {
            delegateMap.Add(type, new List<DelegateEvent>());
        }
        delegateMap[type].Add(callback);
    }

    /// <summary>
    /// 反注册消息
    /// </summary>
    /// <param name="type">消息类型</param>
    /// <param name="callback">回调函数</param>
    public void UnRegisterEvent(EventType type, DelegateEvent callback)
    {
        if (!delegateMap.ContainsKey(type))
        {
            delegateMap.Add(type, new List<DelegateEvent>());
        }
        delegateMap[type].Remove(callback);
    }

    /// <summary>
    /// 消息触发
    /// </summary>
    /// <param name="type">消息类型</param>
    /// <param name="id">消息id</param>
    /// <param name="message">消息</param>
    public void EventCallback(EventType type, int id, params object[] msgs)
    {
        if (delegateMap.ContainsKey(type))
        {
            for (int i = 0; i < delegateMap[type].Count; i++)
            {
                if (delegateMap[type][i] != null)
                {
                    delegateMap[type][i](id, msgs);
                }
                else
                {
                    delegateMap[type].RemoveAt(i);
                    i--;
                }
            }

        }
    }

    /// <summary>
    /// 消息触发
    /// </summary>
    /// <param name="type">消息类型</param>
    /// <param name="id">消息id</param>
    /// <param name="message">消息</param>
    public void EventCallback(EventType type, string strID, params object[] msgs)
    {
        if (delegateMap.ContainsKey(type))
        {
            int id = GetNormalMsgId(strID);
            for (int i = 0; i < delegateMap[type].Count; i++)
            {
                if (delegateMap[type][i] != null)
                {
                    delegateMap[type][i](id, msgs);
                }
                else
                {
                    delegateMap[type].RemoveAt(i);
                    i--;
                }
            }

        }
    }

    /// <summary>
    /// 获取基本消息id
    /// </summary>
    public int GetNormalMsgId(string key)
    {
        if (normalTab == null)
        {
            LuaManager.Instance.DoFile("LuaData/normalid");
            normalTab = LuaManager.Instance.GetLuaTable("normalid");
        }
        if(normalTab == null)
        {
            Debug.Log("normalid null");
        }
        try
        {
            return normalTab.Get<int>(key);
        }
        catch
        {
            Debug.LogError("没有消息id = " + key);
            return -1;
        }
    }


}