﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using XLua;

[LuaCallCSharp]
public class SceneLoadManager : MonoBehaviour
{
    static SceneLoadManager instance;
    public static SceneLoadManager Instance
    {
        get { return instance; }
    }

    private AsyncOperation ao = null;       //场景加载进度（纯场景，非对象池）
    private AssetBundle ab = null;          //场景ab包

    void Awake()
    {
        instance = this;
        GameObject.DontDestroyOnLoad(this.gameObject);
    }

    // Use this for initialization
    void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (ao != null)
        {
            LoadingView.Instance.SetProgress("SceneLoading", ao.progress);
            if (ao.progress == 1)
            {
                ao = null;
            }
        }
    }

    public void ChangeScene(string group, string sceneName, Action callback)
    {
        StartCoroutine(SceneLoading(group, sceneName, callback));
    }

    /// <summary>
    /// 切换场景
    /// </summary>
    public IEnumerator SceneLoading(string group, string sceneName, Action callback)
    {
        if (GameMaster.Instance.isHotFix)
        {
#if UNITY_WEBGL
        LoadingView.Instance.SetProgress("SceneLoading", 0);
        yield return 1;
        ao = SceneManager.LoadSceneAsync(sceneName);
        yield return ao;
        if (callback != null)
        {
            callback();
        }
#else
            LuaTable resTab = LoadManager.Instance.GetTableMsg(group);
            if (resTab == null)
            {
                yield break;
            }
            LuaTable tab = resTab.Get<LuaTable>(sceneName);
            if (tab == null)
            {
                Debug.LogWarning("热更资源中找不到场景，除非内置了场景，否则报错 " + sceneName);
                LoadingView.Instance.SetProgress("SceneLoading", 0);
                yield return 1;
                ao = SceneManager.LoadSceneAsync(sceneName);
                yield return ao;
                if (callback != null)
                {
                    callback();
                }
            }
            else
            {
                if (ab != null)
                {
                    ab.Unload(true);
                }

                ab = AssetBundle.LoadFromFile(StaticData.resPath + "/" + tab.Get<string>("path"));
                LoadingView.Instance.SetProgress("SceneLoading", 0);
                yield return 1;
                ao = SceneManager.LoadSceneAsync(sceneName);
                yield return ao;
                if (callback != null)
                {
                    callback();
                }
            }
#endif
            yield return new WaitForEndOfFrame();
        }
        else
        {
            LoadingView.Instance.SetProgress("SceneLoading", 0);
            yield return 1;
            ao = SceneManager.LoadSceneAsync(sceneName);
            yield return ao;
            if (callback != null)
            {
                callback();
            }
        }

    }
}
