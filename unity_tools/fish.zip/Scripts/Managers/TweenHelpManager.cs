﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;
using DG.Tweening;
using System;
using Spine.Unity;

[LuaCallCSharp]
public class TweenHelpManager : MonoBehaviour
{
    private int totalTime = 0;
    private Action invokeAction = null;
    private static TweenHelpManager instance = null;
    public static TweenHelpManager Instance
    {
        get
        {
            return instance;
        }
    }

    void Start()
    {
        instance = this;
        GameObject.DontDestroyOnLoad(this.gameObject);
    }

    public void ObjMoveLocalY(GameObject obj, float yPos, float time)
    {
        obj.transform.DOLocalMoveY(yPos, time);
    }

    public void ObjDOLocalMove(GameObject obj, GameObject objArea, float time)
    {
        float _time = UnityEngine.Random.Range(time - 0.2f, time + 0.2f);
        RectTransform rect = objArea.GetComponent<RectTransform>();
        float _x = UnityEngine.Random.Range(-0.5f * rect.rect.width + 20, 0.5f * rect.rect.width - 20);
        float _y = UnityEngine.Random.Range(-0.5f * rect.rect.height + 20, 0.5f * rect.rect.height - 20);
        //Debug.LogError(_x + "   " + _y + "   " + objArea.transform.position);
        obj.transform.DOLocalMove(new Vector3(_x, _y, 0), _time);
    }

    public void ObjDoLocalMovePos(GameObject obj, GameObject objArea, float time,float offect)
    {
        if (offect != 0)
        {
            //float _time = UnityEngine.Random.Range(time - 0.2f, time + 0.2f);
            //RectTransform rect = objArea.GetComponent<RectTransform>();
            float _x = UnityEngine.Random.Range(objArea.transform.localPosition.x - offect, objArea.transform.localPosition.x + offect);
            float _y = UnityEngine.Random.Range(objArea.transform.localPosition.y - offect, objArea.transform.localPosition.y + offect);
            //Debug.LogError(_x + "   " + _y + "   " + objArea.transform.position);
            obj.transform.DOLocalMove(new Vector3(_x, _y, 0), time).SetEase(Ease.OutFlash);
        }else
        {
            obj.transform.DOLocalMove(objArea.transform.localPosition, time).SetEase(Ease.OutFlash).OnComplete(()=> {
                obj.SetActive(false);
            });
        }
    }

    public void ObjDoScale(GameObject obj, float time)
    {
        obj.transform.DOScale(Vector3.one, time);
    }

    public void DoInvoke(int _time, Action callBack)
    {        
        totalTime = _time;       
        invokeAction = callBack;
        InvokeRepeating("RunInvoke", 1, 1);
    }

    private void RunInvoke()
    {
        totalTime = totalTime - 1;
        if (invokeAction != null)
        {
            invokeAction();            
        }
        if (totalTime == 0)
        {
            StopInvoke();
        }
    }

    public void StopInvoke()
    {
        CancelInvoke("RunInvoke");
        invokeAction = null;
    }

    public void PlaySpine(GameObject obj,string aniName)
    {
        obj.SetActive(true);
        obj.GetComponent<SkeletonGraphic>().AnimationState.SetAnimation(0, aniName, false);
    }

    public void SetCardMatial(GameObject obj, Material mat)
    {
        //Debug.LogError(obj.transform.GetChild(0).name);
        //Debug.LogError(mat.name);
        Material[] m = { mat };
        obj.transform.GetChild(0).GetComponent<MeshRenderer>().materials = m;
    }

    void OnDestroy()
    {
        StopInvoke();
    }
}
