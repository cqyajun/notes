﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using XLua;

[LuaCallCSharp]
public class SocketClient
{
    public const int Message = 0;     //消息
    public const int Connect = -1;     //连接服务器
    public const int Exception = -2;     //异常掉线
    public const int Disconnect = -3;     //正常断线   
    
    public string socketName;
    public int flag;    //flag^0xF0F0 = hh[0],hh[1],hh_0,hh_1
    public string idType;
    private TcpClient client = null;
    private NetworkStream outStream = null;
    private MemoryStream memStream;
    private BinaryReader reader;

    private const int MAX_READ = 8192;
    private byte[] byteBuffer = new byte[MAX_READ];

    public SocketClient()
    {
    }

    /// <summary>
    /// 注册代理
    /// </summary>
    public void OnRegister()
    {
        memStream = new MemoryStream();
        reader = new BinaryReader(memStream);
    }

    /// <summary>
    /// 连接服务器
    /// </summary>
    public void ConnectServer(string host, int port)
    {
        Debug.LogWarning("连接服务器"+ socketName + ":" + host + "  " + port);
        client = null;
        client = new TcpClient();
        client.SendTimeout = 1000;
        client.ReceiveTimeout = 1000;
        client.NoDelay = true;
        try
        {
            client.BeginConnect(host, port, new AsyncCallback(OnConnect), null);
        }
        catch (Exception e)
        {
            Close();
            Debug.LogError(e.Message);
        }
    }

    /// <summary>
    /// 连接服务器
    /// </summary>
    public void ConnectServerIPAddress(IPAddress host, int port)
    {
        Debug.LogWarning("连接服务器" + socketName + ":" + host + "  " + port);
        client = null;
        client = new TcpClient();
        client.SendTimeout = 1000;
        client.ReceiveTimeout = 1000;
        client.NoDelay = true;
        try
        {
            client.BeginConnect(host, port, new AsyncCallback(OnConnect), null);
        }
        catch (Exception e)
        {
            Close();
            Debug.LogError(e.Message);
        }
    }

    /// <summary>
    /// 连接上服务器
    /// </summary>
    void OnConnect(IAsyncResult asr)
    {
        Debug.LogWarning("连接上服务器" + socketName);
        if (client.Connected)
        {
            outStream = client.GetStream();
            client.GetStream().BeginRead(byteBuffer, 0, MAX_READ, new AsyncCallback(OnRead), null);
            NetworkManager.Instance.AddEvent(socketName, Connect, null);
        }
        else
        {
            OnDisconnected(Exception, "链接失败");
        }
    }

    /// <summary>
    /// 写数据
    /// </summary>
    public void WriteMessage(int id, byte[] msg)
    {
        MemoryStream ms = null;
        using (ms = new MemoryStream())
        {
            ms.Position = 0;
            BinaryWriter writer = new BinaryWriter(ms);
            if (msg != null)
            {
                int msgLength = msg.Length + 4;
                byte[] hh = new byte[4];
                hh[0] = (byte)((flag ^0xF0F0) / 1000);
                hh[1] = (byte)((flag ^ 0xF0F0) / 100 % 10);
                hh[2] = (byte)(msgLength >> 8);
                hh[3] = (byte)msgLength;
                //Debug.Log("发送协议：id = " + id + " msgLength = " + msgLength);
                writer.Write(hh);
                writer.Write(msg);
            }
            writer.Flush();
            if (client != null && client.Connected)
            {
                byte[] data = ms.ToArray();
                outStream.BeginWrite(data, 0, data.Length, new AsyncCallback(OnWrite), null);
            }
            else
            {
                Debug.LogError("client.connected----->>false");
                OnDisconnected(Exception, "已断线");
            }
        }
    }

    

    /// <summary>
    /// 向链接写入数据流
    /// </summary>
    void OnWrite(IAsyncResult r)
    {
        try
        {
            outStream.EndWrite(r);
        }
        catch (Exception ex)
        {
            Debug.LogError("OnWrite--->>>" + ex.Message);
        }
    }


    /// <summary>
    /// 读取消息
    /// </summary>
    void OnRead(IAsyncResult asr)
    {
        int bytesRead = 0;
        if (client.Connected)
        {
            try
            {
                lock (client.GetStream())
                {         //读取字节流到缓冲区
                    bytesRead = client.GetStream().EndRead(asr);
                }
                if (bytesRead < 1)
                {                //包尺寸有问题，断线处理
                    OnDisconnected(Disconnect, "bytesRead < 1");
                    return;
                }
                OnReceive(byteBuffer, bytesRead);   //分析数据包内容，抛给逻辑层
                lock (client.GetStream())
                {         //分析完，再次监听服务器发过来的新消息
                    Array.Clear(byteBuffer, 0, byteBuffer.Length);   //清空数组
                    client.GetStream().BeginRead(byteBuffer, 0, MAX_READ, new AsyncCallback(OnRead), null);
                }
            }
            catch (Exception ex)
            {
                OnDisconnected(Exception, ex.Message);
            }
        }
    }

    /// <summary>
    /// 接收到消息
    /// </summary>
    void OnReceive(byte[] bytes, int length)
    {
        memStream.Seek(0, SeekOrigin.End);
        memStream.Write(bytes, 0, length);
        //Reset to beginning
        memStream.Seek(0, SeekOrigin.Begin);
        while (RemainingBytes() > 4)
        {
            int hh_0 = reader.ReadByte();
            int hh_1 = reader.ReadByte();
            if (hh_0 == ((flag ^ 0xF0F0) / 10 % 10) && hh_1 == ((flag ^ 0xF0F0) % 10))
            {
                int hh_2 = reader.ReadByte();
                int hh_3 = reader.ReadByte();

                int messageLen = (hh_2 << 8) + hh_3;
                //Debug.LogError(hh_0 + " : " + hh_1 + " : " + messageLen + " : " + RemainingBytes());
               

                if (RemainingBytes() >= messageLen - 4)
                {
                    MemoryStream ms = new MemoryStream();
                    BinaryWriter writer = new BinaryWriter(ms);
                    writer.Write(reader.ReadBytes(messageLen - 4));
                    ms.Seek(0, SeekOrigin.Begin);
                    OnReceivedMessage(ms);
                }
                else
                {
                    //Back up the position two bytes
                    memStream.Position = memStream.Position - 4;
                    break;
                }
            }
            else
            {
                Debug.LogError("脏数据" + hh_0 + "  " + hh_1);
                break;
            }
        }
        //Create a new stream with any leftover bytes
        byte[] leftover = reader.ReadBytes((int)RemainingBytes());
        memStream.SetLength(0);     //Clear
        memStream.Write(leftover, 0, leftover.Length);
    }

    /// <summary>
    /// 剩余的字节
    /// </summary>
    private long RemainingBytes()
    {
        return memStream.Length - memStream.Position;
    }

    /// <summary>
    /// 丢失链接
    /// </summary>
    void OnDisconnected(int id, string msg)
    {
        Close();   //关掉客户端链接
        NetworkManager.Instance.AddEvent(socketName, id, null);
        Debug.LogWarning("断开链接：" + msg + " Distype:>" + id + "=====" + socketName);
    }

    /// <summary>
    /// 接收到消息
    /// </summary>
    /// <param name="ms"></param>
    void OnReceivedMessage(MemoryStream ms)
    {
        BinaryReader r = new BinaryReader(ms);
        //byte[] message = r.ReadBytes((int)(ms.Length - ms.Position));
        NetworkManager.Instance.AddEvent(socketName, Message, r);
    }


    /// <summary>
    /// 关闭链接
    /// </summary>
    public void Close()
    {
        if (client != null)
        {
            if (client.Connected) client.Close();
            client = null;
        }
    }


    public void LuaInvoke()
    {
        LuaManager.Instance.CallFunction(socketName + ".KeepAlive");
    }
}
