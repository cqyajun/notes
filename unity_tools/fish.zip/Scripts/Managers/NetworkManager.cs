﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Security.Cryptography;
using System.Net;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;
using UnityWebSocket;
using XLua;

[LuaCallCSharp]
public class NetMsg
{
    public string socketName;
    public int id;
    public object msg;
}


[LuaCallCSharp]
public class NetworkManager : MonoBehaviour
{
    private static NetworkManager instance;
    public static NetworkManager Instance
    {
        get
        {
            return instance;
        }
    }
#if UNITY_WEBGL
    public Dictionary<string, WebSocketClient> sockets = new Dictionary<string, WebSocketClient>();
#else
    public Dictionary<string, SocketClient> sockets = new Dictionary<string, SocketClient>();
#endif
    public Queue<NetMsg> netMsgs = new Queue<NetMsg>();
    public bool isEncrypt;
    public string key;
    private SymmetricAlgorithm mCSP = new TripleDESCryptoServiceProvider();

    void Awake()
    {
        instance = this;
        GameObject.DontDestroyOnLoad(this.gameObject);
    }

    public void AddSocket(string socketName, int flag)
    {
        if (!sockets.ContainsKey(socketName))
        {
#if UNITY_WEBGL
            WebSocketClient wsc = new WebSocketClient();
            wsc.socketName = socketName;
            wsc.flag = flag;
            wsc.OnRegister();
            sockets[socketName] = wsc;
#else
            SocketClient sc = new SocketClient();
            sc.socketName = socketName;
            sc.flag = flag;
            sc.OnRegister();
            sockets[socketName] = sc;
#endif
        }
    }

    public void DelSocket(string socketName)
    {
        if(sockets.ContainsKey(socketName) && sockets[socketName] != null)
        {
            sockets[socketName].Close();
        }
        sockets.Remove(socketName);
    }
    
    void FixedUpdate()
    {
        while (netMsgs.Count > 0)
        {
            NetMsg _event = netMsgs.Dequeue();
            if (LuaManager.Instance != null && _event != null)
            {
                LuaManager.Instance.CallFunction("SocketEventCallBack", _event.socketName, _event.id, _event.msg);
            }
        }
        
    }

    void OnDestroy()
    {
        foreach (var item in sockets)
        {
            item.Value.Close();
        }
    }

    /// <summary>
    /// 发送链接请求
    /// </summary>
    public void SendConnect(string socketName, string ip, int port)
    {
        sockets[socketName].ConnectServer(ip, port);
    }


    /// <summary>
    /// 发送链接请求
    /// </summary>
    public void SendConnectIPAddress(string socketName, int data, int port)
    {
#if UNITY_WEBGL
        Debug.LogError("web can not connect");
#else
        IPAddress ip = new IPAddress(data);
        sockets[socketName].ConnectServerIPAddress(ip, port);
#endif
    }


    /// <summary>
    /// 发送SOCKET消息
    /// </summary>
    public void SendMessage(string socketName, int id, byte[] msg)
    {
        if (sockets.ContainsKey(socketName))
        {
            sockets[socketName].WriteMessage(id, msg);
        }
    }


    public object GetReader(byte[] msg)
    {
        MemoryStream ms = new MemoryStream();
        BinaryWriter writer = new BinaryWriter(ms);
        writer.Write(msg);
        ms.Seek(0, SeekOrigin.Begin);
        BinaryReader r = new BinaryReader(ms);
        return r;
    }

    public void AddEvent(string socketName, int id, object msg)
    {
        NetMsg nm = new NetMsg();
        nm.socketName = socketName;
        nm.id = id;
        nm.msg = msg;
        netMsgs.Enqueue(nm);
    }


#if UNITY_WEBGL
    public WebSocketClient GetSocket(string n)
    {
        if (sockets.ContainsKey(n))
        {
            return sockets[n];
        }
        return null;
    }
#else
    public SocketClient GetSocket(string n)
    {
        if (sockets.ContainsKey(n))
        {
            return sockets[n];
        }
        return null;
    }
#endif

    public void CallWWW(string url, WWWForm form = null, byte[] postData = null, Dictionary<string, string> headers = null, Action<object> callBack = null)
    {
        StartCoroutine(CallingWWW(url, form, postData, headers, callBack));
    }

    IEnumerator CallingWWW(string url, WWWForm form = null, byte[] postData = null, Dictionary<string, string> headers = null, Action<object> callBack = null)
    {
        if (form == null && postData == null)
        {
            WWW www = new WWW(url);
            yield return www;
            callBack(www);
        }
        else if (form != null)
        {
            WWW www = new WWW(url, form);
            yield return www;
            callBack(www);
        }
        else if (postData != null && headers != null)
        {
            WWW www = new WWW(url, postData, headers);
            yield return www;
            callBack(www);
        }
        else if (postData != null)
        {
            WWW www = new WWW(url, postData);
            yield return www;
            callBack(www);
        }
    }

    //http || https
    public void PostForm(string url, WWWForm form, Action<string> strCallback = null, Action<byte[]> bytesCallback = null, Action<string> errorCallback = null)
    {
        StartCoroutine(Upload(url, form, strCallback, bytesCallback, errorCallback));
    }


    public void PostTab(string url, LuaTable tab, Action<string> strCallback = null, Action<byte[]> bytesCallback = null, Action<string> errorCallback = null)
    {
        WWWForm form = new WWWForm();
        tab.ForEach<string, string>((k,v) =>
        {
            form.AddField(k, v);            
        });
        StartCoroutine(Upload(url, form, strCallback, bytesCallback, errorCallback));
    }

    public IEnumerator Upload(string url, WWWForm form, Action<string> strCallback = null, Action<byte[]> bytesCallback = null, Action<string> errorCallback = null, bool useLoading = true)
    {
        if (isEncrypt)
        {
            string data = UrlEncode(AesEncryptor_Base64(System.Text.Encoding.Default.GetString(form.data), key));
            long timestamp = GetTimeStamp();
            string generateStr = RandomStr();
            string sign = MD5EncryptString(data + timestamp + generateStr + key);
            WWWForm eForm = new WWWForm();
            eForm.AddField("data", data);
            eForm.AddField("sign", sign);
            eForm.AddField("timestamp", timestamp.ToString());
            eForm.AddField("generateStr", generateStr);
            using (UnityWebRequest www = UnityWebRequest.Post(url, eForm))
            {
                if (useLoading)
                {
                    GameLoading.Instance.Show();
                }
                yield return www.SendWebRequest();
                if (useLoading)
                {
                    GameLoading.Instance.Hide();
                }
                if (www.isNetworkError || www.isHttpError)
                {
                    Debug.Log(url);
                    Debug.Log(www.error);
                    if (errorCallback != null)
                    {
                        errorCallback(www.error);
                    }
                }
                else
                {
                    string val = AesDecryptor_Base64(www.downloadHandler.text, key);
                    if (strCallback != null)
                    {
                        strCallback(val);
                    }
                    if (bytesCallback != null)
                    {
                        bytesCallback(www.downloadHandler.data);
                    }
                }
            }
        }
        else
        {
            using (UnityWebRequest www = UnityWebRequest.Post(url, form))
            {
                if (useLoading)
                {
                    GameLoading.Instance.Show();
                }
                yield return www.SendWebRequest();
                if (useLoading)
                {
                    GameLoading.Instance.Hide();
                }
                if (www.isNetworkError || www.isHttpError)
                {
                    Debug.Log(url);
                    Debug.Log(www.error);
                    if (errorCallback != null)
                    {
                        errorCallback(www.error);
                    }
                }
                else
                {
                    if (strCallback != null)
                    {
                        strCallback(www.downloadHandler.text);
                    }
                    if (bytesCallback != null)
                    {
                        bytesCallback(www.downloadHandler.data);
                    }
                }
            }
        }
    }

    

    /// <summary>
    /// AES 算法加密(ECB模式) 将明文加密，加密后进行base64编码，返回密文
    /// </summary>
    /// <param name="EncryptStr">明文</param>
    /// <param name="Key">密钥</param>
    /// <returns>加密后base64编码的密文</returns>
    public static string AesEncryptor_Base64(string EncryptStr, string Key)
    {
        try
        {
            byte[] keyArray = Encoding.UTF8.GetBytes(Key);
            //byte[] keyArray = Convert.FromBase64String(Key);
            byte[] toEncryptArray = Encoding.UTF8.GetBytes(EncryptStr);

            RijndaelManaged rDel = new RijndaelManaged();
            rDel.Key = keyArray;
            rDel.Mode = CipherMode.ECB;
            rDel.Padding = PaddingMode.PKCS7;

            ICryptoTransform cTransform = rDel.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            string resultArrayAfter = Convert.ToBase64String(resultArray, 0, resultArray.Length);
            resultArrayAfter = resultArrayAfter.Replace("+", "%2B");
            
            return resultArrayAfter;
        }
        catch (Exception ex)
        {
            return null;
        }
    }

    /// <summary>
    /// AES 算法解密(ECB模式) 将密文base64解码进行解密，返回明文
    /// </summary>
    /// <param name="DecryptStr">密文</param>
    /// <param name="Key">密钥</param>
    /// <returns>明文</returns>
    public static string AesDecryptor_Base64(string DecryptStr, string Key)
    {
        try
        {
            DecryptStr = DecryptStr.Replace("%2B", "+");
            byte[] keyArray = Encoding.UTF8.GetBytes(Key);
            //byte[] keyArray = Convert.FromBase64String(Key);
            byte[] toEncryptArray = Convert.FromBase64String(DecryptStr);

            RijndaelManaged rDel = new RijndaelManaged();
            rDel.Key = keyArray;
            rDel.Mode = CipherMode.ECB;
            rDel.Padding = PaddingMode.PKCS7;

            ICryptoTransform cTransform = rDel.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

            return Encoding.UTF8.GetString(resultArray);//  UTF8Encoding.UTF8.GetString(resultArray);
        }
        catch (Exception ex)
        {
            return null;
        }
    }

    public static string MD5EncryptString(string str)
    {
        MD5 md5 = MD5.Create();
        // 将字符串转换成字节数组
        byte[] byteOld = Encoding.UTF8.GetBytes(str);
        // 调用加密方法
        byte[] byteNew = md5.ComputeHash(byteOld);
        // 将加密结果转换为字符串
        StringBuilder sb = new StringBuilder();
        foreach (byte b in byteNew)
        {
            // 将字节转换成16进制表示的字符串，
            sb.Append(b.ToString("x2"));
        }
        // 返回加密的字符串
        return sb.ToString();
    }

    public static string UrlEncode(string str)
    {
        StringBuilder sb = new StringBuilder();
        byte[] byStr = System.Text.Encoding.UTF8.GetBytes(str); //默认是System.Text.Encoding.Default.GetBytes(str)
        for (int i = 0; i < byStr.Length; i++)
        {
            sb.Append(@"%" + Convert.ToString(byStr[i], 16));
        }

        return (sb.ToString());
    }

    /// 获取当前时间戳
    /// </summary>
    /// <param name="bflag">为真时获取10位时间戳,为假时获取13位时间戳.</param>
    /// <returns></returns>
    public static long GetTimeStamp(bool bflag = false)
    {
        TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
        long ret;
        if (bflag)
            ret = Convert.ToInt64(ts.TotalSeconds);
        else
            ret = Convert.ToInt64(ts.TotalMilliseconds);
        return ret;
    }

    public static string RandomStr()
    {
        Guid g = Guid.NewGuid();
        string GuidString = Convert.ToBase64String(g.ToByteArray());
        GuidString = GuidString.Replace("=", "");
        GuidString = GuidString.Replace("+", "");
        return GuidString.Substring(0,16);
    }
}
