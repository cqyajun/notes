﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;

[LuaCallCSharp]
public class LoadManager : MonoBehaviour
{
    public static LoadManager Instance
    {
        get { return instance; }
    }
    static LoadManager instance;

    bool isUnload;
    public AssetBundleManifest manifest;
    public Dictionary<string, LuaTable> resTabs = new Dictionary<string, LuaTable>();
    public Dictionary<string, List<string>> groups = new Dictionary<string, List<string>>();
    public Dictionary<string, AssetBundle> abs = new Dictionary<string, AssetBundle>();
    public Dictionary<string, int> abNum = new Dictionary<string, int>();
    //public bool loadReady;
    void Awake()
    {
        instance = this;
        GameObject.DontDestroyOnLoad(this.gameObject);
    }

    void Start()
    {
        
    }


    public IEnumerator Init()
    {
        if (GameMaster.Instance.isHotFix)
        {
#if UNITY_WEBGL
            string path = StaticData.resPath + "StreamingAssets";
            WWW www = new WWW(@path);
            yield return www;
            AssetBundle manifestBundle = www.assetBundle;
            if (manifestBundle != null)
            {
                manifest = (AssetBundleManifest)manifestBundle.LoadAsset("AssetBundleManifest");
                manifestBundle.Unload(false);
            }
#else

            string path = StaticData.resPath + "/server_res/StreamingAssets";
            AssetBundle manifestBundle = AssetBundle.LoadFromFile(path);
            manifest = (AssetBundleManifest)manifestBundle.LoadAsset("AssetBundleManifest");
            manifestBundle.Unload(false);
#endif
        }
        GameMaster.Instance.loadReady = true;
        GameMaster.Instance.LoadInitOver();
        yield return 0;
    }

    public void SetTableMsg(string group, LuaTable resTable)
    {
        resTabs[group] = resTable;
    }

    public LuaTable GetTableMsg(string group)
    {
        if (resTabs.ContainsKey(group))
        {
            return resTabs[group];
        }
        else
        {
            Debug.LogError("没有资源配置表 : " + group);
            return null;
        }
    }

    public UnityEngine.Object Load(string resName, string group, Type type = null)
    {
        try
        {
            LuaTable resTab = GetTableMsg(group);
            if (resTab == null)
            {
                return null;
            }
            LuaTable tab = resTab.Get<LuaTable>(resName);
            if(tab == null)
            {
                Debug.LogError("资源配置表没有该资源" + resName + " group = " + group);
                return null;
            }

            if (!groups.ContainsKey(group))
            {
                groups[group] = new List<string>();
            }
            if (!groups[group].Contains(resName))
            {
                groups[group].Add(resName);
            }
            string id = tab.Get<string>("id");
            string path = tab.Get<string>("path");
            bool isLocal = tab.Get<bool>("isLocal");
            if (isLocal)
            {
                if (type == null)
                {
                    return Resources.Load(path);
                }
                else
                {
                    return Resources.Load(path, type);
                }
            }
            else
            {
                if (GameMaster.Instance.isHotFix)
                {
                    if (!abs.ContainsKey(path))
                    {
                        //加载AB资源
                        string[] depends = manifest.GetAllDependencies(path);
                        for (int i = 0; i < depends.Length; i++)
                        {
                            if (!abs.ContainsKey(depends[i]))
                            {
                                AssetBundle subAB = AssetBundle.LoadFromFile(StaticData.resPath + "/" + depends[i]);
                                if (subAB == null)
                                {
                                    Debug.LogError("没有加载到ab包：" + StaticData.resPath + "/" + depends[i]);
                                    return null;
                                }
                                abs[depends[i]] = subAB;
                                abNum[depends[i]] = 0;
                            }
                            abNum[depends[i]]++;
                        }

                        AssetBundle ab = AssetBundle.LoadFromFile(StaticData.resPath + "/" + path);
                        if (ab == null)
                        {
                            Debug.LogError("没有加载到ab包：" + StaticData.resPath + "/" + path);
                            return null;
                        }
                        abs[path] = ab;
                        abNum[path] = 1;
                    }
                    if (type == null)
                    {
                        return abs[path].LoadAsset(id);
                    }
                    else
                    {
                        return abs[path].LoadAsset(id, type);
                    }
                }
                return null;
            }
        }
        catch(Exception)
        {
            Debug.LogError("下载失败" + name);
            return null;
        }
    }

    public IEnumerator LoadAsync(string resName, string group, Type type = null, Action<UnityEngine.Object> callback = null)
    {

        LuaTable resTab = GetTableMsg(group);
        if (resTab == null)
        {
            Debug.LogError("resTab == null");
            yield break;
        }
        LuaTable tab = resTab.Get<LuaTable>(resName);
        if (tab == null)
        {
            Debug.LogError("资源配置表没有该资源" + resName);
            yield break;
        }

        if (!groups.ContainsKey(group))
        {
            groups[group] = new List<string>();
        }
        if (!groups[group].Contains(resName))
        {
            groups[group].Add(resName);
        }
        string id = tab.Get<string>("id");
        string path = tab.Get<string>("path");
        bool isLocal = tab.Get<bool>("isLocal");
        if (isLocal)
        {
            if (type == null)
            {
                //return Resources.Load(path);
                ResourceRequest rr = Resources.LoadAsync(path);
                yield return rr;
                if (rr == null)
                {
                    Debug.LogError("加载失败" + path);
                    yield break;
                }
                if (callback != null)
                {
                    callback(rr.asset);
                }
            }
            else
            {
                //return Resources.Load(path, type);
                ResourceRequest rr = Resources.LoadAsync(path, type);
                yield return rr;
                if (rr == null)
                {
                    Debug.LogError("加载失败" + path);
                    yield break;
                }
                if (callback != null)
                {
                    callback(rr.asset);
                }
            }
        }
        else
        {
            if (GameMaster.Instance.isHotFix)
            {
                if (!abs.ContainsKey(path))
                {
                    //加载AB资源
                    string[] depends = manifest.GetAllDependencies(path);
                    for (int i = 0; i < depends.Length; i++)
                    {
                        if (!abs.ContainsKey(depends[i]))
                        {
                            AssetBundle subAB = AssetBundle.LoadFromFile(StaticData.resPath + "/" + depends[i]);
                            if (subAB == null)
                            {
                                Debug.LogError("没有加载到ab包：" + StaticData.resPath + "/" + depends[i]);
                                yield break;
                            }
                            abs[depends[i]] = subAB;
                            abNum[depends[i]] = 0;
                        }
                        abNum[depends[i]]++;
                    }

                    AssetBundle ab = AssetBundle.LoadFromFile(StaticData.resPath + "/" + path);
                    if (ab == null)
                    {
                        Debug.LogError("没有加载到ab包：" + StaticData.resPath + "/" + path);
                        yield break;
                    }
                    abs[path] = ab;
                    abNum[path] = 1;
                }
                if (type == null)
                {
                    //return abs[path].LoadAsset(id);
                    AssetBundleRequest abr = abs[path].LoadAssetAsync(id);
                    yield return abr;
                    if (abr == null)
                    {
                        Debug.LogError("加载失败" + path);
                        yield break;
                    }
                    if (callback != null)
                    {
                        callback(abr.asset);
                    }
                }
                else
                {
                    //return abs[path].LoadAsset(id, type);
                    AssetBundleRequest abr = abs[path].LoadAssetAsync(id, type);
                    yield return abr;
                    if (abr == null)
                    {
                        Debug.LogError("加载失败" + path);
                        yield break;
                    }
                    if (callback != null)
                    {
                        callback(abr.asset);
                    }
                }
            }
        }
    }

    public void UnLoadGroup(string group)
    {
        LuaTable resTab = GetTableMsg(group);
        if (resTab == null)
        {
            return;
        }
        if (groups.ContainsKey(group))
        {
            for (int i = 0; i < groups[group].Count; i++)
            {
                string resName = groups[group][i];
                LuaTable tab = resTab.Get<LuaTable>(resName);
                string id = tab.Get<string>("id");
                string path = tab.Get<string>("path");
                bool isLocal = tab.Get<bool>("isLocal");
                if (isLocal)
                {
                    UnityEngine.Object obj = Resources.Load(path);
                    if (obj.GetType() == typeof(GameObject))
                    {
                        isUnload = true;
                    }
                    else
                    {
                        Resources.UnloadAsset(obj);
                    }
                }
                else
                {
                    //删除ab资源
                    if (abs.ContainsKey(path))
                    {
                        string[] depends = manifest.GetAllDependencies(path);
                        for (int j = 0; j < depends.Length; j++)
                        {
                            if (abs.ContainsKey(depends[j]))
                            {
                                abNum[depends[j]]--;
                                if (abNum[depends[j]] <= 0)
                                {
                                    abs[depends[j]].Unload(true);
                                    abs.Remove(depends[j]);
                                    abNum.Remove(depends[j]);
                                }
                            }
                        }

                        abNum[path]--;
                        if (abNum[path] <= 0)
                        {
                            abs[path].Unload(true);
                            abs.Remove(path);
                            abNum.Remove(path);
                        }
                    }
                }
            }
            groups.Remove(group);
        }
    }


    void CheckUnload()
    {
        if (isUnload)
        {
            isUnload = false;
            Resources.UnloadUnusedAssets();
        }
    }
}
