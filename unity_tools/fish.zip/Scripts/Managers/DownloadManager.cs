﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using UnityEngine;
using UnityEngine.UI;
using XLua;

[LuaCallCSharp]
public class DownloadManager : MonoBehaviour
{
    private static DownloadManager instance = null;
    public static DownloadManager Instance
    {
        get
        {
            return instance;
        }
    }

    private List<DownLoadFileUnit> m_downLoadList = new List<DownLoadFileUnit>();       // 下载资源列表
    private bool m_downloadSuccess = false;                                             // 是否下载成功
    private long m_downloadSize = 0;                                                    // 下载总大小
    private long m_curDownloadSize = 0;                                                 // 当前下载大小
    private SHA1Managed sha1 = new SHA1Managed();                                       // hash获取
    private Dictionary<string, long> m_downloadGroupsSize = new Dictionary<string, long>(); //下载各组资源总大小
    private Dictionary<string, long> m_currentGroupsSize = new Dictionary<string, long>(); //当前下载各组资源总大小
    private Dictionary<string, Dictionary<string, string>> localMsgDic = new Dictionary<string, Dictionary<string, string>>();
    //public string download_root = "";
    public List<string> startGroupNames = new List<string>();
    public string luaName = "";
    public Dictionary<string, Action<float>> downloadGroupCallBack = new Dictionary<string, Action<float>>();
    public LuaTable tabVersion;
    //public string groups;
    //public bool resReady = false;

    void Awake()
    {
        instance = this;
        GameObject.DontDestroyOnLoad(this.gameObject);
    }
    // Use this for initialization
    void Start()
    {
    }


    public IEnumerator GetVersion()
    {
        yield return 0;
        string url = "";
        if (SdkTool.useSdk)
        {
            string groupName = "user.v211wv2j03.ftnormal01ab.com";
            SdkTool.getDynamicIPByDomain(groupName, GameMaster.Instance.mac, "user", "80");
            SdkTool.getIp();
            SdkTool.getPort();
            url = "http://" + SdkTool.luaIp + ":" + SdkTool.luaPort + "/";
        }
        else
        {
            url = GameMaster.Instance.tab.GetInPath<string>("obj.appConfig.user_url");
        }

        WWWForm form = new WWWForm();
        form.AddField("cid", GameMaster.Instance.cid);
        form.AddField("dtype", GameMaster.Instance.dtype);
        form.AddField("mac", GameMaster.Instance.mac);
        yield return StartCoroutine(NetworkManager.Instance.Upload(
            url + "user/getAppVersion", form,
            (str) => {
                tabVersion = LuaManager.Instance.luaEnv.NewTable();
                LuaManager.Instance.JsonToTab(str, tabVersion);
                //Debug.LogError(str);
                if (tabVersion.Get<bool>("status"))
                {
                    Debug.Log("获取版本成功");

                }
                else
                {
                    MessageBox.Instance.Init("提 示", "网络状态不佳，请检查当前网络环境！", "重新连接", () =>
                    {
                        StartCoroutine(GetVersion());
                    });
                }

            },
            (bytes) => {

            },
            (error) => {
                MessageBox.Instance.Init("提 示", error, "重新连接", () =>
                {
                    StartCoroutine(GetVersion());
                });
            }));
    }


    public string GetURL(string group)
    {
        return GameMaster.Instance.tab.GetInPath<string>("obj.appConfig.update_url") +
#if UNITY_WEBGL
        "WEB/version_" + 
#elif UNITY_ANDROID
        "Android/version_" +
#elif UNITY_IOS
        "IOS/version_" + 
#endif
        tabVersion.GetInPath<string>("obj.appVersion." + group) + 
        "/" + group;
    }

    //检查是否正在下载
    public bool CheckIsDownLoadGroup(string groupName)
    {
        if(m_downloadGroupsSize.ContainsKey(groupName) && 
            m_currentGroupsSize.ContainsKey(groupName) &&
            m_currentGroupsSize[groupName] < m_downloadGroupsSize[groupName])
        {
            return true;
        }
        return false;
    }

    //替换回调
    public void ChangeDownloadCallback(string groupName, Action<float> dgCallback)
    {
        downloadGroupCallBack[groupName] = dgCallback;
    }

    public IEnumerator CheckDownLoadGroup(string groupName, Action<bool> callBack = null)
    {
        if (GameMaster.Instance.isHotFix)
        {
            while (tabVersion == null)
            {
                yield return 1;
            }
            if (groupName != "")
            {

                WWW www = new WWW(GetURL(groupName) + ".ver.txt" + "?timestamp = " + System.DateTime.Now.Ticks.ToString());
                GameLoading.Instance.Show();
                yield return www;
                GameLoading.Instance.Hide();
                if (www.error == null && www.text != "")
                {
                    GetLocalGroupMsg(groupName);
                    string[] serverMsgs = www.text.Split('\n', '\t');
                    for (int j = 1; j < serverMsgs.Length; j++)
                    {
                        string[] subMsg = serverMsgs[j].Split('|', '@');

                        if (subMsg[0] != string.Empty)
                        {
                            if ((localMsgDic.ContainsKey(groupName) &&
                                localMsgDic[groupName].ContainsKey(subMsg[0]) &&
                                serverMsgs[j] == localMsgDic[groupName][subMsg[0]]))
                            {
                                //Debug.Log("有这个资源 = " + subMsg[0]);
                            }
                            else
                            {
                                Debug.Log("需要更新资源 = " + subMsg[0]);
                                www.Dispose();
                                if (callBack != null)
                                {
                                    callBack(true);
                                    yield break;
                                }
                            }
                        }
                    }
                }
                www.Dispose();
                if (callBack != null)
                {
                    callBack(false);
                }
            }

        }
        else
        {
            if (callBack != null)
            {
                callBack(false);
            }
        }
    }

    public IEnumerator DownLoadGroup(List<string> groupNames, Action<float> dgCallback = null)
    {
        if (GameMaster.Instance.isHotFix)
        {
            m_curDownloadSize = 0;
            while (tabVersion == null)
            {
                yield return 1;
            }
            if(dgCallback != null)
            {
                for (int i = 0; i < groupNames.Count; i++)
                {
                    downloadGroupCallBack[groupNames[i]] = dgCallback;
                }
            }
            groupNames.Add("server_res");
       
            for (int i = 0; i < groupNames.Count; i++)
            {
                if (groupNames[i] != "")
                {
                    Debug.LogError(GetURL(groupNames[i]));
                    WWW www = new WWW(GetURL(groupNames[i]) + ".ver.txt" + "?timestamp = " + System.DateTime.Now.Ticks.ToString());
                    yield return www;

                    if (www.error == null && www.text != "")
                    {
                        GetLocalGroupMsg(groupNames[i]);
                        string[] serverMsgs = www.text.Split('\n', '\t');
                        for (int j = 1; j < serverMsgs.Length; j++)
                        {
                            string[] subMsg = serverMsgs[j].Split('|', '@');

                            if (subMsg[0] != string.Empty)
                            {
                                if ((localMsgDic.ContainsKey(groupNames[i]) &&
                                    localMsgDic[groupNames[i]].ContainsKey(subMsg[0]) &&
                                    serverMsgs[j] == localMsgDic[groupNames[i]][subMsg[0]]))
                                {
                                    //Debug.Log("有这个资源 = " + subMsg[0]);
                                }
                                else
                                {
                                    DownLoadFileUnit unit = new DownLoadFileUnit(
                                    GetURL(groupNames[i]) + "/" + subMsg[0] + "?timestamp = " + System.DateTime.Now.Ticks.ToString(),
                                    subMsg[0],
                                    groupNames[i],
                                    StaticData.resPath + "/" + groupNames[i] + "/" + subMsg[0],
                                    subMsg[1],
                                    Convert.ToInt64(subMsg[2]),
                                    serverMsgs[j]);
                                    m_downLoadList.Add(unit);
                                    m_downloadSize += unit.Length;
                                    if (!m_downloadGroupsSize.ContainsKey(groupNames[i]))
                                    {
                                        m_downloadGroupsSize[groupNames[i]] = unit.Length;
                                        m_currentGroupsSize[groupNames[i]] = 0;
                                    }
                                    else
                                    {
                                        m_downloadGroupsSize[groupNames[i]] += unit.Length;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        Debug.LogError("加载配置文件出错" + GetURL(groupNames[i]) + ".ver.txt");
                        //StartCoroutine(DownLoadGroup(groupNames));
                        //弹框提示加载配置文件出错
                        MessageBox.Instance.Init("提 示", "网络状态不佳，请检查当前网络环境！", "继续下载", () =>
                        {
                            StartCoroutine(DownLoadGroup(groupNames, dgCallback));
                        }, "中止下载");
                        yield break;
                    }
                }
            }
        }
        if (m_downLoadList.Count > 0)
        {
            StartCoroutine(StartDownLoad());
        }
        else
        {
            Debug.Log(groupNames + "已经是最新资源");
            localMsgDic.Clear();
            if (groupNames.Contains(startGroupNames[0]) && groupNames.Contains(startGroupNames[1]))
            {
                GameMaster.Instance.downloadReady = true;
                yield return StartCoroutine(GameMaster.Instance.DownLoadInitOver());
            }
            else
            {
                if (LuaManager.Instance != null)
                {
                    LuaManager.Instance.CallFunction("NormalEventCallBack", luaName, groupNames, this);
                }
            }
            if (LoadingView.Instance != null)
            {
                LoadingView.Instance.SetProgress("download", 1);
            }
            if(dgCallback != null)
            {
                dgCallback(1);
            }
        }
    }

    
    public void GetLocalGroupMsg(string groupName)
    {
        string p = Path.Combine(StaticData.resPath + "/", groupName + ".ver.txt");
        string localVersionMsg = string.Empty;
        if (File.Exists(p))
        {
            localVersionMsg = File.ReadAllText(p, Encoding.UTF8);
            string[] localMsgs = localVersionMsg.Split('\n', '\t');
            for (int i = 1; i < localMsgs.Length; i++)
            {
                string[] subMsg = localMsgs[i].Split('|', '@');
                if (subMsg[0] != string.Empty)
                {
                    if(!localMsgDic.ContainsKey(groupName))
                    {
                        localMsgDic[groupName] = new Dictionary<string, string>();
                    }

                    localMsgDic[groupName][subMsg[0]] = localMsgs[i];
                }
            }
        }
    }

    /// <summary>
    /// 开始下载
    /// </summary>
    public IEnumerator StartDownLoad()
    {
        DefaultWebRequestManager.Instance.SetDownloadEvent(
            WebRequestSuccess, UpdateWebRequestProgress, WebRequestFailure, OneFileDownloadSuccess);
        DefaultWebRequestManager.Instance.Requests(m_downLoadList);
        while (!m_downloadSuccess)
        {
            yield return null;
        }
    }

    /// <summary>
    /// 文件下载成功
    /// </summary>
    private void OneFileDownloadSuccess(DownLoadFileUnit unit)
    {
        if (!localMsgDic.ContainsKey(unit.GroupName))
        {
            localMsgDic[unit.GroupName] = new Dictionary<string, string>();
        }
        localMsgDic[unit.GroupName][unit.FileName] = unit.Msg;
        m_curDownloadSize += unit.Length;
        if (m_currentGroupsSize.ContainsKey(unit.GroupName))
        {
            m_currentGroupsSize[unit.GroupName] += unit.Length;
        }
        //if (downloadGroupCallBack.ContainsKey(unit.GroupName))
        //{
        //    downloadGroupCallBack[unit.GroupName]((float)m_currentGroupsSize[unit.GroupName] / (float)m_downloadGroupsSize[unit.GroupName]);
        //}
    }

    

    /// <summary>
    //下载完成
    /// </summary>
    private void WebRequestSuccess()
    {
        m_downloadSuccess = true;
        foreach (var group in localMsgDic)
        {
            string fileMsg = "\n";
            foreach (var msg in group.Value)
            {
                fileMsg += msg.Value + "\n";
            }
            string p = Path.Combine(StaticData.resPath + "/", group.Key + ".ver.txt");
            using (var s = System.IO.File.Create(p))
            {
                byte[] b = System.Text.Encoding.UTF8.GetBytes(fileMsg);
                s.Write(b, 0, b.Length);
            }
            Debug.Log("下载完成group = " + group.Key);

            if (downloadGroupCallBack.ContainsKey(group.Key))
            {
                downloadGroupCallBack[group.Key](1);
                downloadGroupCallBack.Remove(group.Key);
            }
            if (m_downloadGroupsSize.ContainsKey(group.Key))
            {
                m_downloadGroupsSize.Remove(group.Key);
            }
            if (m_currentGroupsSize.ContainsKey(group.Key))
            {
                m_currentGroupsSize.Remove(group.Key);
            }
        }
        Debug.Log("所有资源下载完成");
        localMsgDic.Clear();
        m_downLoadList.Clear();
        if (LoadingView.Instance != null)
        {
            LoadingView.Instance.SetProgress("download", 1);
        }
        if (!GameMaster.Instance.downloadReady)
        {
            GameMaster.Instance.downloadReady = true;
            GameMaster.Instance.StartCoroutine(GameMaster.Instance.DownLoadInitOver());
        }
    }

    /// <summary>
    /// 更新下载进度
    /// </summary>
    public void UpdateWebRequestProgress(long size)
    {
        //Debug.LogFormat("{0}/{1}", FileManager.KBConversionMB(size), FileManager.KBConversionMB(m_downloadSize));
        if(LoadingView.Instance != null)
        {
            LoadingView.Instance.SetProgress("download", (float)size / (float)m_downloadSize);
        }
    }

    public void UpdateCurrentGroupDownload(string groupName, long size)
    {
        if(size == 0)
        {
            return;
        }
        if (downloadGroupCallBack.ContainsKey(groupName) && m_currentGroupsSize.ContainsKey(groupName))
        {
            if (((float)m_currentGroupsSize[groupName] + (float)size) < (float)m_downloadGroupsSize[groupName])
            {
                downloadGroupCallBack[groupName](((float)m_currentGroupsSize[groupName] + (float)size) / (float)m_downloadGroupsSize[groupName]);
            }
        }
    }

    /// <summary>
    /// 请求失败, 弹出请求重连对话框
    /// </summary>
    public void WebRequestFailure(WebReconnection webReconnection)
    {
        Debug.Log("请求失败");
        //todo:弹出网络连接失败，请求重连对话框
        if(Application.internetReachability == NetworkReachability.NotReachable)
        {
            MessageBox.Instance.Init("提示","网络连接中断！","重新连接",()=> {
                webReconnection.Reconnection();
            },"退出游戏",()=> {
                Application.Quit();
            });
        }
        else
        {
            MessageBox.Instance.Init("提示", "网络环境不佳，请检查网络！", "确 定", () => {
                webReconnection.Reconnection();
            });
        }
        
    }
}
