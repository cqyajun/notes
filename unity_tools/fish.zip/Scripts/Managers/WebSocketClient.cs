﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityWebSocket;

public class WebSocketClient
{
    public const int Message = 0;     //消息
    public const int Connect = -1;     //连接服务器
    public const int Exception = -2;     //异常掉线
    public const int Disconnect = -3;     //正常断线   

    public string socketName;
    public int flag;    //flag^0xF0F0 = hh[0],hh[1],hh_0,hh_1
    public string idType;

    private WebSocket socket = null;
    
    private MemoryStream memStream;
    private BinaryReader reader;

    private const int MAX_READ = 8192;
    private byte[] byteBuffer = new byte[MAX_READ];

    /// <summary>
    /// 注册代理
    /// </summary>
    public void OnRegister()
    {
        memStream = new MemoryStream();
        reader = new BinaryReader(memStream);
    }


    /// <summary>
    /// 连接服务器
    /// </summary>
    public void ConnectServer(string host, int port)
    {
        //string address = "wss://demos.kaazing.com/echo";
        string address = "ws://" + host + ":" + port;
        Debug.LogWarning("web连接服务器" + address);
        socket = new WebSocket(address);
        socket.onOpen += OnOpen;
        socket.onClose += OnClose;
        socket.onMessage += OnReceive;
        socket.onError += OnError;

        if (socket == null
                    || socket.readyState == WebSocketState.Open
                    || socket.readyState == WebSocketState.Closing)
            return;

        socket.ConnectAsync();
    }


    public void Close()
    {
        if (socket.readyState == WebSocketState.Connecting
            || socket.readyState == WebSocketState.Open)
        {
            socket.CloseAsync();
        }
    }

    

    /// <summary>
    /// 写数据
    /// </summary>
    public void WriteMessage(int id, byte[] msg)
    {
        
        MemoryStream ms = null;
        using (ms = new MemoryStream())
        {
            ms.Position = 0;
            BinaryWriter writer = new BinaryWriter(ms);
            if (msg != null)
            {
                int msgLength = msg.Length + 4;
                byte[] hh = new byte[4];
                hh[0] = (byte)((flag ^ 0xF0F0) / 1000);
                hh[1] = (byte)((flag ^ 0xF0F0) / 100 % 10);
                hh[2] = (byte)(msgLength >> 8);
                hh[3] = (byte)msgLength;
                
                writer.Write(hh);
                writer.Write(msg);
              
            }
            writer.Flush();
            if (socket != null && socket.readyState == WebSocketState.Open)
            {
                
                byte[] data = ms.ToArray();
                socket.Send(data);
            }
            else
            {
                Debug.LogError("client.connected----->>false");
            }
        }
    }

    public void SendCallBack(bool val)
    {
        Debug.LogWarning(val);
    }



    public void OnOpen(object sender, EventArgs e)
    {
        Debug.Log(socketName + "[INFO] Connected");
        NetworkManager.Instance.AddEvent(socketName, Connect, null);
    }

    public void OnClose(object sender, CloseEventArgs e)
    {
        if (e.statusCode != CloseStatusCode.NoStatus && e.statusCode != CloseStatusCode.Normal)
        {
            Debug.LogError(socketName + "[ERROR] " + e.Reason + " " + e.statusCode);
            NetworkManager.Instance.AddEvent(socketName, Exception, null);
        }
        else
        {
            Debug.Log("正常断线web socket = " + socketName);
            NetworkManager.Instance.AddEvent(socketName, Disconnect, null);
        }
    }

    public void OnReceive(object sender, MessageEventArgs e)
    {
        MemoryStream ms = new MemoryStream(e.RawData);
        BinaryReader reader = new BinaryReader(ms);
        int hh_0 = reader.ReadByte();
        int hh_1 = reader.ReadByte();
        if (hh_0 == ((flag ^ 0xF0F0) / 10 % 10) && hh_1 == ((flag ^ 0xF0F0) % 10))
        {
            int hh_2 = reader.ReadByte();
            int hh_3 = reader.ReadByte();
            int messageLen = (hh_2 << 8) + hh_3;
            if (RemainingBytes(ms) >= messageLen - 4)
            {
                MemoryStream subms = new MemoryStream(reader.ReadBytes((int)(ms.Length - ms.Position)));
                BinaryReader subreader = new BinaryReader(subms);
                NetworkManager.Instance.AddEvent(socketName, Message, subreader);
            }
            else
            {
                Debug.LogError("包尺寸有错");
            }
        }
        
    }


    /// <summary>
    /// 剩余的字节
    /// </summary>
    private long RemainingBytes(MemoryStream memStream)
    {
        return memStream.Length - memStream.Position;
    }

    public void OnError(object sender, UnityWebSocket.ErrorEventArgs e)
    {
        Debug.LogError("[ERROR] " + e.Message + "\n");
    }
}
