﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using XLua;

[LuaCallCSharp]
public class SoundManager : MonoBehaviour
{
    private static SoundManager instance = null;
    public static SoundManager Instance
    {
        get
        {
            return instance;
        }
    }
    public AudioSource[] audioSource;

    void Awake()
    {
        instance = this;
        DontDestroyOnLoad(this.gameObject);
    }
    // Use this for initialization
    void Start ()
    {

    } 
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnApplicationPause(bool pause)
    {
        audioSource[0].Play();
    }

    public void PlaySound(string soundName,string groupName)
    {
        AudioClip ac = LoadManager.Instance.Load(soundName, groupName, typeof(AudioClip)) as AudioClip;
        audioSource[1].PlayOneShot(ac);
    }

    public void PlaySound(AudioClip clip)
    {
        audioSource[1].clip = clip;
        audioSource[1].Play();
    }

    public void PlayBGM(string soundName, string group)
    {
        AudioClip ac = LoadManager.Instance.Load(soundName, group, typeof(AudioClip)) as AudioClip;
        audioSource[0].clip = ac;
        audioSource[0].Play();
    }


    public void CloseBGM()
    {
        audioSource[0].Stop();
    }


    public void SetBGMValue(float val)
    {
        audioSource[0].volume = val;
    }

    public void SetSoundValue(float val)
    {
        audioSource[1].volume = val;
    }

    public float GetBGMValue()
    {
        return audioSource[0].volume;
    }

    public float GetSoundValue()
    {
        return audioSource[1].volume;
    }
}
