﻿using UnityEngine;
using System.Collections;
using System;



public class WWWHelper : WebReconnection
{
    private string url;
    private WWW www;
    private bool isDone;
    private MonoBehaviour mono;
    private string strPost;
    private bool isRequest;
    private Action<WebReconnection> errorCallback;

    public WWWHelper(string url, MonoBehaviour mono, Action<WebReconnection> errorCallback)
    {
        this.url = url;
        isDone = false;
        isRequest = false;
        this.mono = mono;
        this.errorCallback = errorCallback;
        Start();
    }

    public void Start()
    {
        if (!isRequest)
        {
            this.mono.StartCoroutine(StartCoroutine());
        }
    }

    public void Reconnection()
    {
        Start();
    }

    public IEnumerator StartCoroutine()
    {
        isRequest = true;
        if (www != null)
        {
            www.Dispose();
            www = null;
        }
        if (!string.IsNullOrEmpty(this.strPost))
        {
            www = new WWW(url, System.Text.Encoding.Default.GetBytes(this.strPost));
        }
        else
        {
            www = new WWW(url);
        }
        yield return www;
        isRequest = false;
        if (www.error != null)
        {
            Debug.LogError(www.url);
            if (errorCallback != null)
            {
                errorCallback(this);
            }
        }
        else
        {
            isDone = true;
        }
    }

    public bool IsDone
    {
        get
        {
            return isDone;
        }
    }

    public void Dispose()
    {
        if (www != null)
        {
            www.Dispose();
        }
    }

    public string Text
    {
        get
        {
            if (www != null)
            {
                return www.text;
            }
            return string.Empty;
        }
    }

    public byte[] Bytes
    {
        get
        {
            if (www != null)
            {
                return www.bytes;
            }
            return null;
        }
    }

    public void Retry()
    {
        Start();
    }
}


