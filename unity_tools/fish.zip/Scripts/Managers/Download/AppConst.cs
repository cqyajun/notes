﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AppConst
{
    /// <summary>
    /// 自动重连次数
    /// </summary>
    public static int ReconnectionCount = 3; 

    /// <summary>
    /// 游戏名称
    /// </summary>
    public const string AppName = "xxxx";
     
    /// <summary>
    /// 下载代理数量
    /// </summary>
    public const int MAX_REQUEST = 4;
    
    /// <summary>
    /// 超时时间
    /// </summary>
    public const float TIME_OUT = 10f;

}