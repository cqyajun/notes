﻿using UnityEngine;
using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Security.Cryptography;

public class Util
{

    private static string m_downloadFolder;

    /// <summary>
    /// 下载文件保存目录
    /// </summary>
    public static string DownloadFolder
    {
        get
        {
            if(m_downloadFolder !=null)
            {
                return m_downloadFolder;
            }

            string game = AppConst.AppName;
            if (Application.isMobilePlatform)
            {
                m_downloadFolder = string.Format("{0}/{1}", Application.persistentDataPath, game);
            }
            else if (Application.platform == RuntimePlatform.OSXEditor)
            {
                int i = Application.dataPath.LastIndexOf('/');
                m_downloadFolder = Application.dataPath.Substring(0, i + 1) + game;
            }
            else
            {
                m_downloadFolder = string.Format("{0}/{1}", Application.persistentDataPath, game);//"c:/" + game;
            }

            return m_downloadFolder;
        }
    }
}