﻿using UnityEngine;
using System.Collections;
using System.Net;
using System;
using System.Threading;
using System.IO;

public interface WebReconnection
{
    void Reconnection();
}


