﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;


public static class FileManager
{
    const int GB = 1024 * 1024 * 1024;
    public const int MB = 1024 * 1024;
    const int KB = 1024;
    public static string KBConversionMB(float KSize)
    {
        if (KSize / GB >= 1)
            return (Math.Round(KSize / (float)GB, 2)).ToString("F2") + "GB";
        else if (KSize / MB >= 1)
            return (Math.Round(KSize / (float)MB, 2)).ToString("F2") + "MB";
        else if (KSize / KB >= 1)
            return (Math.Round(KSize / (float)KB, 2)).ToString("F2") + "KB";
        else
            return KSize.ToString("F2") + "Byte";
    }

    public static long FileLength(string path)
    {
        long size = 0;
        try
        {
            if (!string.IsNullOrEmpty(path) && File.Exists(path))
            {
                FileInfo fi = new FileInfo(path);
                size = fi.Length;
            }
        }
        catch (Exception ex)
        {
            Debug.Log(ex.Message);
        }
        return size;
    }
}
