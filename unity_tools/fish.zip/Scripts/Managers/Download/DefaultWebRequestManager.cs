﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class DefaultWebRequestManager : JunSingleInstance<DefaultWebRequestManager>, WebReconnection
{
    #region 变量
    /// <summary>
    /// 下载代理列表
    /// </summary>
    private List<DefaultWebRequestAgentHelpers> agentList;

    /// <summary>
    /// 当前重连次数
    /// </summary>
    private int curReconnectionCount = 0;

    /// <summary>
    /// 最后接收数据时间
    /// </summary>
    private float lastTime;

    /// <summary>
    /// 是否下载错误
    /// </summary>
    private bool isNetworkError;

    /// <summary>
    /// 下载成功数据
    /// </summary>
    private long successSize;

    /// <summary>
    /// 请求成功委托
    /// </summary>
    private Action WebRequestFinishEvent;

    /// <summary>
    /// 单个下载成功事件
    /// </summary>
    private Action<DownLoadFileUnit> DownloadSuccess;

    /// <summary>
    /// 请求进度更新委托
    /// </summary>
    private Action<long> UpdateWebRequestProgressEvent;

    /// <summary>
    /// 请求失败委托
    /// </summary>
    private Action<WebReconnection> WebRequestFailureEvent;

    /// <summary>
    /// 请求列表
    /// </summary>
    private List<DownLoadFileUnit> webRequestList;

    /// <summary>
    /// 最后请求索引
    /// </summary>
    private int lastWebRequestIndex = 0;

    /// <summary>
    /// 请求断开
    /// </summary>
    private bool webRequestDisconnect = false;
    #endregion

    #region 属性
    /// <summary>
    /// 获取当前下载大小
    /// </summary>
    public long GetCurDownloadSize
    {
        get
        {
            long v = successSize;
            for (int i = 0; i < agentList.Count; i++)
            {
                v += agentList[i].GetDownloadSize;
                DownloadManager.Instance.UpdateCurrentGroupDownload(agentList[i].downLoadFileUnit.GroupName, agentList[i].GetDownloadSize);
            }
            return v;
        }
    }
    #endregion

    #region 方法
    void Awake()
    {
        agentList = new List<DefaultWebRequestAgentHelpers>();
    }

    /// <summary>
    /// 检查是否有空闲下载代理
    /// </summary>
    public bool CheckFreeWebRequest()
    {
        return GetFreeWebRequest() != null;
    }

    /// <summary>
    /// 获取空闲代理
    /// </summary>
    public DefaultWebRequestAgentHelpers GetFreeWebRequest()
    {
        for (int i = 0; i < agentList.Count; i++)
        {
            if (!agentList[i].Run)
            {
                return agentList[i];
            }
        }

        if (agentList.Count < AppConst.MAX_REQUEST)
        {
            DefaultWebRequestAgentHelpers webRequest = new DefaultWebRequestAgentHelpers(WebRequestSuccessHandle, UpdateWebRequestProgressHandle, WebRequestFailureHandle);
            agentList.Add(webRequest);
            return webRequest;
        }
        return null;
    }


    public bool IsRun()
    {
        for (int i = 0; i < agentList.Count; i++)
        {
            if (agentList[i].Run)
            {
                return true;
            }
        }
        return false;
    }

    /// <summary>
    /// 下载成功回调
    /// </summary>
    public void WebRequestSuccessHandle(DownLoadFileUnit downLoadFileUnit)
    {
        this.successSize += downLoadFileUnit.Length;
        ResetReconnectionCount();
        if (this.DownloadSuccess != null)
        {
            this.DownloadSuccess(downLoadFileUnit);
        }
        if (!IsSuccess())
        {
            Check();
            return;
        }
        webRequestList = null;
        lastWebRequestIndex = 0;
        if (WebRequestFinishEvent != null)
        {
            WebRequestFinishEvent();
        }

        Clear();
    }

    /// <summary>
    /// 下载进度更新
    /// </summary>
    public void UpdateWebRequestProgressHandle()
    {
        UpdateLastTime();
        if (UpdateWebRequestProgressEvent != null)
        {
            UpdateWebRequestProgressEvent(GetCurDownloadSize);
        }
    }

    /// <summary>
    /// 重置重连次数
    /// </summary>
    public void ResetReconnectionCount()
    {
        curReconnectionCount = 0;
    }

    /// <summary>
    /// 下载错误回调
    /// </summary>
    public void WebRequestFailureHandle()
    {
        StopWebRequest();
        webRequestDisconnect = true;
        if (curReconnectionCount >AppConst.ReconnectionCount)
        {
            Reconnection();
        }
        else
        {
            ResetReconnectionCount();
            if (WebRequestFailureEvent != null)
            {
                WebRequestFailureEvent(this);
            }
        }
    }

    /// <summary>
    /// 重连
    /// </summary>
    public void Reconnection()
    {
        webRequestDisconnect = false;
        UpdateLastTime();
        curReconnectionCount++;
        for (int i = 0; i < agentList.Count; i++)
        {
            agentList[i].Reconnection();
        }
    }

    /// <summary>
    /// 停止所有下载代理脚本
    /// </summary>
    public void StopWebRequest()
    {
        for (int i = 0; i < agentList.Count; i++)
        {
            agentList[i].Dispose();
        }
    }

    /// <summary>
    /// 添加下载事件
    /// </summary>
    /// <param name="DownLoadSuccessEvent">下载成功事件</param>
    /// <param name="UpdateScheduleEvent">进度更新事件</param>
    /// <param name="DownloadErrorEvent">下载失败事件</param>
    /// <param name="DownloadSuccess">单个下载成功回调</param>
    public void SetDownloadEvent(
        Action WebRequestFinishEvent, 
        Action<long> UpdateWebRequestProgressEvent, 
        Action<WebReconnection> WebRequestFailureEvent, 
        Action<DownLoadFileUnit> DownloadSuccess)
    {
        this.WebRequestFinishEvent = WebRequestFinishEvent;
        this.UpdateWebRequestProgressEvent = UpdateWebRequestProgressEvent;
        this.WebRequestFailureEvent = WebRequestFailureEvent;
        this.DownloadSuccess = DownloadSuccess;
    }

    public void Requests(List<DownLoadFileUnit> webRequestList)
    {
        this.webRequestList = webRequestList;
        Check();
    }

    public void Check()
    {
        for (int i = lastWebRequestIndex; lastWebRequestIndex < webRequestList.Count; i++, lastWebRequestIndex++)
        {
            if (!CheckFreeWebRequest())
            {
                return;
            }
            DownLoadFileUnit downLoadUnit = webRequestList[lastWebRequestIndex];
            Request(downLoadUnit);
        }
    }

    /// <summary>
    /// 开始下载
    /// </summary>
    /// <param name="url">下载地址</param>
    /// <param name="path">保存目录</param>
    /// <param name="size">文件大小</param>
    /// <param name="success">下载成功回调</param>
    /// <param name="success">下载进度回调</param>
    /// <returns></returns>
    public bool Request(DownLoadFileUnit downLoadFileUnit)
    {
        if (string.IsNullOrEmpty(downLoadFileUnit.DownLoadUrl))
        {
            return false;
        }

        if (string.IsNullOrEmpty(downLoadFileUnit.FilePath))
        {
            return false;
        }

        if (!CheckFreeWebRequest())
        {
            return false;
        }

        DefaultWebRequestAgentHelpers webRequest = GetFreeWebRequest();
        webRequestDisconnect = false;
        UpdateLastTime();
        webRequest.Request(downLoadFileUnit);
        return true;
    }

    public bool IsSuccess()
    {
        if (webRequestList != null && lastWebRequestIndex < webRequestList.Count)
        {
            return false;
        }
        if (IsRun())
        {
            return false;
        }
        return true;
    }

    public void Update()
    {
        if (!IsWebRequest())
        {
            return;
        }

        if (webRequestDisconnect)
        {
            return;
        }

        if (CheckTimeOut())
        {
            return;
        }

        for (int i = 0; i < agentList.Count; i++)
        {
            agentList[i].Update();
        }
    }

    /// <summary>
    /// 判断是否是请求状态
    /// </summary>
    public bool IsWebRequest()
    {
        if (webRequestList != null)
        {
            return true;
        }
        return false;
    }

    /// <summary>
    /// 检测超时
    /// </summary>
    public bool CheckTimeOut()
    {
        if (Time.time - lastTime >AppConst.TIME_OUT)
        {
            for (int i = 0; i < agentList.Count; i++)
            {
                if (agentList[i].Run)
                {
                    Debug.LogError(agentList[i].RequestUrl);
                }
            }
            Debug.LogError("web request timeour url");
            WebRequestFailureHandle();
            return true;
        }
        return false;
    }

    /// <summary>
    /// 更新最后接收时间
    /// </summary>
    public void UpdateLastTime()
    {
        lastTime = Time.time;
    }

    public void Clear()
    {
        if (this.webRequestList!=null)
        {
            this.webRequestList.Clear();
        }
        curReconnectionCount = 0;
    }
    #endregion
}