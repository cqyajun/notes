﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using UnityEngine;

public class DefaultWebRequestAgentHelpers : WebReconnection
{
    #region 变量

    private WWW www;

    public DownLoadFileUnit downLoadFileUnit;

    /// <summary>
    /// 进度
    /// </summary>
    private float progress;

    /// <summary>
    /// 下载成功回调
    /// </summary>
    private Action success;

    /// <summary>
    /// 请求完成回调
    /// </summary>
    public Action<DownLoadFileUnit> WebRequestSuccessEvent;

    /// <summary>
    /// 请求错误回调
    /// </summary>
    public Action UpdateWebRequestProgressEvent;

    public Action WebRequestFailureEvent;

    private bool disposed = false;
    private SHA1Managed sha1 = new SHA1Managed();                                       //hash获取

    #endregion

    #region 属性
    public bool Run
    {
        get
        {
            return disposed;
        }
        set
        {
            disposed = value;
        }
    }

    public long GetDownloadSize
    {
        get
        {
            if (www != null)
            {
                return (long)(www.progress * 100) * downLoadFileUnit.Length / 100;
            }
            return 0;
        }
    }

    public string RequestUrl
    {
        get
        {
            return downLoadFileUnit.DownLoadUrl;
        }
    }
    #endregion

    #region 方法

    public DefaultWebRequestAgentHelpers(Action<DownLoadFileUnit> WebRequestSuccessEvent, Action UpdateWebRequestProgressEvent, Action WebRequestFailureEvent)
    {
        this.WebRequestSuccessEvent = WebRequestSuccessEvent;
        this.UpdateWebRequestProgressEvent = UpdateWebRequestProgressEvent;
        this.WebRequestFailureEvent = WebRequestFailureEvent;
    }

    /// <summary>
    /// 请求发送数据
    /// </summary>
    /// <param name="path">要发送的远程地址</param>
    /// <param name="path">资源保存路径</param>
    public void Request(DownLoadFileUnit downLoadFileUnit)
    {
        if (string.IsNullOrEmpty(downLoadFileUnit.DownLoadUrl))
        {
            return;
        }
        if (string.IsNullOrEmpty(downLoadFileUnit.FilePath))
        {
            return;
        }
        this.downLoadFileUnit = downLoadFileUnit;
        progress = 0;
        Run = true;
        www = new WWW(downLoadFileUnit.DownLoadUrl);
    }

    /// <summary>
    /// 重连
    /// </summary>
    public void Reconnection()
    {
        Request(this.downLoadFileUnit);
    }

    public void Dispose(bool state = false)
    {
        if (www != null)
        {
            www.Dispose();
            www = null;
        }
        if (state)
        {
            Run = false;
        }
    }

    public void Update()
    {
        if (www == null)
        {
            return;
        }

        if (progress != www.progress)
        {
            progress = www.progress;
            UpdateWebRequestProgressHandle();
        }
        if (!www.isDone && www.error == null)
        {
            return;
        }
        if (www.error != null || !Save())
        {
            if (www.error != null)
            {
                Debug.LogError("web request error:" + www.error + "  url:" + downLoadFileUnit.DownLoadUrl);
            }
            if (WebRequestFailureEvent != null)
            {
                WebRequestFailureEvent();
            }
        }
        else
        {
            Dispose(true);
            if (WebRequestSuccessEvent != null)
            {
                WebRequestSuccessEvent(downLoadFileUnit);
            }
        }

    }

    public void UpdateWebRequestProgressHandle()
    {
        if (this.UpdateWebRequestProgressEvent != null)
        {
            this.UpdateWebRequestProgressEvent();
        }
    }

    public bool Save()
    {
        try
        {
            if (string.IsNullOrEmpty(downLoadFileUnit.FilePath))
            {
                Debug.LogError("path is empty");
                return false;
            }

            if (www == null || www.bytes == null)
            {
                Debug.LogError("size is empty");
                return false;
            }
            string hash = Convert.ToBase64String(sha1.ComputeHash(www.bytes));
            if (hash != downLoadFileUnit.Hash)
            {
                Debug.LogError("hash is error");
                return false;
            }

            if (File.Exists(downLoadFileUnit.FilePath))
            {
                File.Delete(downLoadFileUnit.FilePath);
            }

            string directory = Path.GetDirectoryName(downLoadFileUnit.FilePath);
            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }

            File.WriteAllBytes(downLoadFileUnit.FilePath, www.bytes);



            return true;
        }
        catch (System.Exception ex)
        {
            Debug.LogError(ex.ToString() + this.RequestUrl);
            return false;
        }
    }
    #endregion
    
}