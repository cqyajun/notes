﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StaticData
{
#if UNITY_ANDROID
#if UNITY_EDITOR
    public static string luaABPath = Application.persistentDataPath;
    public static string resPath = Application.persistentDataPath;
    public static string ftpUrl = "http://192.168.10.65:9999/Android/";
#else
    public static string luaABPath = Application.persistentDataPath;
    public static string resPath = Application.persistentDataPath;
    public static string ftpUrl = "http://192.168.10.65:9999/Android/";
#endif
#elif UNITY_IPHONE
#if UNITY_EDITOR
    public static string luaABPath = Application.persistentDataPath;
    public static string resPath = Application.persistentDataPath;
    public static string ftpUrl = "http://192.168.12.176:9999/IOS/";
#else
    public static string luaABPath = Application.persistentDataPath;
    public static string resPath = Application.persistentDataPath;
    public static string ftpUrl = "http://192.168.12.176:9999/IOS/";
#endif
#elif UNITY_WEBGL
#if UNITY_EDITOR
    public static string luaABPath = Application.streamingAssetsPath.Replace("/", "//") + "//";
    public static string resPath = Application.streamingAssetsPath.Replace("/", "//") + "//";
    public static string ftpUrl = "http://47.75.60.40:8080/game_res/WEB/";
#else
    public static string luaABPath = Application.streamingAssetsPath.Replace("/","//") + "//";
    public static string resPath = Application.streamingAssetsPath.Replace("/","//") + "//";
    public static string ftpUrl = "http://47.75.60.40:8080/game_res/WEB/";
#endif
#endif
}
