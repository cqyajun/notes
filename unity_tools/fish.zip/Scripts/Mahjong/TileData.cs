﻿using System;
using UnityEngine;
using XLua;

namespace Mahjong
{
    /**
     * 
     * 麻将牌
     * 
     * */
    [LuaCallCSharp]
    public class TileData : MonoBehaviour
    {
        [HideInInspector]
        public LuaTable data = null; //  用于lua层数据交互
    }
}