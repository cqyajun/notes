﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;

namespace Mahjong
{

    [LuaCallCSharp]
    public class MahjongData : MonoBehaviour
    {
        // 正常的麻将材质球
        public Material[] normalTileMats;
        // 灰色的麻将材质球
        public Material[] glowTileMats;

    }
}
