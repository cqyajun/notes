﻿using UnityEngine;
using XLua;
using DG.Tweening;
namespace Mahjong
{
    /**
     * 
     * 
     * 
     * */
    [LuaCallCSharp]
    public class PlayerHand : MonoBehaviour
    {

        public GameObject tileObj = null;
        private LuaTable target = null;

        private System.Action<LuaTable> luaSort2_Start = null;
        private System.Action<LuaTable> luaSort2_PickUp = null;
        private System.Action<LuaTable> luaSort2_PutDown = null;
        private System.Action<LuaTable> luaSort2_End = null;

        private System.Action<LuaTable> luaPlay_Start = null;
        private System.Action<LuaTable> luaPlay_PickUp = null;
        private System.Action<LuaTable> luaPlay_PutDown = null;
        private System.Action<LuaTable> luaPlay_End = null;

        private System.Action<LuaTable> luaOver_Start = null;
        private System.Action<LuaTable> luaOver_PushToTile = null;
        private System.Action<LuaTable> luaOver_End = null;

        private System.Action<LuaTable> luaPressDice_Start = null;
        private System.Action<LuaTable> luaPressDice_Play = null;
        private System.Action<LuaTable> luaPressDice_End = null;

        private System.Action<LuaTable> luaChangeThree_Start = null;
        private System.Action<LuaTable> luaChangeThree_PutDown = null;
        private System.Action<LuaTable> luaChangeThree_End = null;

        private System.Action<LuaTable> luaSortMeld_Start = null;
        private System.Action<LuaTable> luaSortMeld_Move = null;
        private System.Action<LuaTable> luaSortMeld_End = null;

        private System.Action<LuaTable> luaHu_Start = null;
        private System.Action<LuaTable> luaHu_PutDown = null;
        private System.Action<LuaTable> luaHu_End = null;

        public void setTarget(LuaTable lua)
        {
            target = lua;
            luaSort2_Start = target.Get<System.Action<LuaTable>>("eventSort2_Start");
            luaSort2_PickUp = target.Get<System.Action<LuaTable>>("eventSort2_PickUp");
            luaSort2_PutDown = target.Get<System.Action<LuaTable>>("eventSort2_PutDown");
            luaSort2_End = target.Get<System.Action<LuaTable>>("eventSort2_End");

            luaPlay_Start = target.Get<System.Action<LuaTable>>("eventPlay_Start");
            luaPlay_PickUp = target.Get<System.Action<LuaTable>>("eventPlay_PickUp");
            luaPlay_PutDown = target.Get<System.Action<LuaTable>>("eventPlay_PutDown");
            luaPlay_End = target.Get<System.Action<LuaTable>>("eventPlay_End");

            luaOver_Start = target.Get<System.Action<LuaTable>>("eventOver_Start");
            luaOver_PushToTile = target.Get<System.Action<LuaTable>>("eventOver_PushToTile");
            luaOver_End = target.Get<System.Action<LuaTable>>("eventOver_End");

            luaPressDice_Start = target.Get<System.Action<LuaTable>>("eventPressDice_Start");
            luaPressDice_Play = target.Get<System.Action<LuaTable>>("eventPressDice_Play");
            luaPressDice_End = target.Get<System.Action<LuaTable>>("eventPressDice_End");

            luaChangeThree_Start = target.Get<System.Action<LuaTable>>("eventChangeThree_Start");
            luaChangeThree_PutDown = target.Get<System.Action<LuaTable>>("eventChangeThree_PutDown");
            luaChangeThree_End = target.Get<System.Action<LuaTable>>("eventChangeThree_End");

            luaSortMeld_Start = target.Get<System.Action<LuaTable>>("eventSortMeld_Start");
            luaSortMeld_Move = target.Get<System.Action<LuaTable>>("eventSortMeld_Move");
            luaSortMeld_End = target.Get<System.Action<LuaTable>>("eventSortMeld_End");

            luaHu_Start = target.Get<System.Action<LuaTable>>("eventHu_Start");
            luaHu_PutDown = target.Get<System.Action<LuaTable>>("eventHu_PutDown");
            luaHu_End = target.Get<System.Action<LuaTable>>("eventHu_End");
        }

        public virtual void OnDestroy()
        {
            target = null;
            luaSort2_Start = null;
            luaSort2_PickUp = null;
            luaSort2_PutDown = null;
            luaSort2_End = null;

            luaPlay_Start = null;
            luaPlay_PickUp = null;
            luaPlay_PutDown = null;
            luaPlay_End = null;

            luaOver_Start = null;
            luaOver_PushToTile = null;
            luaOver_End = null;

            luaPressDice_Start = null;
            luaPressDice_Play = null;
            luaPressDice_End = null;

            luaChangeThree_Start = null;
            luaChangeThree_PutDown = null;
            luaChangeThree_End = null;
        }

        /**
         * 整理牌动作-开始
         * 
         * */
        public void sort2_Start(){
            if (luaSort2_Start != null) {
                luaSort2_Start(target);
            }
        }

        /**
         * 整理牌动作-拿起牌
         * 
         * */
        public void sort2_PickUp(){
            if (luaSort2_PickUp != null){
                luaSort2_PickUp(target);
            }
        }

        /**
         * 整理牌动作-放下牌
         * 
         * */
        public void sort2_PutDown(){
            if (luaSort2_PutDown != null){
                luaSort2_PutDown(target);
            }
        }

        /**
         * 整理牌动作-结束
         * 
         * */
        public void sort2_End() {
            if (luaSort2_End != null){
                luaSort2_End(target);
            }
        }


        /**
         * 出牌动作-开始
         * 
         * */
        public void play_Start(){
            if (luaPlay_Start != null){
                luaPlay_Start(target);
            }
        }

        /**
         * 出牌动作-拿起牌
         * 
         * */
        public void play_PickUp(){
            if (luaPlay_PickUp != null) {
                luaPlay_PickUp(target);
            }
        }

        /**
         * 整理牌动作-放下牌
         * 
         * */
        public void play_PutDown(){
            if (luaPlay_PutDown != null) {
                luaPlay_PutDown(target);
            }
        }

        /**
         * 出牌动作-结束
         * 
         * */
        public void play_End(){
            if (luaPlay_End != null) {
                luaPlay_End(target);
            }
        }

        /**
         * 结束动作-开始
         * 
         * */
        public void over_Start(){
            if (luaOver_Start != null){
                luaOver_Start(target);
            }
        }

        public void over_PushToTile(){
            if (luaOver_PushToTile != null){
                luaOver_PushToTile(target);
            }
        }

        /**
         * 结束动作-结束
         * 
         * */
        public void over_End(){
            if (luaOver_End != null){
                luaOver_End(target);
            }
        }

        /**
        * 结束动作-开始
        * 
        * */
        public void pressDice_Start(){
            if (luaPressDice_Start != null){
                luaPressDice_Start(target);
            }
        }

        public void pressDice_Play(){
            if (luaPressDice_Play != null){
                luaPressDice_Play(target);
            }
        }

        /**
         * 结束动作-结束
         * 
         * */
        public void pressDice_End() {
            if (luaPressDice_End != null) {
                luaPressDice_End(target);
            }
        }

        /**
       * 放牌 换三张动作-开始
       * 
       * */
        public void changeThree_Start(){
            if (luaChangeThree_Start != null){
                luaChangeThree_Start(target);
            }
        }

        /**
         * 放牌 换三张动作-放牌
         * */
        public void changeThree_PutDown(){
            if (luaChangeThree_PutDown != null){
                luaChangeThree_PutDown(target);
            }
        }

        /**
         * 放牌 换三张动作-结束
         * */
        public void changeThree_End(){
            if (luaChangeThree_End != null){
                luaChangeThree_End(target);
            }
        }

        /**
       * 整理牌组-开始
       * 
       * */
        public void sortMeld_Start()
        {
            if (luaSortMeld_Start != null)
            {
                luaSortMeld_Start(target);
            }
        }

        /**
         * 放牌 换三张动作-放牌
         * */
        public void sortMeld_Move()
        {
            if (luaSortMeld_Move != null)
            {
                luaSortMeld_Move(target);
            }
        }

        /**
         * 放牌 换三张动作-结束
         * */
        public void sortMeld_End()
        {
            if (luaSortMeld_End != null)
            {
                luaSortMeld_End(target);
            }
        }

        /**
      * 胡-开始
      * 
      * */
        public void hu_Start()
        {
            if (luaHu_Start != null)
            {
                luaHu_Start(target);
            }
        }

        /**
         * 放牌 胡动作-放牌
         * */
        public void hu_PutDown()
        {
            if (luaHu_PutDown != null)
            {
                luaHu_PutDown(target);
            }
        }

        /**
         * 放牌 胡动作-结束
         * */
        public void hu_End()
        {
            if (luaHu_End != null)
            {
                luaHu_End(target);
            }
        }
    }
}