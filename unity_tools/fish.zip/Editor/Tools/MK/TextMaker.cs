﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.U2D;
using System.Text;

[CustomEditor(typeof(TextTool))]
public class TextMaker : Editor
{
    [MenuItem("Assets/MogenTools/TextMaker")]
    public static void GetTextUV()
    {
        Debug.Log("GetTextUV");
        Object[] arr = Selection.GetFiltered(typeof(Object), SelectionMode.Assets);
        string path = Application.dataPath.Substring(0, Application.dataPath.LastIndexOf('/')) + "/" + AssetDatabase.GetAssetPath(arr[0]);
        Object[] objs = AssetDatabase.LoadAllAssetsAtPath(AssetDatabase.GetAssetPath(arr[0]));
        Material m = (Material)AssetDatabase.LoadAssetAtPath(AssetDatabase.GetAssetPath(arr[0]).Replace("png", "mat"), typeof(Material));
        if (m == null)
        {
            m = new Material(Shader.Find("GUI/Text Shader"));
            m.mainTexture = (Texture)arr[0];
            ProjectWindowUtil.CreateAsset(m, arr[0].name + "_mat.mat");
        }
        Font font = (Font)AssetDatabase.LoadAssetAtPath(AssetDatabase.GetAssetPath(arr[0]).Replace("png", "fontsettings"), typeof(Font));
        if (font == null)
        {
            font = new Font(arr[0].name);
            ProjectWindowUtil.CreateAsset(font, arr[0].name + "_setting.fontsettings");
        }
        CharacterInfo[] cis = new CharacterInfo[objs.Length - 1];

        Vector2 vertSize = Vector2.zero;
        Vector2 vertPos = Vector2.zero;
        for (int i = 1; i < objs.Length; i++)
        {
            Sprite sp = (Sprite)objs[i];
            CharacterInfo ci = new CharacterInfo();
            ci.index = Encoding.ASCII.GetBytes(sp.name)[0];
            ci.uvBottomLeft = sp.uv[1];
            ci.uvBottomRight = sp.uv[0];
            ci.uvTopRight = sp.uv[3];
            ci.uvTopLeft = sp.uv[2];

            vertSize.x = (int)sp.rect.xMax - (int)sp.rect.xMin;
            vertSize.y = (int)sp.rect.yMax - (int)sp.rect.yMin;
            
            vertPos.x = 0;
            vertPos.y = vertSize.y / -2;
            ci.vert = new Rect(vertPos, vertSize);

            //ci.minX = 0;
            //ci.maxX = (int)sp.rect.xMax - (int)sp.rect.xMin;
            //ci.minY = 0;
            //ci.maxY = (int)sp.rect.yMax - (int)sp.rect.yMin;
            ci.advance = ci.maxX;
            cis[i - 1] = ci;
        }
        font.characterInfo = cis;
        font.material = m;
    }


    [MenuItem("Assets/MogenTools/TextMaker2")]
    public static void GetTextUV2()
    {
        Debug.Log("GetTextUV");
        Object[] arr = Selection.GetFiltered(typeof(Object), SelectionMode.Assets);
        string path = Application.dataPath.Substring(0, Application.dataPath.LastIndexOf('/')) + "/" + AssetDatabase.GetAssetPath(arr[0]);
        Object[] objs = AssetDatabase.LoadAllAssetsAtPath(AssetDatabase.GetAssetPath(arr[0]));
        //Material m = (Material)AssetDatabase.LoadAssetAtPath(AssetDatabase.GetAssetPath(arr[0]).Replace("png", "mat"), typeof(Material));
        //if (m == null)
        //{
        //    m = new Material(Shader.Find("GUI/Text Shader"));
        //    m.mainTexture = (Texture)arr[0];
        //    ProjectWindowUtil.CreateAsset(m, arr[0].name + "_mat.mat");
        //}
        Font font = (Font)AssetDatabase.LoadAssetAtPath(AssetDatabase.GetAssetPath(arr[0]).Replace(".png", "_setting.fontsettings"), typeof(Font));
        if (font == null)
        {
            Debug.LogError(AssetDatabase.GetAssetPath(arr[0]).Replace(".png", "_setting.fontsettings"));
            return;
        }
        Vector2 vertSize = Vector2.zero;
        Vector2 vertPos = Vector2.zero;
        CharacterInfo[] cis = font.characterInfo;
        for (int i = 1; i < objs.Length; i++)
        {
            Sprite sp = (Sprite)objs[i];
            CharacterInfo ci = cis[i - 1];
            //ci.vert = new Rect(Vector2.zero, new Vector2((int)sp.rect.xMax - (int)sp.rect.xMin, (int)sp.rect.yMax - (int)sp.rect.yMin));


            vertSize.x = (int)sp.rect.xMax - (int)sp.rect.xMin;
            vertSize.y = (int)sp.rect.yMax - (int)sp.rect.yMin;

            vertPos.x = 0;
            vertPos.y = vertSize.y / -2;
            ci.vert = new Rect(vertPos, vertSize);

            //Debug.LogError(ci.vert);
            //ci.minX = 0;
            //ci.maxX = (int)sp.rect.xMax - (int)sp.rect.xMin;
            //ci.minY = 0;
            //ci.maxY = (int)sp.rect.yMax - (int)sp.rect.yMin;
            ci.advance = ci.maxX;
            cis[i - 1] = ci;
        }
        font.characterInfo = cis;
        //font.material = m;
    }
}
