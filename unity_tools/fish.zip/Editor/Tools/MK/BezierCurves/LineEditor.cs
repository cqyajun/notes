﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;

[CustomEditor(typeof(Line))]
public class LineEditor : Editor
{

    Line line;
    public string LineFile = "line/";
    void OnEnable()
    {
        line = (Line)target;
    }

    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();
        LineFile = EditorGUILayout.TextField("Line Name", LineFile);
        if (GUILayout.Button("Create Line"))
        {
            string[] sub = LineFile.Split('/');
            string dir = "";
            for (int i = 0; i < sub.Length - 1; i++)
            {
                dir += sub[i] + "/";
            }
            Debug.Log(dir);
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }
            string str = line.MakeLuaData(LineFile.Replace("/", "_"));
            string strText = line.MakeTextData(LineFile.Replace("/", "_"));
            using (var s = System.IO.File.Create("Assets/XLua/Lua/by/LuaData/line_" + LineFile + ".lua"))
            {
                //UnityEngine.Debug.Log(str);
                byte[] data = System.Text.Encoding.UTF8.GetBytes(str);
                s.Write(data, 0, data.Length);
            }

            using (var s = System.IO.File.Create("Assets/../data/" + LineFile + ".dat"))
            {
                //UnityEngine.Debug.Log(str);
                byte[] data = System.Text.Encoding.Default.GetBytes(strText);
                s.Write(data, 0, data.Length);
            }

            if (line != null)
            {
                Object prefab = PrefabUtility.CreatePrefab("Assets/Resources/data/line/" + LineFile.Replace("/", "_") + ".prefab", line.gameObject);
                PrefabUtility.ReplacePrefab(line.gameObject, prefab, ReplacePrefabOptions.ConnectToPrefab);
                line.gameObject.name = LineFile.Replace("/", "_");
            }
        }
    }
}
