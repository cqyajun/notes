﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;

[CustomEditor(typeof(Swatch))]
public class SwatchEditor : Editor
{

    Swatch swatch;
    public string swatchFile = "swatch/";
    void OnEnable()
    {
        swatch = (Swatch)target;
        swatchFile = swatch.name.Replace('_', '/');
    }

    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();
        swatchFile = EditorGUILayout.TextField("Swatch Name", swatchFile);
        if (GUILayout.Button("Create Swatch"))
        {
            string[] sub = swatchFile.Split('/');
            string dir = "";
            for (int i = 0; i < sub.Length - 1; i++)
            {
                dir += sub[i] + "/";
            }
            Debug.Log(dir);
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }
            string str = swatch.MakeLuaData(swatchFile.Replace("/", "_"));

            using (var s = System.IO.File.Create("Assets/XLua/Lua/by/LuaData/swatch_" + swatchFile + ".lua"))
            {
                //UnityEngine.Debug.Log(str);
                byte[] data = System.Text.Encoding.UTF8.GetBytes(str);
                s.Write(data, 0, data.Length);
            }

            string strText = swatch.MakeTextData(swatchFile.Replace("/", "_"));

            using (var s = System.IO.File.Create("Assets/../data/" + swatchFile + ".dat"))
            {
                //UnityEngine.Debug.Log(str);
                byte[] data = System.Text.Encoding.UTF8.GetBytes(strText);
                s.Write(data, 0, data.Length);
            }
            if (swatch != null)
            {
                Object prefab = PrefabUtility.CreatePrefab("Assets/Resources/data/swatch/" + swatchFile.Replace("/", "_") + ".prefab", swatch.gameObject);
                PrefabUtility.ReplacePrefab(swatch.gameObject, prefab, ReplacePrefabOptions.ConnectToPrefab);
                swatch.gameObject.name = swatchFile.Replace("/", "_");
            }
        }

        if(swatch.changeFish)
        {
            swatch.changeFish = false;
            for (int i = 0; i < swatch.swatchs.Count; i++)
            {
                if(swatch.swatchs[i].fishType == (int)swatch.fishChangID.x)
                {
                    swatch.swatchs[i].fishType = (int)swatch.fishChangID.y;
                }
            }
        }
        if (swatch.setGroupIDs && (int)swatch.timeGroupIDs.z != 0)
        {

            List<int> saveData = new List<int>();
            for (int i = (int)swatch.timeGroupIDs.x; i < (int)swatch.timeGroupIDs.y; i += (int)swatch.timeGroupIDs.z)
            {
                SwatchMsg sm = new SwatchMsg();
                sm.fishType = 100;
                sm.startFps = i;
                sm.trackOrGroup = swatch.groupIDs[Random.Range(0, swatch.groupIDs.Count)];
                while (saveData.Contains(sm.trackOrGroup))
                {
                    sm.trackOrGroup = swatch.groupIDs[Random.Range(0, swatch.groupIDs.Count)];
                }
                saveData.Add(sm.trackOrGroup);
                if (saveData.Count == swatch.groupIDs.Count)
                {
                    saveData.RemoveRange(0, 5);
                }

                swatch.swatchs.Add(sm);
            }
            swatch.setGroupIDs = false;
        }

        if (swatch.setfishIDs && (int)swatch.timefishIDs.z != 0)
        {
            List<int> saveData = new List<int>();
            List<int> saveData2 = new List<int>();
            for (int i = (int)swatch.timefishIDs.x; i < (int)swatch.timefishIDs.y; i += (int)swatch.timefishIDs.z)
            {
                SwatchMsg sm = new SwatchMsg();
                int num = Random.Range(0, swatch.fishIDs.Count);

                while (saveData2.Contains(num))
                {
                    num = Random.Range(0, swatch.fishIDs.Count);
                }
                saveData2.Add(num);
                if (saveData2.Count == swatch.fishIDs.Count)
                {
                    saveData2.RemoveRange(0, 5);
                }
                sm.fishType = swatch.fishIDs[num];

                sm.startFps = i;
                sm.trackOrGroup = swatch.trackIDs[Random.Range(0, swatch.trackIDs.Count)];
                while (saveData.Contains(sm.trackOrGroup))
                {
                    sm.trackOrGroup = swatch.trackIDs[Random.Range(0, swatch.trackIDs.Count)];
                }
                saveData.Add(sm.trackOrGroup);
                if (saveData.Count == swatch.trackIDs.Count)
                {
                    saveData.RemoveRange(0, 5);
                }

                swatch.swatchs.Add(sm);
            }
            swatch.setfishIDs = false;

        }
    }
}
