﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;

[CustomEditor(typeof(Group))]
public class GroupEditor : Editor
{
    Group group;
    public string groupFile = "group/";
    void OnEnable()
    {
        group = (Group)target;
        groupFile = group.name.Replace('_', '/');
    }

    void OnSceneGUI()
    {
        Group g = target as Group;

        if(g.isInsert)
        {
            g.isInsert = false;
            g.groupMsgs.Insert(g.insertIndex, new GroupMsg());
        }

        if(g.isRemove)
        {
            g.isRemove = false;
            g.groupMsgs.RemoveAt(g.removeIndex);
        }

        if(g.isChangeFishType)
        {
            g.isChangeFishType = false;
            string[] fts = g.fishType.Split('|');
            for (int i = 0; i < g.groupMsgs.Count; i++)
            {
                
                g.groupMsgs[i].fishType = System.Convert.ToInt32(fts[i % fts.Length]);
            }
        }

        if(g.setStartFps)
        {

            g.setStartFps = false;
            for (int i = 0; i < g.groupMsgs.Count; i++)
            {
                g.groupMsgs[i].startFps = i * g.distance + g.startFPS;
                if(g.groupMsgs[i].startFps == 0)
                {
                    g.groupMsgs[i].startFps = 1;
                }
            }
        }

        if(g.isChangeTrackID)
        {
            g.isChangeTrackID = false;
            for (int i = 0; i < g.groupMsgs.Count; i++)
            {
                g.groupMsgs[i].trackID = g.trackID;
            }
        }

        while(g.groupMsgs.Count > 31)
        {
            g.groupMsgs.RemoveAt(31);
        }
    }

    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();
        groupFile = EditorGUILayout.TextField("Group Name", groupFile);
        if (GUILayout.Button("Create Group"))
        {
            string str = group.MakeLuaData(groupFile.Replace("/", "_"));

            using (var s = System.IO.File.Create("Assets/XLua/Lua/by/LuaData/group_" + groupFile + ".lua"))
            {
                //UnityEngine.Debug.Log(str);
                byte[] data = System.Text.Encoding.UTF8.GetBytes(str);
                s.Write(data, 0, data.Length);
            }

            string strText = group.MakeTextData(groupFile.Replace("/", "_"));

            using (var s = System.IO.File.Create("Assets/../data/" + groupFile + ".dat"))
            {
                //UnityEngine.Debug.Log(str);
                byte[] data = System.Text.Encoding.UTF8.GetBytes(strText);
                s.Write(data, 0, data.Length);
            }

            Object prefab = PrefabUtility.CreatePrefab("Assets/Resources/data/group/" + groupFile.Replace("/", "_") + ".prefab", group.gameObject);
            PrefabUtility.ReplacePrefab(group.gameObject, prefab, ReplacePrefabOptions.ConnectToPrefab);
            group.gameObject.name = groupFile.Replace("/", "_");
        }
    }

    [MenuItem("Tools/data/Make Group")]
    public static void MakeGroup()
    {
        Object[] objs = Resources.LoadAll("data/group/");//AssetDatabase.LoadAllAssetsAtPath("Resources/data/group/");
        Debug.Log(objs.Length);
        for (int i = 0; i < objs.Length; i++)
        {
            GameObject go = objs[i] as GameObject;
            Group g = go.GetComponent<Group>();
            string gf = g.name.Replace('_', '/');

            string str = g.MakeLuaData(gf.Replace("/", "_"));

            using (var s = System.IO.File.Create("Assets/XLua/Lua/by/LuaFishing/" + gf + ".lua"))
            {
                //UnityEngine.Debug.Log(str);
                byte[] data = System.Text.Encoding.UTF8.GetBytes(str);
                s.Write(data, 0, data.Length);
            }

            string strText = g.MakeTextData(gf.Replace("/", "_"));

            using (var s = System.IO.File.Create("Assets/../data/" + gf + ".dat"))
            {
                //UnityEngine.Debug.Log(str);
                byte[] data = System.Text.Encoding.UTF8.GetBytes(strText);
                s.Write(data, 0, data.Length);
            }
        }
        AssetDatabase.Refresh();
    }
}
