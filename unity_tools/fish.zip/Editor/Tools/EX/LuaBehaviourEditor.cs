﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(LuaBehaviour))]
public class LuaBehaviourEditor : Editor
{

    void OnSceneGUI()
    {
        LuaBehaviour lb = (LuaBehaviour)target;
        if (lb.editorSettting)
        {
            lb.editorSettting = false;
            lb.objs.Clear();
            CheckChild(lb.transform, ref lb.objs);
        }
    }

    public void CheckChild(Transform root, ref List<GameObject> fishingMsgs)
    {
        fishingMsgs.Add(root.gameObject);
        for (int i = 0; i < root.childCount; i++)
        {
            CheckChild(root.GetChild(i), ref fishingMsgs);
        }
    }
}
