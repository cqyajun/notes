﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(GoldPotTool))]
public class GoldPotToolEditor : Editor
{

    public void OnSceneGUI()
    {
        GoldPotTool gpt = (GoldPotTool)target;
        if(gpt.golds.Count == 0)
        {
            for (int i = 0; i < gpt.transform.childCount; i++)
            {
                gpt.golds.Add(gpt.transform.GetChild(i));
            }
        }
        if(gpt.isEditor)
        {
            gpt.isEditor = false;
            for (int i = 0; i < gpt.golds.Count; i++)
            {
                gpt.golds[i].position = new Vector3(i % 20 * 70 - 1330 / 2, i / 20 * 70 - 280 / 2);
            }
        }
    }
}
