﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

[CustomEditor(typeof(ImgeSetName))]
public class ImgeSetNameEditor : Editor
{

    public void OnSceneGUI()
    {
        ImgeSetName isn = (ImgeSetName)target;
        if (isn.enabled)
        {
            for (int i = 0;i<isn.transform.childCount;i++)
            {
                Transform t = isn.transform.GetChild(i);
                t.name = t.GetComponent<Image>().sprite.name;
                t.transform.GetChild(0).name = "gold" + t.name;
            }
            isn.enabled = false;
        }
    }
}
