﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Text;

public class VersionSetting : Editor
{
    //[MenuItem("Tools/Set Version")]
    public static void SetVersion()
    {
#if UNITY_ANDROID
        SetVersion(BuildTarget.Android, "version_" + Application.version);
#endif
    }


    public static void SetVersion(BuildTarget target,string version)
    {

#if UNITY_ANDROID
        CopyFiles(target, Application.streamingAssetsPath, Application.dataPath + "/../Server/Android/" + version.Replace(".","_"));
        MakeHttpVersion(target,version.Replace(".", "_"));
        MakeCurrentVersion(version.Replace(".", "_"));
        File.Delete(Application.streamingAssetsPath + "/server_res.ver.txt");
        if (Directory.Exists(Application.streamingAssetsPath + "/server_res"))
        {
            Directory.Delete(Application.streamingAssetsPath + "/server_res", true);
        }
        AssetDatabase.Refresh();
#elif UNITY_IOS
        CopyFiles(target, Application.streamingAssetsPath, Application.dataPath + "/../Server/IOS/" + version.Replace(".", "_"));
        MakeHttpVersion(target, version.Replace(".", "_"));
        MakeCurrentVersion(version.Replace(".", "_"));
        File.Delete(Application.streamingAssetsPath + "/server_res.ver.txt");
        if (Directory.Exists(Application.streamingAssetsPath + "/server_res"))
        {
            Directory.Delete(Application.streamingAssetsPath + "/server_res", true);
        }
        AssetDatabase.Refresh();
#elif UNITY_WEBGL
        CopyFiles(target, Application.streamingAssetsPath, Application.dataPath + "/../Server/WEB/" + version.Replace(".", "_"));
        MakeHttpVersion(target, version.Replace(".", "_"));
        MakeCurrentVersion(version.Replace(".", "_"));
        File.Delete(Application.streamingAssetsPath + "/server_res.ver.txt");
        if (Directory.Exists(Application.streamingAssetsPath + "/server_res"))
        {
            Directory.Delete(Application.streamingAssetsPath + "/server_res", true);
        }
        AssetDatabase.Refresh();
#elif UNITY_STANDALONE_WIN
        CopyFiles(target, Application.streamingAssetsPath, Application.dataPath + "/../Server/Windows/" + version.Replace(".", "_"));
        MakeHttpVersion(target, version.Replace(".", "_"));
        MakeCurrentVersion(version.Replace(".", "_"));
        File.Delete(Application.streamingAssetsPath + "/server_res.ver.txt");
        if (Directory.Exists(Application.streamingAssetsPath + "/server_res"))
        {
            Directory.Delete(Application.streamingAssetsPath + "/server_res", true);
        }
        AssetDatabase.Refresh();
#endif


    }

    static void MakeCurrentVersion(string version)
    {
#if UNITY_ANDROID
        string fileName = Application.dataPath + "/../Server/Android/version.txt";
        if (File.Exists(fileName))
        {
            File.Delete(fileName);
        }
        File.WriteAllText(fileName, version);
#elif UNITY_IOS
        string fileName = Application.dataPath + "/../Server/IOS/version.txt";
        if (File.Exists(fileName))
        {
            File.Delete(fileName);
        }
        File.WriteAllText(fileName, version);
#elif UNITY_WEBGL
        string fileName = Application.dataPath + "/../Server/WEB/version.txt";
        if (File.Exists(fileName))
        {
            File.Delete(fileName);
        }
        File.WriteAllText(fileName, version, Encoding.Default);
#elif UNITY_STANDALONE_WIN
        string fileName = Application.dataPath + "/../Server/Windows/CurrentVersion2.txt";
        if (File.Exists(fileName))
        {
            File.Delete(fileName);
        }
        File.WriteAllText(fileName, version);
#endif

    }

    static void CopyFiles(BuildTarget bt, string src, string dest)
    {
        if (Directory.Exists(dest))
        {
            Directory.Delete(dest, true);
        }

        if (!Directory.Exists(dest))
        {
            Directory.CreateDirectory(dest);
        }


        //var destDirs = Directory.GetDirectories(dest);


        var files = Directory.GetFiles(src, "*.*", SearchOption.AllDirectories);
        foreach (string s in files)
        {
            if (s.Contains(".svn") || s.Contains("local_res"))
            {
                continue;
            }
            if (Path.GetExtension(s) != ".meta" && Path.GetExtension(s) != ".manifest" )//|| Path.GetFileName(s) == "StreamingAssets.manifest")/* && Path.GetFileName(s) != "StreamingAssets"*/)
            {
                var p = dest + Directory.GetParent(s).FullName.Substring(src.Length);
                if (!Directory.Exists(p))
                    Directory.CreateDirectory(p);

                //File.Copy(s, Path.Combine(p, Path.GetFileName(s)), true);
                if (Path.GetFileName(s) == "StreamingAssets")
                {
                    if (!Directory.Exists(p + "/server_res/"))
                        Directory.CreateDirectory(p + "/server_res/");
                    File.Copy(s, Path.Combine(p + "/server_res/", Path.GetFileName(s)), true);
                }
                else
                {
                    File.Copy(s, Path.Combine(p, Path.GetFileName(s)), true);
                }
            }
        }
        AssetDatabase.Refresh();
    }

    static void MakeHttpVersion(BuildTarget bt, string version)
    {
        string dest = string.Empty;
        if (bt == BuildTarget.iOS)
            dest = Application.dataPath + "/../Server/Ios/" + version.Replace(".", "_") + "/";
        else if(bt == BuildTarget.Android)
            dest = Application.dataPath + "/../Server/Android/" + version.Replace(".", "_") + "/";
        else if (bt == BuildTarget.WebGL)
            dest = Application.dataPath + "/../Server/WEB/" + version.Replace(".", "_") + "/";
        else if (bt == BuildTarget.StandaloneWindows)
            dest = Application.dataPath + "/../Server/Windows/" + version.Replace(".", "_") + "/";
        DirectoryInfo tmpInfo = new DirectoryInfo(dest);
        if (tmpInfo.Exists)
        {
            dest = tmpInfo.FullName;
        }
        Verall verAll = Verall.Read(dest);
        //UnityEngine.Debug.Log(verAll);
        if (verAll == null)
        {
            verAll = new Verall();
        }

        Verall newVersion = Verall.ReportBaseOn(verAll, dest);

        newVersion.SaveToPath(dest);
        newVersion.SaveToPath(Application.streamingAssetsPath);
    }

    static void DelFiles(string fileName)
    {
        
    }
}
