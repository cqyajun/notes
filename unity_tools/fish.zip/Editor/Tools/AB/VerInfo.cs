﻿using UnityEngine;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;


public class Verall
{
    public Dictionary<string, VerInfo> groups = new Dictionary<string, VerInfo>();
    public int ver;

    public static Verall ReportBaseOn(Verall verset, string path)
    {
        
        Verall vernew = new Verall();
        string[] directories = Directory.GetDirectories(path);
        foreach (string str in directories)
        {
            string key = Path.GetFileName(str);
            //UnityEngine.Debug.Log(key);
            if ((key.IndexOf("path") != 0) && !verset.groups.ContainsKey(key))
            {
                UnityEngine.Debug.LogWarning("目录未包含:" + key + " 如果需要增加，修改allver增加一行");
                verset.groups.Add(key, new VerInfo(key));
            }
        }

        UnityEngine.Debug.Log("目录数量:" + verset.groups.Count);
        int num = 0;
        int num2 = 0;
        int num3 = 0;
        foreach (KeyValuePair<string, VerInfo> pair in verset.groups)
        {
            vernew.groups[pair.Key] = new VerInfo(pair.Key);
            vernew.groups[pair.Key].GenHash(path);
            //UnityEngine.Debug.Log("目录Hash:" + pair.Key +"," + vernew.groups[pair.Key].filehash);
            foreach (KeyValuePair<string, string> pair2 in pair.Value.filehash)
            {
                if (!vernew.groups[pair.Key].filehash.ContainsKey(pair2.Key))
                {
                    UnityEngine.Debug.Log("文件被删除：" + pair.Key + ":" + pair2.Key);
                    num++;
                }
                else
                {
                    string str3 = vernew.groups[pair.Key].filehash[pair2.Key];
                    string str4 = pair.Value.filehash[pair2.Key];
                    if (str3 != str4)
                    {
                        UnityEngine.Debug.Log("文件更新：" + pair.Key + ":" + pair2.Key);
                        num2++;
                    }
                }
            }
            foreach (KeyValuePair<string, string> pair2 in vernew.groups[pair.Key].filehash)
            {
                if (!pair.Value.filehash.ContainsKey(pair2.Key))
                {
                    //UnityEngine.Debug.Log("文件增加：" + pair.Key + ":" + pair2.Key);
                    num3++;
                }
            }
        }

        if (((num3 == 0) && (num == 0)) && (num2 == 0))
        {
            vernew.ver = verset.ver;
            UnityEngine.Debug.Log("无变化 ver=" + vernew.ver);
        }
        else
        {
            vernew.ver = verset.ver + 1;
            UnityEngine.Debug.Log(string.Concat(new object[] { "检查变化结果 add:", num3, " remove:", num, " update:", num2 }));
            UnityEngine.Debug.Log("版本号变为:" + vernew.ver);
        }
        return vernew;
    }

    public static Verall Read(string path)
    {
        if (!File.Exists(Path.Combine(path, "allver.ver.txt")))
        {
            Debug.LogWarning("没有allver.ver.txt");
            return null;
        }
        string[] strArray = File.ReadAllText(Path.Combine(path, "allver.ver.txt"), Encoding.UTF8).Split(new string[] { "\n", "\r" }, StringSplitOptions.RemoveEmptyEntries);
        Verall verall = new Verall();
        foreach (string str2 in strArray)
        {
            if (str2.IndexOf("Ver:") == 0)
            {
                verall.ver = int.Parse(str2.Substring(4));
            }
            else
            {
                string[] strArray2 = str2.Split(new char[] { '|' });
                verall.groups[strArray2[0]] = new VerInfo(strArray2[0]);
                verall.groups[strArray2[0]].Read(verall.ver, strArray2[1], int.Parse(strArray2[2]), path);
            }
        }
        return verall;
    }

    public void SaveToPath(string path)
    {
        //Debug.Log(path);
        //Debug.Log(this.groups.Keys.Count);
        Dictionary<string, string> dictionary = new Dictionary<string, string>();
        foreach (VerInfo info in this.groups.Values)
        {
            dictionary[info.group] = info.SaveToPath(this.ver, path);
        }
        //string contents = "Ver:" + this.ver + "\n";
        //foreach (KeyValuePair<string, string> pair in dictionary)
        //{
        //    object obj2 = contents;
        //    if (!pair.Key.Contains(".DS_Store"))
        //    {
        //        contents = string.Concat(new object[] { obj2, pair.Key, "|", pair.Value, "|", this.groups[pair.Key].filehash.Count, "\n" });
        //    }
        //}
        //File.WriteAllText(Path.Combine(path, "allver.ver.txt"), contents, Encoding.UTF8);
    }

    public override string ToString()
    {
        int num = 0;
        int num2 = 0;
        int num3 = 0;
        foreach (KeyValuePair<string, VerInfo> pair in this.groups)
        {
            if (pair.Value.match > 0)
            {
                num++;
            }
            num3 += pair.Value.match;
            num2 += pair.Value.filehash.Count;
        }
        return string.Concat(new object[] { "ver=", this.ver, " group=(", num, "/", this.groups.Count, ") file=(", num3, "/", num2, ")" });
    }
}

public class VerInfo
{
    private string _group;
    public Dictionary<string, string> filehash = new Dictionary<string, string>();
    public int match = 0;
    private static SHA1CryptoServiceProvider osha1 = new SHA1CryptoServiceProvider();

    public VerInfo(string group)
    {
        this.group = group;
    }

    public void GenHash(string path)
    {
        UnityEngine.Debug.Log("GenHash:" + this.group);
        string groupRoot = Path.Combine(path, this.group);
        string[] strArray = Directory.GetFiles(groupRoot, "*.*", SearchOption.AllDirectories);
        foreach (string str in strArray)
        {
            if (((str.IndexOf(".crc.txt") < 0) && (str.IndexOf(".meta") < 0)) && (str.IndexOf(".db") < 0) && (str.IndexOf(".DS_Store") < 0))
            {
                this.GenHashOne(str, groupRoot);
            }
        }
    }

    public void GenHashOne(string filename, string pathParent)
    {
        string tmpParent = Path.GetFullPath(pathParent);
        using (Stream stream = File.OpenRead(filename))
        {
            string str = Convert.ToBase64String(osha1.ComputeHash(stream)) + "@" + stream.Length;
            filename = filename.Replace(tmpParent, "").Replace("\\", "/");
            if (filename.StartsWith("/"))
            {
                filename = filename.Substring(1);
            }
            this.filehash[filename] = str;
        }
    }

    public bool Read(int ver, string hash, int filecount, string path)
    {
        string str2 = Path.Combine(path, this.group.Replace('/', '_') + ".ver.txt");
        if (!File.Exists(str2))
        {
            return false;
        }
        using (Stream stream = File.OpenRead(str2))
        {
            if (Convert.ToBase64String(osha1.ComputeHash(stream)) != hash)
            {
                return false;
            }
        }
        string[] strArray = File.ReadAllText(str2, Encoding.UTF8).Split(new string[] { "\n", "\r" }, StringSplitOptions.RemoveEmptyEntries);
        foreach (string str5 in strArray)
        {
            string[] strArray2;
            if (str5.IndexOf("Ver:") == 0)
            {
                strArray2 = str5.Split(new string[] { "Ver:", "|FileCount:" }, StringSplitOptions.RemoveEmptyEntries);
                int num = int.Parse(strArray2[0]);
                int num2 = int.Parse(strArray2[1]);
                if (ver != num)
                {
                    return false;
                }
                if (num2 != filecount)
                {
                    return false;
                }
            }
            else
            {
                strArray2 = str5.Split(new char[] { '|' });
                this.filehash[strArray2[0]] = strArray2[1];
            }
        }
        return true;
    }

    public string SaveToPath(int ver, string path)
    {
        string contents = string.Concat(new object[] { "Ver:", ver, "|FileCount:", this.filehash.Count, "\n" });
        foreach (KeyValuePair<string, string> pair in this.filehash)
        {
            string str6 = contents;
            contents = str6 + pair.Key + "|" + pair.Value + "\n";
        }
        string str3 = Path.Combine(path, this.group.Replace('/', '_') + ".ver.txt");
        File.WriteAllText(str3, contents, Encoding.UTF8);
        using (Stream stream = File.OpenRead(str3))
        {
            return Convert.ToBase64String(osha1.ComputeHash(stream));
        }
    }

    public string group
    {
        get
        {
            return _group;
        }
        private set
        {
            this._group = value;
        }
    }
}

