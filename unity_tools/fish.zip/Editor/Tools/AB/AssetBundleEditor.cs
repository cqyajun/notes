﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Linq;

public class AssetBundleEditor : Editor
{  

    [MenuItem("Tools/FrameWork/Make AssetBundle")]
    public static void MakeAssetBundle()
    {
#if UNITY_ANDROID
        ResourcesEditor.SetGameResABName();
        ResourcesEditor.SetRescourcesMsg();
        LuaPackage.BulidLua(BuildTarget.Android, Application.version);
        MakeAssetBundleAB(BuildTarget.Android, Application.version);
        VersionSetting.SetVersion(BuildTarget.Android, "version_" + Application.version);
#elif UNITY_IPHONE
       ResourcesEditor.SetGameResABName();
        ResourcesEditor.SetRescourcesMsg();
        LuaPackage.BulidLua(BuildTarget.iOS, Application.version);
        MakeAssetBundleAB(BuildTarget.iOS, Application.version);
        VersionSetting.SetVersion(BuildTarget.iOS, "version_" + Application.version);
#elif UNITY_WEBGL
        ResourcesEditor.SetGameResABName();
        ResourcesEditor.SetRescourcesMsg();
        LuaPackage.BulidLua(BuildTarget.WebGL, Application.version);
        MakeAssetBundleAB(BuildTarget.WebGL, Application.version);
        VersionSetting.SetVersion(BuildTarget.WebGL, "version_" + Application.version);
#endif
    }

    static void MakeAssetBundleAB(BuildTarget target, string version)
    {                
        string resPath = "Assets/StreamingAssets";
        if (!Directory.Exists(resPath))
        {
            Directory.CreateDirectory(resPath);
        }
        //BuildAssetBundleOptions options = BuildAssetBundleOptions.DeterministicAssetBundle |
        //                                  BuildAssetBundleOptions.ChunkBasedCompression |
        //                                  BuildAssetBundleOptions.DisableWriteTypeTree;
        BuildAssetBundleOptions options = BuildAssetBundleOptions.None;
        BuildPipeline.BuildAssetBundles(resPath, options, target);
        AssetDatabase.Refresh();
    }

   

    static void CopyFiles(string src, string dest)
    {
        if (Directory.Exists(dest))
        {
            Directory.Delete(dest, true);
        }

        if (!Directory.Exists(dest))
        {
            Directory.CreateDirectory(dest);
        }


        //var destDirs = Directory.GetDirectories(dest);


        var files = Directory.GetFiles(src, "*.*", SearchOption.AllDirectories);
        foreach (string s in files)
        {
            if (s.Contains(".svn") || s.Contains("local_res"))
            {
                continue;
            }
            if (Path.GetExtension(s) != ".meta" && Path.GetExtension(s) != ".manifest")//|| Path.GetFileName(s) == "StreamingAssets.manifest")/* && Path.GetFileName(s) != "StreamingAssets"*/)
            {
                var p = dest + Directory.GetParent(s).FullName.Substring(src.Length);
                if (!Directory.Exists(p))
                    Directory.CreateDirectory(p);

                File.Copy(s, Path.Combine(p, Path.GetFileName(s)), true);
            }
        }
        AssetDatabase.Refresh();
    }

}
