﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.U2D;
using System.Text;

public class NoResourcesMsgList : Editor
{
    [MenuItem("Assets/MogenTools/NoResourcesMsgList")]
    public static void NoResourcesMsgListSetting()
    {
        string str = "";
        Object[] arr = Selection.GetFiltered(typeof(Object), SelectionMode.Assets);
        string path = AssetDatabase.GetAssetPath(arr[0]);//Application.dataPath.Substring(0, Application.dataPath.LastIndexOf('/')) + "/" + AssetDatabase.GetAssetPath(arr[0]);
        path = path.Replace("Assets/Game/", "").Replace("Assets/Resources/", "").Replace("/","\\");
        Debug.Log(path);
        TextAsset tta = AssetDatabase.LoadAssetAtPath<TextAsset>("Assets/Config/AssetBundleConfig.asset");
        if(tta != null)
        {
            str = tta.text;
        }
        if (!str.Contains(path))
        {
            str += path + "\n";
            TextAsset ta = new TextAsset(str);
            ta.name = "AssetBundleConfig";
            AssetDatabase.CreateAsset(ta, "Assets/Config/AssetBundleConfig.asset");
            AssetDatabase.SaveAssets();
            Debug.Log(ta.text);
        }
    }
}
