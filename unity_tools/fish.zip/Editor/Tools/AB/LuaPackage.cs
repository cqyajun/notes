﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;

public class LuaPackage : Editor
{
    static List<AssetBundleBuild> luaMaps = new List<AssetBundleBuild>();
    static List<string> luaGroups = new List<string>();
    [MenuItem("Tools/FrameWork/Build Lua")]
    public static void BuildLua()
    {
#if UNITY_ANDROID
        BulidLua(BuildTarget.Android,Application.version);
#elif UNITY_IOS
        BulidLua(BuildTarget.iOS,Application.version);
#elif UNITY_WEBGL
        BulidLua(BuildTarget.WebGL, Application.version);
#endif
    }
    [MenuItem("Tools/FrameWork/Copy Lua")]
    public static void CopyLua()
    {
        string streamDir = Application.dataPath + "/" + "Resources/Lua/";
        if (Directory.Exists(streamDir))
        {
            Directory.Delete(streamDir, true);
        }
        Directory.CreateDirectory(streamDir);
        CopyLuaTXTFiles("Assets/XLua/Lua/", streamDir);
        AssetDatabase.Refresh();
    }

    public static void BulidLua(BuildTarget target, string version)
    {
        luaMaps.Clear();
        if (!Directory.Exists("Assets/XLua/Lua/"))
        {
            return;
        }
        if (Directory.Exists("Assets/StreamingAssets/lua"))
        {
            Directory.Delete("Assets/StreamingAssets/lua", true);
        }
        if (target == BuildTarget.WebGL)
        {
            CopyLua();
        }
        else
        {
            //CopyLua();
            string streamDir = Application.dataPath + "/" + "Game/";
            if (!Directory.Exists(streamDir))
            {
                Directory.CreateDirectory(streamDir);
            }
            CopyLuaBytesFiles("Assets/XLua/Lua/", streamDir);
            
        }
        AssetDatabase.Refresh();
        ResourcesEditor.SetGameResABName();
        AssetDatabase.Refresh();
    }

    static void CopyLuaBytesFiles(string sourceDir, string destDir, bool appendext = true, string searchPattern = "*.lua", SearchOption option = SearchOption.AllDirectories)
    {
        if (!Directory.Exists(sourceDir))
        {
            return;
        }
        string[] dirs = Directory.GetDirectories(sourceDir);
        for (int i = 0; i < dirs.Length; i++)
        {
            if (!Directory.Exists(dirs[i].Replace("XLua/Lua", "Game") + "/Lua"))
            {
                Directory.CreateDirectory(dirs[i].Replace("XLua/Lua", "Game") + "/Lua");
            }
            
            string[] files = Directory.GetFiles(dirs[i], searchPattern, option);
            int len = sourceDir.Length;

            if (sourceDir[len - 1] == '/' || sourceDir[len - 1] == '\\')
            {
                --len;
            }
            for (int j = 0; j < files.Length; j++)
            {
                string dest = dirs[i].Replace("XLua/Lua", "Game") + "/Lua" + files[j].Replace(dirs[i], "");
                if (appendext) dest += ".bytes";
                string dir = Path.GetDirectoryName(dest);

                Directory.CreateDirectory(dir);
                File.Copy(files[j], dest, true);
            }
        }

        //string[] files = Directory.GetFiles(sourceDir, searchPattern, option);
        //int len = sourceDir.Length;

        //if (sourceDir[len - 1] == '/' || sourceDir[len - 1] == '\\')
        //{
        //    --len;
        //}

        //for (int i = 0; i < files.Length; i++)
        //{
        //    string str = files[i].Remove(0, len);
        //    string dest = destDir + str;
        //    if (appendext) dest += ".bytes";
        //    string dir = Path.GetDirectoryName(dest);

        //    Directory.CreateDirectory(dir);
        //    File.Copy(files[i], dest, true);
        //}
    }

    static void CopyLuaTXTFiles(string sourceDir, string destDir, bool appendext = true, string searchPattern = "*.lua", SearchOption option = SearchOption.AllDirectories)
    {
        if (!Directory.Exists(sourceDir))
        {
            return;
        }

        string[] files = Directory.GetFiles(sourceDir, searchPattern, option);
        int len = sourceDir.Length;

        if (sourceDir[len - 1] == '/' || sourceDir[len - 1] == '\\')
        {
            --len;
        }

        for (int i = 0; i < files.Length; i++)
        {
            string str = files[i].Remove(0, len);
            string dest = destDir + str;
            if (appendext) dest += ".txt";
            string dir = Path.GetDirectoryName(dest);

            Directory.CreateDirectory(dir);
            File.Copy(files[i], dest, true);
        }
    }

    static void AddBuildMap(string bundleName, string pattern, string path, ref List<AssetBundleBuild> maps)
    {
        string[] files = Directory.GetFiles(path, pattern);
        if (files.Length == 0) return;

        for (int i = 0; i < files.Length; i++)
        {
            files[i] = files[i].Replace('\\', '/');
        }
        AssetBundleBuild build = new AssetBundleBuild();
        build.assetBundleName = bundleName;
        build.assetNames = files;
        maps.Add(build);
    }
}
