/**
 * Created by JetBrains PhpStorm.
 * User: taoqili
 * Date: 12-2-10
 * Time: 下午3:50
 * To change this template use File | Settings | File Templates.
 */
//文件类型图标索引
var fileTypeMaps = {
    ".rar":"icon_rar.gif",
    ".zip":"icon_rar.gif",
    ".doc":"icon_doc.gif",
    ".docx":"icon_doc.gif",
    ".pdf":"icon_pdf.gif",
    ".mp3":"icon_mp3.gif",
    ".xls":"icon_xls.gif",
    ".chm":"icon_chm.gif",
    ".ppt":"icon_ppt.gif",
    ".pptx":"icon_ppt.gif",
    ".avi":"icon_mv.gif",
    ".rmvb":"icon_mv.gif",
    ".wmv":"icon_mv.gif",
    ".flv":"icon_mv.gif",
    ".swf":"icon_mv.gif",
    ".rm":"icon_mv.gif",
    ".exe":"icon_exe.gif",
    ".psd":"icon_psd.gif",
    ".txt":"icon_txt.gif"
};